"use client";

import { useEffect, useState } from "react";

interface WinnerInfo {
  username: string;
  prize: string;
  ticket: string;
}

const FALLBACK_WINNERS: WinnerInfo[] = [
  { username: "Lord_Kaelen", prize: "Demon Armor", ticket: "#089" },
  { username: "Merlin_Sorc", prize: "Golden Helmet", ticket: "#142" },
  { username: "Galahad_Knight", prize: "Great Shield", ticket: "#004" },
  { username: "Legolas_Paladin", prize: "Winged Helmet", ticket: "#299" },
  { username: "Morgana_Druid", prize: "Magic Plate Armor", ticket: "#077" },
  { username: "Elrond_Elf", prize: "Stonecutter Axe", ticket: "#105" },
];

export default function WinnersMarquee() {
  const [winners, setWinners] = useState<WinnerInfo[]>(FALLBACK_WINNERS);

  useEffect(() => {
    fetch("/api/draw-history?limit=10&status=ended")
      .then((r) => r.json())
      .then((data) => {
        if (data.draws && data.draws.length > 0) {
          const loadedWinners = data.draws
            .filter((d: any) => d.winner || d.federal1stPrize)
            .map((d: any) => {
              const ticketNum = d.winner?.winningTicketNumber || 
                                (d.federal1stPrize ? (parseInt(d.federal1stPrize) % d.soldTickets) + 1 : 1);
              return {
                username: d.winner?.username || "Guerreiro Anônimo",
                prize: d.title,
                ticket: `#${String(ticketNum).padStart(3, "0")}`,
              };
            });
          if (loadedWinners.length > 0) {
            setWinners(loadedWinners);
          }
        }
      })
      .catch(() => {});
  }, []);

  // Double the winners to create a seamless infinite scrolling loop
  const displayWinners = [...winners, ...winners];

  return (
    <div style={s.marqueeContainer}>
      <div style={s.fadeLeft} />
      
      <div style={s.marqueeTrack} className="winners-marquee-track">
        {displayWinners.map((winner, idx) => (
          <div key={idx} style={s.winnerItem}>
            <span style={s.trophy}>🏆</span>
            <strong style={s.username}>{winner.username}</strong>
            <span style={s.action}>conquistou</span>
            <strong style={s.prize}>{winner.prize}</strong>
            <span style={s.ticket}>{winner.ticket}</span>
            <span style={s.dot}>✦</span>
          </div>
        ))}
      </div>

      <div style={s.fadeRight} />

      <style jsx global>{`
        @keyframes scrollMarquee {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }
        .winners-marquee-track {
          display: flex;
          width: max-content;
          animation: scrollMarquee 25s linear infinite;
        }
        .winners-marquee-track:hover {
          animation-play-state: paused;
        }
      `}</style>
    </div>
  );
}

const s: Record<string, React.CSSProperties> = {
  marqueeContainer: {
    position: "relative",
    overflow: "hidden",
    background: "#110e08",
    borderBottom: "1px solid #3d2e0f",
    padding: "10px 0",
    display: "flex",
    alignItems: "center",
    width: "100%",
    zIndex: 10,
  },
  marqueeTrack: {
    display: "flex",
    alignItems: "center",
    gap: 32,
  },
  winnerItem: {
    display: "flex",
    alignItems: "center",
    gap: 8,
    fontSize: 12.5,
    fontFamily: "'Cinzel', serif",
    color: "#a8865a",
    whiteSpace: "nowrap" as const,
  },
  trophy: {
    fontSize: 14,
  },
  username: {
    color: "#d4af37",
    fontWeight: "bold",
    letterSpacing: "0.5px",
  },
  action: {
    fontSize: 11,
    fontStyle: "italic",
    color: "#8a6a10",
    fontFamily: "'Crimson Text', serif",
  },
  prize: {
    color: "#f0dfa8",
    letterSpacing: "0.5px",
  },
  ticket: {
    background: "rgba(39, 174, 96, 0.1)",
    border: "1px solid #27ae60",
    color: "#27ae60",
    borderRadius: 3,
    padding: "1px 5px",
    fontSize: 10,
    fontWeight: "bold",
  },
  dot: {
    marginLeft: 16,
    color: "#5a4318",
    fontSize: 14,
  },
  fadeLeft: {
    position: "absolute",
    left: 0,
    top: 0,
    bottom: 0,
    width: 60,
    background: "linear-gradient(90deg, #110e08 0%, transparent 100%)",
    zIndex: 2,
    pointerEvents: "none",
  },
  fadeRight: {
    position: "absolute",
    right: 0,
    top: 0,
    bottom: 0,
    width: 60,
    background: "linear-gradient(270deg, #110e08 0%, transparent 100%)",
    zIndex: 2,
    pointerEvents: "none",
  },
};
