import { cookies } from "next/headers";
import { verifyToken } from "./auth";

export async function getSession() {

  const cookieStore =
    cookies();

  const token =
    cookieStore.get("token");

  if (!token) {
    return null;
  }

  const user =
    await verifyToken(
      token.value
    );

  return user;
}