import { NextRequest, NextResponse } from "next/server";
import { verifyToken } from "@/lib/auth";
import prisma from "@/lib/prisma";
import { v4 as uuid } from "uuid";
import crypto from "crypto";

export async function POST(req: NextRequest) {
  try {
    const token = req.cookies.get("token")?.value;
    if (!token) return NextResponse.json({ error: "Nao autenticado" }, { status: 401 });

    const decoded = verifyToken(token);
    if (!decoded) return NextResponse.json({ error: "Token invalido" }, { status: 401 });

    const body = await req.json();
    const { amount, raffleId, quantity } = body;

    if (!amount || !raffleId || !quantity || quantity < 1) {
      return NextResponse.json({ error: "Dados invalidos" }, { status: 400 });
    }

    const raffle = await prisma.raffle.findUnique({ where: { id: raffleId } });
    if (!raffle || raffle.status !== "active") {
      return NextResponse.json({ error: "Rifa nao encontrada ou encerrada" }, { status: 404 });
    }

    const available = raffle.totalTickets - raffle.soldTickets;
    if (quantity > available) {
      return NextResponse.json({ error: "Bilhetes insuficientes disponiveis" }, { status: 400 });
    }

    const user = await prisma.user.findUnique({ where: { id: decoded.id } });
    if (!user) return NextResponse.json({ error: "Usuario nao encontrado" }, { status: 404 });

    let mpPaymentId = `mock-${uuid()}`;
    let pixCode = `00020101021226870014br.gov.bcb.pix25650014br.gov.bcb.pix22370007cliente3025000000000000000000000005204000053039865404${Number(amount).toFixed(2)}5802BR5910Tibia Rifa6009Sao Paulo62070503***6304EA2C`;

    // Attempt to generate real PIX using Mercado Pago API via direct fetch (bypassing buggy SDK)
    if (process.env.MP_ACCESS_TOKEN && !process.env.MP_ACCESS_TOKEN.startsWith("YOUR_")) {
      try {
        const mpRes = await fetch("https://api.mercadopago.com/v1/payments", {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${process.env.MP_ACCESS_TOKEN}`,
            "Content-Type": "application/json",
            "X-Idempotency-Key": crypto.randomUUID(),
          },
          body: JSON.stringify({
            transaction_amount: Number(amount),
            description: `${quantity}x bilhete(s) - ${raffle.title}`,
            payment_method_id: "pix",
            payer: {
              email: user.email.includes("@") ? user.email : "test_payer@testuser.com",
            },
            external_reference: uuid(),
          }),
        });

        if (mpRes.ok) {
          const paymentData = await mpRes.json();
          if (paymentData.id) {
            mpPaymentId = String(paymentData.id);
            pixCode = paymentData.point_of_interaction?.transaction_data?.qr_code ?? pixCode;
            console.log("[pix] Mercado Pago payment created successfully:", mpPaymentId);
          }
        } else {
          const errData = await mpRes.json().catch(() => ({}));
          console.warn("[pix] Mercado Pago API returned error, falling back to local simulation:", errData);
        }
      } catch (mpErr) {
        console.error("[pix] Failed to contact Mercado Pago API, using local fallback:", mpErr);
      }
    }

    const payment = await prisma.payment.create({
      data: {
        amount: Number(amount),
        status: "PENDING",
        pixCode: mpPaymentId,
        userId: decoded.id,
      },
    });

    return NextResponse.json({
      success: true,
      paymentId: payment.id,
      mpPaymentId: mpPaymentId,
      qr_code: pixCode,
    });
  } catch (err) {
    console.error("[pix] General error:", err);
    return NextResponse.json({ error: "Erro ao gerar PIX" }, { status: 500 });
  }
}
