"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { GoldenHelmetIcon } from "@/components/Navbar";

interface DrawRecord {
  id: string;
  title: string;
  status: string;
  totalTickets: number;
  soldTickets: number;
  winner: any; // Winner relation object or name
  createdAt: string;
  federalContest: number | null;
  federalDrawDate: string | null;
  federal1stPrize: string | null;
}

function CopyButton({ text, label }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch { /* fallback */ }
  };
  return (
    <button onClick={copy} className="pf-copy-btn" title={label ?? "Copiar"}>
      {copied ? (
        <span className="pf-copied-badge">✓ Copiado!</span>
      ) : (
        <span className="pf-copy-icon">📋</span>
      )}
    </button>
  );
}

function SkeletonRow() {
  return (
    <div className="pf-history-row pf-skeleton-row">
      <div className="skeleton" style={{ height: 16, width: "30%", borderRadius: 4 }} />
      <div className="skeleton" style={{ height: 14, width: "15%", borderRadius: 4 }} />
      <div className="skeleton" style={{ height: 14, width: "15%", borderRadius: 4 }} />
      <div className="skeleton" style={{ height: 14, width: "20%", borderRadius: 4 }} />
      <div className="skeleton" style={{ height: 30, width: 80, borderRadius: 6 }} />
    </div>
  );
}

export default function ProvablyFairPage() {
  /* ── Verifier State ── */
  const [federalContest, setFederalContest] = useState("");
  const [federal1stPrize, setFederal1stPrize] = useState("");
  const [totalSold, setTotalSold] = useState("");
  const [expectedWinnerIndex, setExpectedWinnerIndex] = useState<number | null>(null);
  
  const [resultIndex, setResultIndex] = useState<number | null>(null);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  /* ── History State ── */
  const [draws, setDraws] = useState<DrawRecord[]>([]);
  const [historyLoading, setHistoryLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [statusFilter, setStatusFilter] = useState("all");
  const [search, setSearch] = useState("");
  const searchTimeout = useRef<NodeJS.Timeout | null>(null);

  const verifierRef = useRef<HTMLDivElement>(null);

  /* ── Fetch draw history ── */
  const fetchHistory = useCallback(async (p: number, status: string, q: string) => {
    setHistoryLoading(true);
    try {
      const params = new URLSearchParams({ page: String(p), limit: "8", status });
      if (q) params.set("search", q);
      const res = await fetch(`/api/draw-history?${params}`);
      const data = await res.json();
      setDraws(data.draws ?? []);
      setTotalPages(data.pagination?.totalPages ?? 1);
    } catch {
      setDraws([]);
    } finally {
      setHistoryLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchHistory(page, statusFilter, search);
  }, [page, statusFilter, fetchHistory]);

  function handleSearch(val: string) {
    setSearch(val);
    if (searchTimeout.current) clearTimeout(searchTimeout.current);
    searchTimeout.current = setTimeout(() => {
      setPage(1);
      fetchHistory(1, statusFilter, val);
    }, 400);
  }

  function changeStatusFilter(s: string) {
    setStatusFilter(s);
    setPage(1);
    fetchHistory(1, s, search);
  }

  function autoFill(draw: DrawRecord) {
    if (!draw.federalContest || !draw.federal1stPrize) return;
    setFederalContest(String(draw.federalContest));
    setFederal1stPrize(draw.federal1stPrize);
    setTotalSold(String(draw.soldTickets));
    setResultIndex(null);
    setError("");
    setSuccess("");
    verifierRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function handleVerify(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setSuccess("");
    setResultIndex(null);

    const prizeVal = parseInt(federal1stPrize, 10);
    const ticketsSold = parseInt(totalSold, 10);

    if (isNaN(prizeVal) || prizeVal < 0) {
      setError("O 1º Prêmio da Loteria Federal deve ser um número inteiro válido.");
      return;
    }
    if (isNaN(ticketsSold) || ticketsSold <= 0) {
      setError("A quantidade de bilhetes vendidos deve ser maior que zero.");
      return;
    }

    const winningIndex = prizeVal % ticketsSold;
    setResultIndex(winningIndex);
    setSuccess("Divisão modular calculada com sucesso! Veja o resultado abaixo.");
  }

  return (
    <div style={s.page}>
      {/* ═══ HERO BANNER ═══ */}
      <section style={s.hero}>
        <div style={{ display: "flex", justifyContent: "center", marginBottom: 16 }}>
          <GoldenHelmetIcon size={56} />
        </div>
        <h1 style={s.heroTitle}>TRANSPARÊNCIA ABSOLUTA</h1>
        <p style={s.heroSub}>Sorteios 100% auditáveis e baseados nos resultados oficiais da Loteria Federal da Caixa</p>
        <div style={s.heroDivider}>
          <div style={s.divLine} />
          <span style={{ color: "#8a6a10", fontSize: 16 }}>🛡️</span>
          <div style={s.divLine} />
        </div>

        {/* Trust badges */}
        <div style={s.trustRow}>
          <TrustBadge icon="🇧🇷" label="Loteria Federal" />
          <TrustBadge icon="📜" label="Zero Manipulação" />
          <TrustBadge icon="⚖️" label="100% Verificável" />
          <TrustBadge icon="🔎" label="Matemática Pura" />
        </div>
      </section>

      <div style={s.container}>
        {/* ═══ HOW IT WORKS ═══ */}
        <section style={{ marginBottom: 48 }}>
          <h2 style={s.sectionTitle}>✦ COMO FUNCIONA O SORTEIO?</h2>
          <p style={s.sectionSub}>Entenda o processo transparente que garante total integridade de cada item lendário sorteado</p>
          
          <div style={s.stepsGrid}>
            <StepCard
              step="01"
              icon="🎟️"
              title="1. Fechamento da Rifa"
              desc="Quando todos os bilhetes são vendidos (ou a rifa é encerrada), o total de bilhetes vendidos serve como divisor matemático do nosso sorteio."
            />
            <StepCard
              step="02"
              icon="🇧🇷"
              title="2. Loteria Federal"
              desc="Aguardamos o sorteio oficial da Loteria Federal (Caixa Econômica). O número sorteado no 1º prêmio (ex: 47814) servirá como a nossa semente de sorteio."
            />
            <StepCard
              step="03"
              icon="⚙️"
              title="3. Cálculo Modular (Resto)"
              desc="Calculamos o resto da divisão do 1º prêmio pelo número de bilhetes vendidos: Fórmula: Índice Vencedor = 1º Prêmio % Bilhetes Vendidos."
            />
            <StepCard
              step="04"
              icon="🏆"
              title="4. Bilhete Vencedor"
              desc="O bilhete que estiver na posição correspondente ao índice vencedor na lista ordenada por ordem de compra (createdAt) leva a premiação!"
            />
          </div>
        </section>

        {/* ═══ INTERACTIVE VERIFIER ═══ */}
        <section ref={verifierRef} style={{ marginBottom: 48 }}>
          <h2 style={s.sectionTitle}>✦ AUDITORIA INDEPENDENTE</h2>
          <p style={s.sectionSub}>Use a calculadora abaixo para auditar de forma autônoma qualquer resultado do sistema</p>

          <div style={s.verifierCard}>
            <form onSubmit={handleVerify} style={{ display: "flex", flexDirection: "column", gap: 18 }}>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16 }}>
                {/* Federal Contest */}
                <div style={s.fieldGroup}>
                  <label style={s.label}>
                    🔢 Concurso Federal
                  </label>
                  <input
                    type="number"
                    className="form-input"
                    style={s.monoInput}
                    placeholder="Ex: 5865"
                    value={federalContest}
                    onChange={(e) => setFederalContest(e.target.value)}
                    required
                  />
                </div>

                {/* 1st Prize */}
                <div style={s.fieldGroup}>
                  <label style={s.label}>
                    💰 1º Prêmio Oficial (5 dígitos)
                  </label>
                  <input
                    type="number"
                    className="form-input"
                    style={s.monoInput}
                    placeholder="Ex: 47814"
                    value={federal1stPrize}
                    onChange={(e) => setFederal1stPrize(e.target.value)}
                    required
                  />
                </div>

                {/* Total Sold */}
                <div style={s.fieldGroup}>
                  <label style={s.label}>
                    🎟️ Bilhetes Vendidos
                  </label>
                  <input
                    type="number"
                    className="form-input"
                    style={s.monoInput}
                    placeholder="Ex: 500"
                    value={totalSold}
                    onChange={(e) => setTotalSold(e.target.value)}
                    required
                  />
                </div>
              </div>

              {error && <div style={s.errorBox}>⚠️ {error}</div>}
              {success && <div style={s.successBox}>✨ {success}</div>}

              <button type="submit" className="btn btn-gold btn-full" style={{ fontSize: 14, letterSpacing: 2, padding: "14px 0", cursor: "pointer" }}>
                🛡️ AUDITAR BILHETE VENCEDOR
              </button>
            </form>
          </div>

          {/* Verification Results */}
          {resultIndex !== null && (
            <div style={s.resultCard} className="animate-fade-in">
              <h3 style={{ fontFamily: "var(--font-title)", color: "var(--gold)", fontSize: 16, marginBottom: 16, letterSpacing: 1 }}>
                🎯 RESULTADO DO CÁLCULO DE AUDITORIA
              </h3>
              
              <div style={s.calcGrid}>
                <div style={s.calcBox}>
                  <span style={s.calcLabel}>Semente Oficial (1º Prêmio)</span>
                  <strong style={s.calcValue}>{federal1stPrize}</strong>
                </div>
                <div style={s.calcBox}>
                  <span style={s.calcLabel}>Divisor (Bilhetes Vendidos)</span>
                  <strong style={s.calcValue}>{totalSold}</strong>
                </div>
              </div>

              <div style={s.winnerBox}>
                <span style={s.winnerLabel}>ÍNDICE DO BILHETE GANHADOR DETERMINADO</span>
                <span style={s.winnerNumber}>Posição #{resultIndex}</span>
                <span style={s.winnerFormula}>
                  Cálculo: {federal1stPrize} Modulo (%) {totalSold} = Resto da Divisão: <strong>{resultIndex}</strong>
                </span>
                <p style={{ fontSize: 12, color: "var(--cream3)", marginTop: 12, fontStyle: "italic" }}>
                  * O vencedor oficial é o comprador do bilhete correspondente ao índice #{resultIndex} na lista ordenada cronologicamente por compra.
                </p>
              </div>
            </div>
          )}
        </section>

        {/* ═══ DRAW HISTORY ═══ */}
        <section style={{ marginBottom: 48 }}>
          <h2 style={s.sectionTitle}>✦ HISTÓRICO DE AUDITORIA DE SORTEIOS</h2>
          <p style={s.sectionSub}>Acompanhe e valide cada sorteio oficial realizado no sistema</p>

          {/* Search & Filters */}
          <div style={s.historyControls}>
            <div style={s.searchBox}>
              <span style={{ fontSize: 14, opacity: 0.5 }}>🔍</span>
              <input
                type="text"
                placeholder="Buscar por nome da rifa..."
                value={search}
                onChange={(e) => handleSearch(e.target.value)}
                style={s.searchInput}
              />
            </div>
            <div style={s.filterBtns}>
              {[
                { key: "all", label: "Todos" },
                { key: "ended", label: "Sorteados" },
                { key: "active", label: "Ativos" },
              ].map((f) => (
                <button
                  key={f.key}
                  onClick={() => changeStatusFilter(f.key)}
                  style={{
                    ...s.filterBtn,
                    ...(statusFilter === f.key ? s.filterBtnActive : {}),
                  }}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {/* History Table */}
          <div style={s.historyTable}>
            <div style={s.historyHeader}>
              <span style={{ flex: 2 }}>Prêmio / Rifa</span>
              <span style={{ flex: 1, textAlign: "center" }}>Concurso Federal</span>
              <span style={{ flex: 1, textAlign: "center" }}>1º Prêmio Caixa</span>
              <span style={{ flex: 1, textAlign: "center" }}>Bilhete Ganhador</span>
              <span style={{ width: 100, textAlign: "center" }}>Ação</span>
            </div>

            {/* Skeleton loading */}
            {historyLoading && Array.from({ length: 5 }).map((_, i) => <SkeletonRow key={i} />)}

            {/* Empty state */}
            {!historyLoading && draws.length === 0 && (
              <div style={s.emptyHistory}>
                <span style={{ fontSize: 32 }}>📭</span>
                <span style={{ color: "var(--cream3)", fontSize: 14, marginTop: 8 }}>Nenhum sorteio registrado no reino</span>
              </div>
            )}

            {/* Data rows */}
            {!historyLoading && draws.map((draw) => (
              <div key={draw.id} style={s.historyRow}>
                {/* Title + Date */}
                <div style={{ flex: 2, display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}>
                  <span style={s.rowTitle}>{draw.title}</span>
                  <span style={s.rowDate}>
                    {new Date(draw.createdAt).toLocaleDateString("pt-BR", { day: "2-digit", month: "short", year: "numeric" })}
                  </span>
                </div>

                {/* Contest */}
                <div style={{ flex: 1, textAlign: "center" }}>
                  {draw.federalContest ? (
                    <strong style={{ color: "var(--gold)" }}>Nº {draw.federalContest}</strong>
                  ) : (
                    <span style={{ color: "var(--cream3)", fontSize: 12, fontStyle: "italic" }}>Aguardando Sorteio</span>
                  )}
                </div>

                {/* 1st Prize */}
                <div style={{ flex: 1, textAlign: "center" }}>
                  {draw.federal1stPrize ? (
                    <code style={{ fontSize: 13, color: "var(--cream)" }}>{draw.federal1stPrize}</code>
                  ) : (
                    <span style={{ color: "var(--cream3)", fontSize: 12 }}>—</span>
                  )}
                </div>

                {/* Winner */}
                <div style={{ flex: 1, textAlign: "center" }}>
                  {draw.winner ? (
                    <span style={s.winnerTag}>#{String(draw.winner.winningTicketNumber || draw.federal1stPrize ? (parseInt(draw.federal1stPrize || "0") % draw.soldTickets) + 1 : 0).padStart(3, "0")}</span>
                  ) : draw.status === "ended" && draw.federal1stPrize ? (
                    <span style={s.winnerTag}>#{String((parseInt(draw.federal1stPrize || "0") % draw.soldTickets) + 1).padStart(3, "0")}</span>
                  ) : (
                    <span style={{ color: "var(--cream3)", fontSize: 12 }}>—</span>
                  )}
                </div>

                {/* Action */}
                <div style={{ width: 100, textAlign: "center" }}>
                  {draw.status === "ended" && draw.federal1stPrize ? (
                    <button
                      onClick={() => autoFill(draw)}
                      style={s.validateBtn}
                    >
                      ⚡ Validar
                    </button>
                  ) : (
                    <span style={{ fontSize: 11, color: "var(--cream3)", fontStyle: "italic" }}>
                      🔒 Ativo
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div style={s.pagination}>
              <button
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page <= 1}
                style={s.pageBtn}
              >
                ← Anterior
              </button>
              <span style={s.pageInfo}>
                Página <strong style={{ color: "var(--gold)" }}>{page}</strong> de {totalPages}
              </span>
              <button
                onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                disabled={page >= totalPages}
                style={s.pageBtn}
              >
                Próxima →
              </button>
            </div>
          )}
        </section>
      </div>

      {/* Styles */}
      <style jsx global>{`
        .pf-copy-btn {
          background: var(--dark4);
          border: 1px solid var(--border);
          color: var(--cream3);
          padding: 4px 8px;
          border-radius: 4px;
          font-size: 12px;
          cursor: pointer;
          transition: all 0.2s;
          flex-shrink: 0;
        }
        .pf-copy-btn:hover {
          border-color: var(--gold3);
          color: var(--gold);
        }
        .pf-copied-badge {
          color: var(--green2);
          font-weight: 600;
          font-size: 11px;
        }
        .pf-copy-icon { font-size: 13px; }
        .pf-skeleton-row {
          display: flex !important;
          align-items: center;
          gap: 16px;
          padding: 14px 16px !important;
        }
        .animate-fade-in {
          animation: fadeInUp 0.5s ease forwards;
        }
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(12px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}

function TrustBadge({ icon, label }: { icon: string; label: string }) {
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 6,
      background: "rgba(212,175,55,0.05)", border: "1px solid var(--border)",
      borderRadius: 6, padding: "6px 14px", fontSize: 12,
      color: "var(--cream2)", letterSpacing: 0.5,
    }}>
      <span>{icon}</span>
      <span style={{ fontFamily: "var(--font-title)", fontSize: 10, letterSpacing: 1.5, textTransform: "uppercase" as const }}>{label}</span>
    </div>
  );
}

function StepCard({ step, icon, title, desc }: { step: string; icon: string; title: string; desc: string }) {
  return (
    <div style={{
      background: "var(--dark3)", border: "1px solid var(--border)", borderRadius: 10,
      padding: 24, position: "relative", overflow: "hidden",
      transition: "border-color 0.3s, box-shadow 0.3s",
    }}
    onMouseEnter={(e) => {
      e.currentTarget.style.borderColor = "var(--gold3)";
      e.currentTarget.style.boxShadow = "0 0 24px rgba(212,175,55,0.08)";
    }}
    onMouseLeave={(e) => {
      e.currentTarget.style.borderColor = "var(--border)";
      e.currentTarget.style.boxShadow = "none";
    }}
    >
      <span style={{
        position: "absolute", top: 12, right: 16,
        fontFamily: "var(--font-title)", fontSize: 36, color: "var(--gold3)", opacity: 0.12,
        fontWeight: 800,
      }}>{step}</span>
      <span style={{ fontSize: 28, marginBottom: 12, display: "block" }}>{icon}</span>
      <h3 style={{ fontFamily: "var(--font-title)", color: "var(--gold)", fontSize: 15, marginBottom: 8, letterSpacing: 1 }}>{title}</h3>
      <p style={{ fontSize: 13, color: "var(--cream3)", lineHeight: 1.6 }}>{desc}</p>
    </div>
  );
}

const s: Record<string, React.CSSProperties> = {
  page: { minHeight: "100vh", background: "var(--dark)", color: "var(--cream)" },
  hero: {
    background: "linear-gradient(180deg, var(--dark2) 0%, var(--dark) 100%)",
    borderBottom: "1px solid var(--border)",
    padding: "56px 20px 40px",
    textAlign: "center",
  },
  heroTitle: {
    fontFamily: "var(--font-title)", color: "var(--gold)",
    fontSize: "clamp(22px, 4vw, 36px)", letterSpacing: 4, fontWeight: 800,
    textShadow: "0 0 30px rgba(212,175,55,0.2)",
  },
  heroSub: { color: "var(--cream3)", fontSize: 14, fontStyle: "italic", marginTop: 6, fontFamily: "'Crimson Text', serif" },
  heroDivider: { display: "flex", alignItems: "center", gap: 12, maxWidth: 380, margin: "20px auto 16px" },
  divLine: { flex: 1, height: 1, background: "linear-gradient(90deg, transparent, #5a4318, transparent)" },
  trustRow: { display: "flex", justifyContent: "center", gap: 10, flexWrap: "wrap" as const, marginTop: 8 },

  container: { maxWidth: 960, margin: "0 auto", padding: "48px 20px" },
  sectionTitle: {
    fontFamily: "var(--font-title)", color: "var(--gold)", fontSize: "clamp(16px, 3vw, 22px)",
    textAlign: "center" as const, marginBottom: 8, letterSpacing: 2.5,
  },
  sectionSub: { textAlign: "center" as const, color: "var(--cream3)", fontSize: 13, fontStyle: "italic", marginBottom: 28, fontFamily: "'Crimson Text', serif" },

  stepsGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 16 },

  verifierCard: {
    background: "var(--dark3)", border: "1px solid var(--border2)", borderRadius: 12,
    padding: "28px 24px",
    boxShadow: "0 4px 40px rgba(0,0,0,0.3), inset 0 1px 0 rgba(212,175,55,0.04)",
  },
  fieldGroup: { display: "flex", flexDirection: "column" as const, gap: 6 },
  label: {
    fontSize: 12, color: "var(--cream2)", fontFamily: "var(--font-title)",
    letterSpacing: 0.8, display: "flex", alignItems: "center",
  },
  monoInput: { fontFamily: "monospace", fontSize: 13, flex: 1 },

  errorBox: {
    background: "rgba(180,30,30,0.12)", border: "1px solid var(--red)",
    color: "#e57373", borderRadius: 8, padding: "10px 14px", fontSize: 13,
  },
  successBox: {
    background: "rgba(39, 174, 96, 0.08)", border: "1px solid var(--green2)",
    color: "#a3e2bc", borderRadius: 8, padding: "10px 14px", fontSize: 13,
  },

  resultCard: {
    background: "var(--dark3)", border: "1px solid var(--border2)", borderRadius: 12,
    padding: 28, marginTop: 20,
    boxShadow: "0 4px 40px rgba(0,0,0,0.3), inset 0 1px 0 rgba(212,175,55,0.04)",
  },
  calcGrid: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, padding: "16px 0", borderTop: "1px solid var(--border)", marginTop: 8 },
  calcBox: { display: "flex", flexDirection: "column" as const, gap: 4 },
  calcLabel: { fontSize: 11, color: "var(--cream3)", textTransform: "uppercase" as const, letterSpacing: 1 },
  calcValue: { fontFamily: "var(--font-title)", color: "var(--gold)", fontSize: 18 },

  winnerBox: {
    background: "rgba(39,174,96,0.06)", border: "1px solid var(--green2)",
    borderRadius: 10, padding: 24, textAlign: "center" as const, marginTop: 16,
  },
  winnerLabel: {
    display: "block", fontSize: 11, color: "var(--green2)",
    letterSpacing: 2, textTransform: "uppercase" as const, fontWeight: 700, marginBottom: 6,
  },
  winnerNumber: {
    display: "block", fontFamily: "var(--font-title)", fontSize: 44, color: "var(--gold)",
    fontWeight: 800, textShadow: "0 0 30px rgba(212,175,55,0.3)",
  },
  winnerFormula: { display: "block", fontSize: 13, color: "var(--cream3)", fontStyle: "italic", marginTop: 8, fontFamily: "'Crimson Text', serif" },

  /* History */
  historyControls: {
    display: "flex", gap: 12, marginBottom: 16, flexWrap: "wrap" as const,
    alignItems: "center", justifyContent: "space-between",
  },
  searchBox: {
    display: "flex", alignItems: "center", gap: 8,
    background: "var(--dark3)", border: "1px solid var(--border)",
    borderRadius: 8, padding: "0 12px", flex: 1, minWidth: 200, maxWidth: 360,
  },
  searchInput: {
    background: "transparent", border: "none", color: "var(--cream)",
    padding: "10px 0", fontSize: 13, flex: 1, outline: "none",
    fontFamily: "var(--font-body)",
  },
  filterBtns: { display: "flex", gap: 6 },
  filterBtn: {
    background: "var(--dark3)", border: "1px solid var(--border)",
    color: "var(--cream3)", padding: "7px 14px", borderRadius: 6,
    fontSize: 11, fontFamily: "var(--font-title)", letterSpacing: 1,
    cursor: "pointer", transition: "all 0.2s", textTransform: "uppercase" as const,
  },
  filterBtnActive: {
    background: "rgba(212,175,55,0.1)",
    borderColor: "var(--gold)",
    color: "var(--gold)",
  },

  historyTable: {
    background: "var(--dark3)", border: "1px solid var(--border)", borderRadius: 10,
    overflow: "hidden", display: "flex", flexDirection: "column" as const,
  },
  historyHeader: {
    display: "flex", background: "var(--dark2)", borderBottom: "1px solid var(--border)",
    padding: "14px 16px", color: "var(--cream3)", fontSize: 11,
    fontFamily: "var(--font-title)", letterSpacing: 1.2, textTransform: "uppercase" as const,
  },
  historyRow: {
    display: "flex", borderBottom: "1px solid var(--border)", padding: "14px 16px",
    alignItems: "center", transition: "background 0.2s",
  },
  rowTitle: { color: "var(--cream2)", fontSize: 14, fontWeight: 600 },
  rowDate: { color: "var(--cream3)", fontSize: 11 },
  winnerTag: {
    background: "rgba(39, 174, 96, 0.12)", border: "1px solid var(--green2)",
    color: "var(--green2)", borderRadius: 4, padding: "3px 8px", fontSize: 12,
    fontFamily: "var(--font-title)", fontWeight: "bold", display: "inline-block",
  },
  validateBtn: {
    background: "linear-gradient(180deg, #d4af37 0%, #8a6a10 100%)", border: "none",
    color: "#0a0704", borderRadius: 4, padding: "6px 12px", fontSize: 11,
    fontFamily: "var(--font-title)", fontWeight: "bold", cursor: "pointer",
    boxShadow: "0 2px 6px rgba(212,175,55,0.2)", transition: "all 0.2s",
  },
  emptyHistory: { padding: "48px 16px", textAlign: "center" as const, display: "flex", flexDirection: "column" as const, alignItems: "center" },

  pagination: { display: "flex", justifyContent: "center", alignItems: "center", gap: 16, marginTop: 24 },
  pageBtn: {
    background: "var(--dark3)", border: "1px solid var(--border)", color: "var(--cream)",
    padding: "8px 16px", borderRadius: 6, fontSize: 12, cursor: "pointer", transition: "all 0.2s",
  },
  pageInfo: { fontSize: 13, color: "var(--cream3)" },
};
