import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// This route reads query params from request.url — must be dynamic
export const dynamic = "force-dynamic";

/**
 * GET /api/draw-history
 * Returns paginated, auditable raffle draw history.
 *
 * SECURITY RULES:
 *  - serverSeed is NEVER exposed for raffles with status === "active"
 *  - serverSeed is revealed ONLY after a raffle has ended (status !== "active")
 *  - serverSeedHash is always safe to expose (pre-commitment, cannot be reverse-engineered)
 *
 * Query params:
 *  - page: number (default 1)
 *  - limit: number (default 10, max 50)
 *  - status: "active" | "ended" | "all" (default "all")
 *  - search: string (searches raffle title)
 */
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);

    const page = Math.max(1, parseInt(searchParams.get("page") ?? "1", 10));
    const limit = Math.min(50, Math.max(1, parseInt(searchParams.get("limit") ?? "10", 10)));
    const statusFilter = searchParams.get("status") ?? "all";
    const search = (searchParams.get("search") ?? "").trim();

    const skip = (page - 1) * limit;

    // Build where clause
    const where: Record<string, unknown> = {};

    if (statusFilter === "active") {
      where.status = "active";
    } else if (statusFilter === "ended") {
      where.status = { not: "active" };
    }

    if (search) {
      where.title = { contains: search, mode: "insensitive" };
    }

    const [total, raffles] = await Promise.all([
      prisma.raffle.count({ where }),
      prisma.raffle.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: "desc" },
        select: {
          id: true,
          title: true,
          description: true,
          status: true,
          totalTickets: true,
          soldTickets: true,
          winner: true,
          createdAt: true,
          federalContest: true,
          federalDrawDate: true,
          federal1stPrize: true,
        },
      }),
    ]);

    // Apply strict security filter
    const safeRaffles = raffles.map((r) => ({
      id: r.id,
      title: r.title,
      description: r.description,
      status: r.status,
      totalTickets: r.totalTickets,
      soldTickets: r.soldTickets,
      createdAt: r.createdAt,
      federalContest: (r as any).federalContest ?? null,
      federalDrawDate: (r as any).federalDrawDate ?? null,
      federal1stPrize: (r as any).federal1stPrize ?? null,
      winner: r.winner ?? null,
    }));

    return NextResponse.json({
      draws: safeRaffles,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
        hasNext: page * limit < total,
        hasPrev: page > 1,
      },
    });
  } catch (err) {
    console.error("[draw-history] error:", err);
    return NextResponse.json(
      { error: "Erro ao buscar histórico de sorteios." },
      { status: 500 }
    );
  }
}
