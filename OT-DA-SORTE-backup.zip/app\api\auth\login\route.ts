import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import bcrypt from "bcryptjs";
import { generateToken } from "@/lib/auth";
import { checkRateLimit } from "@/lib/rate-limit";

export async function POST(req: Request) {
  try {
    // 1. Rate Limiting Check
    const ip = req.headers.get("x-forwarded-for") || "127.0.0.1";
    const isRateAllowed = checkRateLimit(ip, 10, 60 * 1000); // 10 logins per minute per IP
    if (!isRateAllowed) {
      return NextResponse.json(
        { error: "Muitas tentativas. Por favor, aguarde um minuto." },
        { status: 429 }
      );
    }

    const { email, password } = await req.json();

    if (!email || !password) {
      return NextResponse.json({ error: "Email e senha são obrigatórios" }, { status: 400 });
    }

    const user = await prisma.user.findUnique({ where: { email } });

    if (!user) {
      return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 });
    }

    // Check if email is verified (skip check for admin accounts)
    if (!user.emailVerified && user.role !== "admin" && user.role !== "ADMIN") {
      return NextResponse.json(
        { error: "E-mail não confirmado. Por favor, confirme seu e-mail na sua caixa de entrada para poder logar." },
        { status: 403 }
      );
    }

    // 2. Brute Force Lockout Verification
    const now = new Date();
    if (user.lockUntil && user.lockUntil > now) {
      const remainingMinutes = Math.ceil((user.lockUntil.getTime() - now.getTime()) / (60 * 1000));
      return NextResponse.json(
        { error: `Conta temporariamente bloqueada. Tente novamente em ${remainingMinutes} minutos.` },
        { status: 403 }
      );
    }

    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
      // 3. Handle Login Failure (Increment Attempts & Lockout)
      const newAttempts = user.failedAttempts + 1;
      let lockUntil: Date | null = null;
      let msg = "Senha incorreta.";

      if (newAttempts >= 5) {
        lockUntil = new Date(Date.now() + 15 * 60 * 1000); // Lock for 15 minutes
        msg = "Senha incorreta. Limite de tentativas excedido, conta bloqueada por 15 minutos.";
      } else {
        msg = `Senha incorreta. Você tem mais ${5 - newAttempts} tentativas antes do bloqueio.`;
      }

      await prisma.user.update({
        where: { id: user.id },
        data: {
          failedAttempts: newAttempts,
          lockUntil: lockUntil,
        },
      });

      return NextResponse.json({ error: msg }, { status: 401 });
    }

    // 4. Successful Authentication (Reset failed attempts)
    if (user.failedAttempts > 0 || user.lockUntil) {
      await prisma.user.update({
        where: { id: user.id },
        data: {
          failedAttempts: 0,
          lockUntil: null,
        },
      });
    }

    const token = generateToken({
      id: user.id,
      email: user.email,
      username: user.username,
      role: user.role,
    });

    const response = NextResponse.json({
      success: true,
      user: { id: user.id, email: user.email, username: user.username, role: user.role },
    });

    response.cookies.set("token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7, // 7 dias
      path: "/",
    });

    return response;
  } catch (err) {
    console.error("[login]", err);
    return NextResponse.json({ error: "Erro interno" }, { status: 500 });
  }
}
