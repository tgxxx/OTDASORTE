import { NextRequest, NextResponse } from "next/server";
import { verifyToken } from "@/lib/auth";
import prisma from "@/lib/prisma";

export async function GET(req: NextRequest) {
  const token = req.cookies.get("token")?.value;
  if (!token) return NextResponse.json({ error: "Nao autenticado" }, { status: 401 });

  const decoded = verifyToken(token);
  if (!decoded) return NextResponse.json({ error: "Token invalido" }, { status: 401 });

  const tickets = await prisma.ticket.findMany({
    where: { userId: decoded.id },
    include: { raffle: { select: { title: true, status: true } } },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json({ tickets });
}
