"use client";

import { useEffect, useState } from "react";

interface FeedItem {
  username: string;
  raffle: string;
  number: number;
  time: string;
}

export default function LiveFeed() {
  const [feed, setFeed] = useState<FeedItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchFeed();
    const interval = setInterval(fetchFeed, 6000); // Poll every 6 seconds
    return () => clearInterval(interval);
  }, []);

  async function fetchFeed() {
    try {
      const res = await fetch("/api/live-feed");
      if (res.ok) {
        const data = await res.json();
        setFeed(data.feed || []);
      }
    } catch (err) {
      console.error("[live-feed-polling]", err);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card card-gold">
      <h3 className="card-title" style={{ display: "flex", alignItems: "center", gap: "8px", margin: 0, marginBottom: "16px" }}>
        <div className="live-feed-dot" />
        ATIVIDADE EM TEMPO REAL
      </h3>

      {loading && feed.length === 0 ? (
        <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
          <div className="skeleton skeleton-text" style={{ height: "34px", width: "100%", margin: 0 }} />
          <div className="skeleton skeleton-text" style={{ height: "34px", width: "100%", margin: 0 }} />
          <div className="skeleton skeleton-text" style={{ height: "34px", width: "100%", margin: 0 }} />
        </div>
      ) : feed.length === 0 ? (
        <p style={{ color: "var(--cream3)", fontSize: "13px", fontStyle: "italic", textAlign: "center", padding: "12px" }}>
          Silêncio no Reino. Aguardando próximas jogadas...
        </p>
      ) : (
        <div className="live-feed">
          {feed.map((item, i) => (
            <div key={i} className="live-feed-item">
              <span style={{ color: "var(--gold)", fontWeight: "bold" }}>{item.username}</span>
              <span>comprou bilhete</span>
              <span
                style={{
                  background: "var(--dark4)",
                  border: "1px solid var(--border)",
                  borderRadius: "4px",
                  padding: "2px 6px",
                  fontFamily: "var(--font-title)",
                  color: "var(--cream2)",
                  fontSize: "10px",
                }}
              >
                #{String(item.number).padStart(3, "0")}
              </span>
              <span style={{ color: "var(--cream2)" }}>na rifa {item.raffle}</span>
              <span style={{ fontSize: "10px", color: "var(--cream3)", marginLeft: "auto", opacity: 0.7 }}>
                {new Date(item.time).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}