export async function verifyTurnstile(
  token: string
) {

  const response = await fetch(

    "https://challenges.cloudflare.com/turnstile/v0/siteverify",

    {
      method: "POST",

      body: new URLSearchParams({

        secret:
          process.env
          .TURNSTILE_SECRET_KEY!,

        response: token
      })
    }
  );

  return response.json();
}