"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { GoldenHelmetIcon } from "@/components/Navbar";

interface Raffle {
  id: string;
  title: string;
  description: string;
  image?: string;
  price: number;
  totalTickets: number;
  soldTickets: number;
  status: string;
}

export default function Rifas() {
  const [raffles, setRaffles] = useState<Raffle[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/raffles")
      .then((r) => r.json())
      .then((data) => {
        setRaffles(Array.isArray(data) ? data : []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const active = raffles.filter((r) => r.status === "active");
  const ended = raffles.filter((r) => r.status !== "active");

  return (
    <div style={{ minHeight: "100vh", background: "var(--dark)", color: "var(--cream)" }}>
      {/* Hero Banner */}
      <div
        style={{
          background: "linear-gradient(180deg, var(--dark2) 0%, var(--dark) 100%)",
          borderBottom: "1px solid var(--border)",
          padding: "56px 20px 48px",
          textAlign: "center",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <div style={{ display: "flex", justifyContent: "center", marginBottom: "16px" }}>
          <GoldenHelmetIcon size={56} />
        </div>
        <h1 style={{ fontFamily: "var(--font-title)", color: "var(--gold)", fontSize: "clamp(24px, 4vw, 38px)", letterSpacing: "3px", fontWeight: "800" }}>
          RIFAS DO REINO
        </h1>
        <p style={{ color: "var(--cream3)", fontSize: "14px", fontStyle: "italic", marginTop: "6px" }}>
          Escolha suas rifas ativas, adquira seus bilhetes e concorra a itens de poder lendário!
        </p>
      </div>

      <div className="container" style={{ padding: "48px 20px" }}>
        {loading && (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "24px" }}>
            <div className="skeleton skeleton-card" />
            <div className="skeleton skeleton-card" />
            <div className="skeleton skeleton-card" />
          </div>
        )}

        {!loading && active.length === 0 && (
          <div className="empty-state">
            <div className="empty-state-icon">🔮</div>
            <div className="empty-state-title">Nenhuma Rifa Ativa</div>
            <div className="empty-state-text" style={{ marginBottom: "20px" }}>
              Todos os prêmios do reino foram conquistados! Volte em breve para novos desafios.
            </div>
          </div>
        )}

        {active.length > 0 && (
          <>
            <h2 style={{ fontFamily: "var(--font-title)", color: "var(--gold)", fontSize: "16px", letterSpacing: "2.5px", marginBottom: "24px" }}>
              ✦ RIFAS DISPONÍVEIS
            </h2>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "24px" }}>
              {active.map((raffle) => (
                <RaffleCard key={raffle.id} raffle={raffle} />
              ))}
            </div>
          </>
        )}

        {ended.length > 0 && (
          <>
            <h2 style={{ fontFamily: "var(--font-title)", color: "var(--gold)", fontSize: "16px", letterSpacing: "2.5px", marginBottom: "24px", marginTop: "56px", opacity: 0.6 }}>
              ✦ SORTEIOS CONCLUÍDOS
            </h2>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "24px", opacity: 0.75 }}>
              {ended.map((raffle) => (
                <RaffleCard key={raffle.id} raffle={raffle} ended />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function RaffleCard({ raffle, ended }: { raffle: Raffle; ended?: boolean }) {
  const pct = Math.round((raffle.soldTickets / raffle.totalTickets) * 100);
  return (
    <div className="card card-gold" style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      {raffle.image ? (
        <img
          src={raffle.image}
          alt={raffle.title}
          style={{ width: "100%", height: "190px", objectFit: "cover", borderBottom: "1.5px solid var(--border)" }}
          onError={(e) => {
            (e.target as HTMLImageElement).src = "https://i.imgur.com/8Fk3UeA.png";
          }}
        />
      ) : (
        <div
          style={{
            width: "100%",
            height: "190px",
            background: "var(--dark2)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "48px",
            borderBottom: "1.5px solid var(--border)",
          }}
        >
          🏆
        </div>
      )}
      
      <div style={{ padding: "20px", display: "flex", flexDirection: "column", gap: "12px", flex: 1 }}>
        <h3 style={{ fontSize: "16px", color: "var(--gold)", margin: 0 }}>{raffle.title}</h3>
        <p style={{ color: "var(--cream3)", fontSize: "13px", margin: 0, flex: 1, lineHeight: "1.4" }}>{raffle.description}</p>

        {/* Progress Tracker */}
        <div style={{ margin: "8px 0" }}>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: "11px", marginBottom: "4px", color: "var(--cream3)" }}>
            <span>Progresso de Venda</span>
            <span>{pct}%</span>
          </div>
          <div className="progress-track" style={{ height: "6px" }}>
            <div className="progress-fill" style={{ width: `${pct}%` }} />
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: "10px", color: "var(--cream3)", marginTop: "4px" }}>
            <span>{raffle.soldTickets} vendidos</span>
            <span>meta: {raffle.totalTickets}</span>
          </div>
        </div>

        {/* Price Tag */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            background: "var(--dark4)",
            border: "1px solid var(--border)",
            borderRadius: "var(--radius-sm)",
            padding: "8px 12px",
          }}
        >
          <span style={{ fontSize: "12px", color: "var(--cream3)", textTransform: "uppercase", letterSpacing: "1px" }}>Por Ticket</span>
          <strong style={{ fontFamily: "var(--font-title)", color: "var(--gold)", fontSize: "16px" }}>
            R$ {raffle.price.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
          </strong>
        </div>

        {!ended ? (
          <Link href={`/?raffle=${raffle.id}`} className="btn btn-gold btn-full" style={{ marginTop: "6px" }}>
            ⚡ PARTICIPAR
          </Link>
        ) : (
          <button className="btn btn-outline btn-full" style={{ marginTop: "6px", cursor: "default" }} disabled>
            ENCERRADA
          </button>
        )}
      </div>
    </div>
  );
}
