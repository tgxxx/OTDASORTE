"use client";

import { useEffect, useState } from "react";
import { GoldenHelmetIcon } from "@/components/Navbar";

interface Player {
  id: string;
  username: string;
  xp: number;
  level: number;
  avatar?: string;
  _count: { tickets: number };
}

const MEDALS = ["🥇", "🥈", "🥉"];

export default function Ranking() {
  const [players, setPlayers] = useState<Player[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/ranking")
      .then((r) => r.json())
      .then((d) => {
        setPlayers(d.users ?? []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  return (
    <div style={{ minHeight: "100vh", background: "var(--dark)", color: "var(--cream)" }}>
      {/* Hero Banner */}
      <div
        style={{
          background: "linear-gradient(180deg, var(--dark2) 0%, var(--dark) 100%)",
          borderBottom: "1px solid var(--border)",
          padding: "56px 20px 48px",
          textAlign: "center",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <div style={{ display: "flex", justifyContent: "center", marginBottom: "16px" }}>
          <GoldenHelmetIcon size={56} />
        </div>
        <h1 style={{ fontFamily: "var(--font-title)", color: "var(--gold)", fontSize: "clamp(24px, 4vw, 38px)", letterSpacing: "3px", fontWeight: "800" }}>
          HALL DA FAMA
        </h1>
        <p style={{ color: "var(--cream3)", fontSize: "14px", fontStyle: "italic", marginTop: "6px" }}>
          Os maiores aventureiros e heróis lendários do Reino de OT da Sorte
        </p>
      </div>

      <div className="container-sm" style={{ padding: "48px 20px", display: "flex", flexDirection: "column", gap: "12px" }}>
        
        {loading && (
          <>
            <div className="skeleton" style={{ height: "74px", borderRadius: "var(--radius-md)" }} />
            <div className="skeleton" style={{ height: "74px", borderRadius: "var(--radius-md)" }} />
            <div className="skeleton" style={{ height: "74px", borderRadius: "var(--radius-md)" }} />
          </>
        )}

        {!loading && players.length === 0 && (
          <div className="empty-state">
            <div className="empty-state-icon">🛡️</div>
            <div className="empty-state-title">Nenhum Herói Encontrado</div>
            <div className="empty-state-text">
              Ainda não há heróis lendários no Hall da Fama. Seja o primeiro a dominar o reino!
            </div>
          </div>
        )}

        {!loading && players.map((p, i) => {
          const isTop3 = i < 3;
          const topClass = i === 0 ? "gold" : i === 1 ? "silver" : i === 2 ? "bronze" : "";

          return (
            <div key={p.id} className={`rank-card ${topClass}`}>
              {/* Rank Position */}
              <div style={{ minWidth: "36px", textAlign: "center" }}>
                {isTop3 ? (
                  <span style={{ fontSize: "28px" }}>{MEDALS[i]}</span>
                ) : (
                  <span style={{ fontFamily: "var(--font-title)", color: "var(--cream3)", fontSize: "14px" }}>
                    #{i + 1}
                  </span>
                )}
              </div>

              {/* Player Avatar */}
              {p.avatar ? (
                <img
                  src={p.avatar}
                  alt={p.username}
                  style={{
                    width: "40px",
                    height: "40px",
                    borderRadius: "50%",
                    border: `1.5px solid ${isTop3 ? "var(--gold)" : "var(--border2)"}`,
                    objectFit: "cover",
                  }}
                />
              ) : (
                <div
                  style={{
                    width: "40px",
                    height: "40px",
                    borderRadius: "50%",
                    background: "var(--dark2)",
                    border: `1.5px solid ${isTop3 ? "var(--gold)" : "var(--border2)"}`,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontFamily: "var(--font-title)",
                    color: "var(--gold)",
                    fontSize: "18px",
                    fontWeight: 700,
                  }}
                >
                  {p.username[0].toUpperCase()}
                </div>
              )}

              {/* Player Name and Description */}
              <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: "2px" }}>
                <span style={{ fontFamily: "var(--font-title)", color: isTop3 ? "var(--gold)" : "var(--cream2)", fontSize: "15px", fontWeight: isTop3 ? "bold" : "normal" }}>
                  {p.username}
                </span>
                <span style={{ color: "var(--cream3)", fontSize: "12px" }}>
                  Nível {p.level} · {p._count.tickets} bilhetes comprados
                </span>
              </div>

              {/* Player XP */}
              <div style={{ textAlign: "right", display: "flex", flexDirection: "column", alignItems: "flex-end" }}>
                <span style={{ fontFamily: "var(--font-title)", color: "var(--gold)", fontSize: "18px", fontWeight: "bold" }}>
                  {p.xp.toLocaleString("pt-BR")}
                </span>
                <span style={{ color: "var(--gold3)", fontSize: "10px", letterSpacing: "1.5px", textTransform: "uppercase" }}>
                  XP
                </span>
              </div>

              {/* Bottom accent line for top player */}
              {i === 0 && <div className="rank-bar" />}
            </div>
          );
        })}
      </div>
    </div>
  );
}
