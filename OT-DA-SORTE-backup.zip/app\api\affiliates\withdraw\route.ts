import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { verifyToken } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    // 1. Verify Authentication
    const token = req.cookies.get("token")?.value;
    if (!token) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
    }

    const decoded = verifyToken(token);
    if (!decoded) {
      return NextResponse.json({ error: "Sessão inválida" }, { status: 401 });
    }

    // 2. Parse request fields
    const { amount, pixKey } = await req.json();

    if (!amount || !pixKey) {
      return NextResponse.json({ error: "Valor e Chave PIX são obrigatórios" }, { status: 400 });
    }

    const withdrawalAmount = Number(amount);
    if (isNaN(withdrawalAmount) || withdrawalAmount <= 0) {
      return NextResponse.json({ error: "Valor de saque inválido" }, { status: 400 });
    }

    // 3. Retrieve user
    const user = await prisma.user.findUnique({
      where: { id: decoded.id }
    });

    if (!user) {
      return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 });
    }

    // 4. Validate commission balance
    if (user.commissionBalance < withdrawalAmount) {
      return NextResponse.json({ error: "Saldo de comissão insuficiente para este saque" }, { status: 400 });
    }

    // 5. Atomic transaction to request payout
    await prisma.$transaction([
      prisma.user.update({
        where: { id: user.id },
        data: { commissionBalance: { decrement: withdrawalAmount } }
      }),
      prisma.commissionWithdrawal.create({
        data: {
          userId: user.id,
          amount: withdrawalAmount,
          pixKey: pixKey,
          status: "PENDING"
        }
      })
    ]);

    return NextResponse.json({
      success: true,
      message: "Solicitação de saque enviada com sucesso! Aguarde o processamento pela administração."
    });
  } catch (err) {
    console.error("[affiliate-withdraw]", err);
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 });
  }
}
