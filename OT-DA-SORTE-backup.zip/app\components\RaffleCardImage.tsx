"use client";

interface RaffleCardImageProps {
  src: string;
  alt: string;
}

const imgStyle: React.CSSProperties = {
  width: "80px",
  height: "80px",
  objectFit: "contain",
  borderRadius: 4,
  background: "#110e08",
  border: "1px solid #5a4318",
  padding: 4,
  flexShrink: 0,
};

const fallbackStyle: React.CSSProperties = {
  width: "80px",
  height: "80px",
  background: "#110e08",
  border: "1px dashed #5a4318",
  borderRadius: 4,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  fontSize: 32,
  flexShrink: 0,
};

export default function RaffleCardImage({ src, alt }: RaffleCardImageProps) {
  if (!src) {
    return <div style={fallbackStyle}>🏆</div>;
  }

  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={src}
      alt={alt}
      style={imgStyle}
      onError={(e) => {
        (e.target as HTMLImageElement).src = "https://i.imgur.com/8Fk3UeA.png";
      }}
    />
  );
}
