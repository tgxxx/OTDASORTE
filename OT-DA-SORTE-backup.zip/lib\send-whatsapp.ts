import twilio from "twilio";

/**
 * Sends a WhatsApp message using configured provider: Evolution API, Meta Cloud API, Twilio, or fallback to Console logging.
 * 
 * Env variables required for each:
 * 
 * 1. Evolution API:
 *    - EVOLUTION_API_URL: e.g. "https://api.evolution.example.com"
 *    - EVOLUTION_API_KEY: "your-api-key"
 *    - EVOLUTION_API_INSTANCE: "instance-name"
 * 
 * 2. Meta WhatsApp Cloud API:
 *    - META_WA_URL: e.g. "https://graph.facebook.com/v17.0/PHONE_NUMBER_ID/messages"
 *    - META_WA_TOKEN: "your-facebook-token"
 * 
 * 3. Twilio:
 *    - TWILIO_ACCOUNT_SID
 *    - TWILIO_AUTH_TOKEN
 *    - TWILIO_WHATSAPP_NUMBER
 */
export async function sendWhatsApp(to: string, message: string) {
  // Format phone number to clean E.164 (ensure only numbers)
  const cleanPhone = to.replace(/\D/g, "");

  // --- 1. Evolution API Integration ---
  if (process.env.EVOLUTION_API_URL && process.env.EVOLUTION_API_KEY && process.env.EVOLUTION_API_INSTANCE) {
    try {
      const url = `${process.env.EVOLUTION_API_URL}/message/sendText/${process.env.EVOLUTION_API_INSTANCE}`;
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "apikey": process.env.EVOLUTION_API_KEY
        },
        body: JSON.stringify({
          number: cleanPhone,
          options: {
            delay: 1200,
            presence: "composing",
            linkPreview: true
          },
          textMessage: {
            text: message
          }
        })
      });
      if (response.ok) {
        console.log(`[Evolution API] Mensagem enviada para ${cleanPhone}`);
        return await response.json();
      } else {
        console.error(`[Evolution API Error] Status: ${response.status}`, await response.text());
      }
    } catch (err) {
      console.error("[Evolution API Connection Error]:", err);
    }
  }

  // --- 2. Meta WhatsApp Cloud API Integration ---
  if (process.env.META_WA_URL && process.env.META_WA_TOKEN) {
    try {
      const response = await fetch(process.env.META_WA_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${process.env.META_WA_TOKEN}`
        },
        body: JSON.stringify({
          messaging_product: "whatsapp",
          recipient_type: "individual",
          to: cleanPhone,
          type: "text",
          text: {
            preview_url: false,
            body: message
          }
        })
      });
      if (response.ok) {
        console.log(`[Meta WhatsApp] Mensagem enviada para ${cleanPhone}`);
        return await response.json();
      } else {
        console.error(`[Meta WhatsApp Error] Status: ${response.status}`, await response.text());
      }
    } catch (err) {
      console.error("[Meta WhatsApp Connection Error]:", err);
    }
  }

  // --- 3. Twilio Fallback ---
  if (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_ACCOUNT_SID !== "COLE_AQUI") {
    try {
      const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
      const res = await client.messages.create({
        from: process.env.TWILIO_WHATSAPP_NUMBER || "whatsapp:+14155238886",
        to: `whatsapp:+${cleanPhone}`,
        body: message,
      });
      console.log(`[Twilio WhatsApp] Mensagem enviada para ${cleanPhone}`);
      return res;
    } catch (err) {
      console.error("[Twilio WhatsApp Error]:", err);
    }
  }

  // --- 4. Simulated Local Logging Fallback ---
  console.log("-----------------------------------------");
  console.log(`[WhatsApp Simulado] Para: ${cleanPhone}`);
  console.log(`Mensagem:\n${message}`);
  console.log("-----------------------------------------");
  return { simulated: true, to: cleanPhone, body: message };
}

/**
 * Pre-defined message dispatcher for specific raffle events
 */
export async function sendRafflePurchaseNotification(
  phone: string,
  username: string,
  raffleTitle: string,
  ticketNumbers: number[]
) {
  const message = `⚔️ *OT DA SORTE* ⚔️\n\n` +
    `Olá, *${username}*! Sua jornada foi recompensada! 🛡️\n\n` +
    `Seu pagamento foi confirmado e seus *${ticketNumbers.length}* bilhetes para a rifa *${raffleTitle}* foram condecorados! 🎉\n\n` +
    `🎟️ *Seus Números da Sorte:*\n` +
    `[ ${ticketNumbers.join(", ")} ]\n\n` +
    `Boa sorte na sua conquista, nobre guerreiro! ⚔️⚔️`;
    
  return sendWhatsApp(phone, message);
}

export async function sendWinnerNotification(
  phone: string,
  username: string,
  raffleTitle: string,
  winningNumber: number
) {
  const message = `⚔️ *OT DA SORTE — VENCEDOR!* ⚔️\n\n` +
    `🏆 *PARABÉNS, ${username.toUpperCase()}!* 🏆\n\n` +
    `Os deuses do destino falaram! Seu bilhete número *${winningNumber}* foi sorteado no sistema *Provably Fair* e você é o grande vencedor da rifa *${raffleTitle}*! ⚔️🛡️🔮\n\n` +
    `Entre em contato com nossa administração medieval agora mesmo para resgatar seus itens lendários e Tibia Coins! 💰💎\n\n` +
    `Que sua sorte continue infinita! 👑`;

  return sendWhatsApp(phone, message);
}