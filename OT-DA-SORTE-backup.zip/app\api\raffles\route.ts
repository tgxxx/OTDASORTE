import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { verifyToken } from "@/lib/auth";

// GET - lista todas as rifas ativas
export async function GET() {
  const raffles = await prisma.raffle.findMany({
    orderBy: { createdAt: "desc" },
    include: { _count: { select: { tickets: true } } },
  });
  return NextResponse.json(raffles);
}

// POST - cria uma nova rifa (somente admin)
export async function POST(req: NextRequest) {
  const token = req.cookies.get("token")?.value;
  if (!token) return NextResponse.json({ error: "Nao autenticado" }, { status: 401 });

  const decoded = verifyToken(token);
  if (!decoded || decoded.role !== "ADMIN") {
    return NextResponse.json({ error: "Acesso negado" }, { status: 403 });
  }

  try {
    const { title, description, image, price, totalTickets } = await req.json();

    if (!title || !price || !totalTickets) {
      return NextResponse.json({ error: "Campos obrigatorios: title, price, totalTickets" }, { status: 400 });
    }

    const raffle = await prisma.raffle.create({
      data: { title, description: description ?? "", image: image ?? null, price: Number(price), totalTickets: Number(totalTickets) },
    });

    return NextResponse.json({ success: true, raffle });
  } catch (err) {
    console.error("[raffles POST]", err);
    return NextResponse.json({ error: "Erro interno" }, { status: 500 });
  }
}

// DELETE - exclui uma rifa (somente admin)
export async function DELETE(req: NextRequest) {
  const token = req.cookies.get("token")?.value;
  if (!token) return NextResponse.json({ error: "Nao autenticado" }, { status: 401 });

  const decoded = verifyToken(token);
  if (!decoded || decoded.role !== "ADMIN") {
    return NextResponse.json({ error: "Acesso negado" }, { status: 403 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "ID da rifa nao fornecido" }, { status: 400 });
    }

    // Deleta tickets associados à rifa
    await prisma.ticket.deleteMany({ where: { raffleId: id } });

    // Deleta a rifa
    await prisma.raffle.delete({ where: { id } });

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("[raffles DELETE]", err);
    return NextResponse.json({ error: "Erro ao deletar rifa" }, { status: 500 });
  }
}
