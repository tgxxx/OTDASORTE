import { NextRequest, NextResponse } from "next/server";
import { verifyToken } from "@/lib/auth";
import prisma from "@/lib/prisma";

export async function GET(req: NextRequest) {
  const token = req.cookies.get("token")?.value;
  if (!token) return NextResponse.json({ error: "Nao autenticado" }, { status: 401 });
  const decoded = verifyToken(token);
  if (!decoded || decoded.role !== "ADMIN") return NextResponse.json({ error: "Acesso negado" }, { status: 403 });

  const [users, tickets, payments, raffles] = await Promise.all([
    prisma.user.count(),
    prisma.ticket.count(),
    prisma.payment.findMany({ where: { status: "APPROVED" }, select: { amount: true } }),
    prisma.raffle.count(),
  ]);

  const revenue = payments.reduce((sum, p) => sum + p.amount, 0);

  return NextResponse.json({ users, tickets, revenue, raffles });
}
