import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import prisma from "@/lib/prisma";
import { generateToken } from "@/lib/auth";
import { verifyTurnstile } from "@/lib/turnstile";
import { checkRateLimit } from "@/lib/rate-limit";
import crypto from "crypto";
import { sendVerificationEmail } from "@/lib/email";

export async function POST(req: Request) {
  try {
    // 1. Rate Limiting Check
    const ip = req.headers.get("x-forwarded-for") || "127.0.0.1";
    const isRateAllowed = checkRateLimit(ip, 5, 60 * 1000); // 5 registers per minute per IP
    if (!isRateAllowed) {
      return NextResponse.json(
        { error: "Muitas tentativas. Por favor, aguarde um minuto." },
        { status: 429 }
      );
    }

    const body = await req.json();
    const { username, email, password, captchaToken } = body;

    if (!username || !email || !password) {
      return NextResponse.json({ error: "Todos os campos são obrigatórios" }, { status: 400 });
    }

    if (password.length < 6) {
      return NextResponse.json({ error: "Senha deve ter no mínimo 6 caracteres" }, { status: 400 });
    }

    // 2. Cloudflare Turnstile anti-bot verification
    if (process.env.TURNSTILE_SECRET_KEY && process.env.TURNSTILE_SECRET_KEY !== "COLE_AQUI") {
      if (!captchaToken) {
        return NextResponse.json({ error: "Verificação anti-bot é obrigatória" }, { status: 400 });
      }
      try {
        const captchaRes = await verifyTurnstile(captchaToken);
        if (!captchaRes || !captchaRes.success) {
          return NextResponse.json({ error: "Verificação anti-bot inválida. Tente novamente." }, { status: 400 });
        }
      } catch (err) {
        console.error("Turnstile error:", err);
      }
    }

    const userExists = await prisma.user.findFirst({
      where: { OR: [{ email }, { username }] },
    });

    if (userExists) {
      return NextResponse.json({ error: "Email ou username já cadastrado" }, { status: 400 });
    }

    // 3. Resolve Affiliate referral tracking cookie
    // Cookie string is parsed safely
    let referredById: string | undefined = undefined;
    const cookieHeader = req.headers.get("cookie") || "";
    const refMatch = cookieHeader.match(/(?:^|;)\s*ref=([^;]+)/);
    if (refMatch) {
      const refCode = decodeURIComponent(refMatch[1]);
      const referrer = await prisma.user.findUnique({
        where: { affiliateCode: refCode },
      });
      if (referrer) {
        referredById = referrer.id;
      }
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    // 4. Generate unique affiliate code for the new user
    const generatedAffiliateCode = `${username.toLowerCase().replace(/[^a-z0-9]/g, "")}-${Math.floor(1000 + Math.random() * 9000)}`;

    const verificationToken = crypto.randomBytes(32).toString("hex");
    const verificationTokenExpires = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 horas

    const user = await prisma.user.create({
      data: {
        username,
        email,
        password: hashedPassword,
        affiliateCode: generatedAffiliateCode,
        referredById,
        avatar: `https://api.dicebear.com/7.x/adventurer/svg?seed=${encodeURIComponent(username)}`, // beautiful premium avatar fallback
        emailVerified: false,
        verificationToken,
        verificationTokenExpires,
      },
    });

    // Enviar e-mail de confirmação
    try {
      await sendVerificationEmail(email, username, verificationToken);
    } catch (emailErr) {
      console.error("Erro ao enviar e-mail de verificação:", emailErr);
    }

    const response = NextResponse.json({
      success: true,
      message: "Cadastro efetuado! Um e-mail de verificação foi enviado para sua caixa de entrada. Por favor, confirme-o para ativar sua conta.",
    });

    // Delete ref cookie on successful registration
    response.cookies.delete("ref");

    return response;
  } catch (err) {
    console.error("[register]", err);
    return NextResponse.json({ error: "Erro interno" }, { status: 500 });
  }
}
