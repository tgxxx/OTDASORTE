import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { verifyToken } from "@/lib/auth";

export async function GET(req: NextRequest) {
  try {
    const token = req.cookies.get("token")?.value;
    if (!token) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
    }

    const decoded = verifyToken(token);
    if (!decoded) {
      return NextResponse.json({ error: "Sessão inválida" }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { id: decoded.id },
      select: {
        id: true,
        username: true,
        email: true,
        role: true,
        avatar: true,
        xp: true,
        level: true,
        balance: true,
        commissionBalance: true,
        affiliateCode: true,
        affiliateCommission: true,
        createdAt: true,
        tickets: {
          select: {
            id: true,
            number: true,
            createdAt: true,
            raffle: {
              select: {
                id: true,
                title: true,
                status: true,
                winningTicketNumber: true,
              },
            },
          },
          orderBy: { createdAt: "desc" },
          take: 50,
        },
        referrals: {
          select: {
            id: true,
            username: true,
            createdAt: true,
          },
          orderBy: { createdAt: "desc" },
        },
        commissionEarnings: {
          select: {
            id: true,
            amount: true,
            createdAt: true,
          },
          orderBy: { createdAt: "desc" },
          take: 20,
        },
        withdrawals: {
          select: {
            id: true,
            amount: true,
            status: true,
            createdAt: true,
          },
          orderBy: { createdAt: "desc" },
          take: 20,
        },
        rafflesWon: {
          select: {
            id: true,
            title: true,
            drawDate: true,
            winningTicketNumber: true,
          },
          orderBy: { drawDate: "desc" },
        },
      },
    });

    if (!user) {
      return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 });
    }

    return NextResponse.json({ user });
  } catch (err) {
    console.error("[profile]", err);
    return NextResponse.json({ error: "Erro interno" }, { status: 500 });
  }
}

// PATCH - Update profile fields
export async function PATCH(req: NextRequest) {
  try {
    const token = req.cookies.get("token")?.value;
    if (!token) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
    }

    const decoded = verifyToken(token);
    if (!decoded) {
      return NextResponse.json({ error: "Sessão inválida" }, { status: 401 });
    }

    const { avatar } = await req.json();

    const updated = await prisma.user.update({
      where: { id: decoded.id },
      data: {
        ...(avatar !== undefined ? { avatar } : {}),
      },
      select: {
        id: true,
        username: true,
        avatar: true,
      },
    });

    return NextResponse.json({ success: true, user: updated });
  } catch (err) {
    console.error("[profile update]", err);
    return NextResponse.json({ error: "Erro interno" }, { status: 500 });
  }
}

// DELETE - Delete user account safely and securely
export async function DELETE(req: NextRequest) {
  try {
    const token = req.cookies.get("token")?.value;
    if (!token) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
    }

    const decoded = verifyToken(token);
    if (!decoded) {
      return NextResponse.json({ error: "Sessão inválida" }, { status: 401 });
    }

    const userId = decoded.id;

    // Transação segura para garantir exclusão relacional íntegra
    await prisma.$transaction(async (tx) => {
      // 1. Limpar winnerId nas rifas ganhas para não violar chaves estrangeiras
      await tx.raffle.updateMany({
        where: { winnerId: userId },
        data: { winnerId: null },
      });

      // 2. Limpar referredById nos usuários indicados
      await tx.user.updateMany({
        where: { referredById: userId },
        data: { referredById: null },
      });

      // 3. Deletar Bilhetes comprados
      await tx.ticket.deleteMany({
        where: { userId },
      });

      // 4. Deletar Pagamentos realizados
      await tx.payment.deleteMany({
        where: { userId },
      });

      // 5. Deletar Logs de segurança
      await tx.log.deleteMany({
        where: { userId },
      });

      // 6. Deletar Ganhos de Comissões de Afiliados
      await tx.commissionEarning.deleteMany({
        where: { referrerId: userId },
      });

      // 7. Deletar Solicitações de Saques de Comissões
      await tx.commissionWithdrawal.deleteMany({
        where: { userId },
      });

      // 8. Deletar a conta do Usuário principal
      await tx.user.delete({
        where: { id: userId },
      });
    });

    // Limpar o cookie do token de login
    const response = NextResponse.json({
      success: true,
      message: "Sua conta e todos os dados associados foram excluídos definitivamente do reino.",
    });

    response.cookies.delete("token");

    return response;
  } catch (err) {
    console.error("[profile delete]", err);
    return NextResponse.json({ error: "Erro interno do servidor ao excluir a conta" }, { status: 500 });
  }
}
