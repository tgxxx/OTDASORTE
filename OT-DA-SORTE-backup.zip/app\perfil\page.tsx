"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";

export default function ProfilePage() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<"overview" | "tickets" | "affiliates" | "settings">("overview");
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // Password Change State
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [pwdLoading, setPwdLoading] = useState(false);
  const [pwdMessage, setPwdMessage] = useState("");
  const [pwdError, setPwdError] = useState("");

  // Affiliate Withdrawal State
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [pixKey, setPixKey] = useState("");
  const [wdLoading, setWdLoading] = useState(false);
  const [wdMessage, setWdMessage] = useState("");
  const [wdError, setWdError] = useState("");

  // Copy Alert State
  const [copiedLink, setCopiedLink] = useState(false);

  // Avatar Update State
  const [avatarUrl, setAvatarUrl] = useState("");
  const [avatarLoading, setAvatarLoading] = useState(false);
  const [avatarMessage, setAvatarMessage] = useState("");

  // Account Deletion State
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState("");
  const [deleteLoading, setDeleteLoading] = useState(false);

  useEffect(() => {
    fetchProfile();
  }, []);

  async function fetchProfile() {
    setLoading(true);
    try {
      const res = await fetch("/api/user/profile");
      if (res.status === 401) {
        router.push("/login");
        return;
      }
      if (!res.ok) {
        setError("Erro ao carregar o perfil.");
        return;
      }
      const data = await res.json();
      setUser(data.user);
      setAvatarUrl(data.user.avatar || "");
    } catch (err) {
      setError("Erro de conexão. Tente novamente.");
    } finally {
      setLoading(false);
    }
  }

  async function handlePasswordChange(e: React.FormEvent) {
    e.preventDefault();
    setPwdMessage("");
    setPwdError("");

    if (newPassword !== confirmPassword) {
      setPwdError("As senhas não coincidem.");
      return;
    }

    setPwdLoading(true);
    try {
      const res = await fetch("/api/user/change-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      const data = await res.json();
      if (!res.ok) {
        setPwdError(data.error || "Erro ao alterar a senha.");
      } else {
        setPwdMessage("Senha alterada com sucesso!");
        setCurrentPassword("");
        setNewPassword("");
        setConfirmPassword("");
      }
    } catch {
      setPwdError("Erro de rede. Tente novamente.");
    } finally {
      setPwdLoading(false);
    }
  }

  async function handleWithdrawal(e: React.FormEvent) {
    e.preventDefault();
    setWdMessage("");
    setWdError("");

    const amountNum = parseFloat(withdrawAmount);
    if (isNaN(amountNum) || amountNum <= 0) {
      setWdError("Informe um valor de saque válido.");
      return;
    }

    if (!pixKey.trim()) {
      setWdError("Chave PIX é obrigatória.");
      return;
    }

    setWdLoading(true);
    try {
      const res = await fetch("/api/affiliates/withdraw", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount: amountNum, pixKey }),
      });
      const data = await res.json();
      if (!res.ok) {
        setWdError(data.error || "Erro ao solicitar saque.");
      } else {
        setWdMessage("Solicitação de saque efetuada com sucesso!");
        setWithdrawAmount("");
        fetchProfile(); // Reload balance and history
      }
    } catch {
      setWdError("Erro de rede. Tente novamente.");
    } finally {
      setWdLoading(false);
    }
  }

  async function handleAvatarFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    setAvatarLoading(true);
    setAvatarMessage("");

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = async () => {
        const canvas = document.createElement("canvas");
        const ctx = canvas.getContext("2d");
        canvas.width = 256;
        canvas.height = 256;

        if (ctx) {
          const size = Math.min(img.width, img.height);
          const sx = (img.width - size) / 2;
          const sy = (img.height - size) / 2;
          ctx.drawImage(img, sx, sy, size, size, 0, 0, 256, 256);
          
          const optimizedDataUrl = canvas.toDataURL("image/jpeg", 0.8);
          setAvatarUrl(optimizedDataUrl);

          try {
            const res = await fetch("/api/user/profile", {
              method: "PATCH",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ avatar: optimizedDataUrl }),
            });
            const data = await res.json();
            if (!res.ok) {
              setAvatarMessage("Erro ao salvar o avatar no reino.");
            } else {
              setAvatarMessage("Retrato de herói atualizado com sucesso!");
              setUser((prev: any) => ({ ...prev, avatar: data.user.avatar }));
            }
          } catch {
            setAvatarMessage("Erro de rede ao salvar retrato.");
          }
        }
        setAvatarLoading(false);
      };
    };
    reader.readAsDataURL(file);
  }

  async function handleAvatarUpdate(e: React.FormEvent) {
    e.preventDefault();
    setAvatarMessage("");
    setAvatarLoading(true);

    try {
      const res = await fetch("/api/user/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ avatar: avatarUrl }),
      });
      const data = await res.json();
      if (!res.ok) {
        setAvatarMessage("Erro ao atualizar avatar.");
      } else {
        setAvatarMessage("Avatar atualizado com sucesso!");
        setUser((prev: any) => ({ ...prev, avatar: data.user.avatar }));
      }
    } catch {
      setAvatarMessage("Erro de rede. Tente novamente.");
    } finally {
      setAvatarLoading(false);
    }
  }

  async function handleDeleteAccount() {
    if (!user) return;
    if (deleteConfirmText.toLowerCase() !== user.username.toLowerCase()) {
      alert("O nome inserido não confere com o seu Nick.");
      return;
    }

    setDeleteLoading(true);
    try {
      const res = await fetch("/api/user/profile", {
        method: "DELETE",
      });
      const data = await res.json();
      if (!res.ok) {
        alert(data.error || "Erro ao excluir a ficha de jogador.");
      } else {
        alert("Sua ficha de jogador foi apagada com sucesso. Até breve, aventureiro!");
        window.location.href = "/";
      }
    } catch {
      alert("Erro de conexão ao excluir conta.");
    } finally {
      setDeleteLoading(false);
    }
  }

  function handleCopyReferralLink() {
    if (!user) return;
    const origin = window.location.origin;
    const refLink = `${origin}?ref=${user.affiliateCode}`;
    navigator.clipboard.writeText(refLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  }

  if (loading) {
    return (
      <div className="container" style={{ padding: "80px 20px" }}>
        <div className="skeleton skeleton-title" style={{ margin: "0 auto 40px", width: "200px" }} />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 3fr", gap: "24px" }}>
          <div className="skeleton skeleton-card" />
          <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
            <div className="skeleton skeleton-text" style={{ height: "40px" }} />
            <div className="skeleton skeleton-card" style={{ height: "300px" }} />
          </div>
        </div>
      </div>
    );
  }

  if (error || !user) {
    return (
      <div className="container" style={{ padding: "80px 20px", textAlign: "center" }}>
        <div className="empty-state">
          <div className="empty-state-icon">⚠️</div>
          <div className="empty-state-title">Erro ao Carregar Perfil</div>
          <div className="empty-state-text" style={{ marginBottom: "24px" }}>{error || "Não foi possível carregar as informações do seu perfil."}</div>
          <button className="btn btn-gold" onClick={fetchProfile}>Tentar Novamente</button>
        </div>
      </div>
    );
  }

  const referralLink = `${typeof window !== "undefined" ? window.location.origin : ""}?ref=${user.affiliateCode}`;
  const nextLevelXp = user.level * 100;
  const xpPercentage = Math.min(100, Math.max(0, Math.round((user.xp / nextLevelXp) * 100)));

  return (
    <div className="container" style={{ padding: "40px 20px" }}>
      {/* Page Title */}
      <div style={{ textAlign: "center", marginBottom: "32px" }}>
        <h1 style={{ fontSize: "32px", textShadow: "0 0 20px rgba(212,175,55,0.25)" }}>FICHA DO JOGADOR</h1>
        <p style={{ color: "var(--cream3)", fontStyle: "italic", marginTop: "6px" }}>Estatísticas, conquistas e configurações da sua jornada</p>
      </div>

      {/* Profile Layout */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: "32px", alignItems: "start" }}>
        {/* Left Side: RPG Character Card */}
        <div className="card card-gold" style={{ position: "sticky", top: "84px", textAlign: "center" }}>
          {/* Avatar Container (Clicável) */}
          <div style={{ position: "relative", display: "inline-block", margin: "0 auto 16px" }}>
            <input
              type="file"
              accept="image/*"
              id="avatar-upload-file"
              style={{ display: "none" }}
              onChange={handleAvatarFileChange}
              disabled={avatarLoading}
            />
            <label
              htmlFor="avatar-upload-file"
              style={{
                display: "block",
                position: "relative",
                cursor: "pointer",
                borderRadius: "50%",
                overflow: "hidden",
                width: "120px",
                height: "120px",
                border: "3px solid var(--gold)",
                boxShadow: "0 0 24px var(--gold-glow)",
              }}
              className="avatar-hover-container"
            >
              {user.avatar ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={user.avatar}
                  alt={user.username}
                  style={{
                    width: "100%",
                    height: "100%",
                    objectFit: "cover",
                    transition: "all 0.2s",
                  }}
                />
              ) : (
                <div
                  style={{
                    width: "100%",
                    height: "100%",
                    background: "var(--dark2)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: "48px",
                    fontFamily: "var(--font-title)",
                    color: "var(--gold)",
                    transition: "all 0.2s",
                  }}
                >
                  {user.username[0].toUpperCase()}
                </div>
              )}
              {/* Overlay escuro em hover */}
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  background: "rgba(10, 7, 4, 0.75)",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  opacity: 0,
                  transition: "opacity 0.2s",
                  fontSize: "10px",
                  color: "var(--gold)",
                  fontFamily: "var(--font-title)",
                  letterSpacing: "1px",
                }}
                className="avatar-overlay"
              >
                <span>📷</span>
                <span style={{ marginTop: "4px" }}>ATUALIZAR</span>
              </div>
            </label>
            <div
              style={{
                position: "absolute",
                bottom: "-6px",
                right: "6px",
                background: "var(--gold)",
                color: "var(--dark)",
                borderRadius: "50%",
                width: "36px",
                height: "36px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontWeight: "bold",
                fontFamily: "var(--font-title)",
                border: "2px solid var(--dark)",
                fontSize: "14px",
                boxShadow: "0 2px 8px rgba(0,0,0,0.5)",
                zIndex: 2,
              }}
              title="Nível do Jogador"
            >
              {user.level}
            </div>
          </div>

          <h2 style={{ fontSize: "22px", color: "var(--gold)", marginBottom: "4px" }}>{user.username}</h2>
          <p style={{ color: "var(--cream3)", fontSize: "14px", marginBottom: "20px" }}>{user.email}</p>

          {/* XP Progress Bar */}
          <div style={{ textAlign: "left", marginBottom: "24px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: "12px", marginBottom: "6px" }}>
              <span style={{ color: "var(--cream3)", fontFamily: "var(--font-title)", letterSpacing: "1px" }}>Experiência (XP)</span>
              <span style={{ color: "var(--gold)" }}>{user.xp} / {nextLevelXp} XP</span>
            </div>
            <div className="progress-track" style={{ height: "10px" }}>
              <div className="progress-fill" style={{ width: `${xpPercentage}%` }} />
            </div>
            <span style={{ fontSize: "11px", color: "var(--cream3)", display: "block", textAlign: "right", marginTop: "4px", fontStyle: "italic" }}>
              {xpPercentage}% para o nível {user.level + 1}
            </span>
          </div>

          {/* RPG Attributes Grid */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px", marginBottom: "20px" }}>
            <div style={{ background: "var(--dark2)", border: "1px solid var(--border)", borderRadius: "var(--radius-sm)", padding: "10px", textAlign: "center" }}>
              <div style={{ fontSize: "10px", color: "var(--cream3)", letterSpacing: "1px", textTransform: "uppercase", marginBottom: "4px" }}>Saldo Principal</div>
              <div style={{ color: "var(--gold)", fontSize: "16px", fontWeight: "bold" }}>
                R$ {user.balance.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
              </div>
            </div>
            <div style={{ background: "var(--dark2)", border: "1px solid var(--border)", borderRadius: "var(--radius-sm)", padding: "10px", textAlign: "center" }}>
              <div style={{ fontSize: "10px", color: "var(--cream3)", letterSpacing: "1px", textTransform: "uppercase", marginBottom: "4px" }}>Saldo de Comissão</div>
              <div style={{ color: "#27ae60", fontSize: "16px", fontWeight: "bold" }}>
                R$ {user.commissionBalance.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
              </div>
            </div>
          </div>

          {/* Joined Date */}
          <p style={{ color: "var(--cream3)", fontSize: "11px", letterSpacing: "1px", textTransform: "uppercase" }}>
            Membro desde {new Date(user.createdAt).toLocaleDateString("pt-BR")}
          </p>
        </div>

        {/* Right Side: Navigation & Tabs */}
        <div style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
          {/* Tabs bar */}
          <div className="tabs">
            <button
              className={`tab ${activeTab === "overview" ? "tab-active" : ""}`}
              onClick={() => setActiveTab("overview")}
            >
              Ficha
            </button>
            <button
              className={`tab ${activeTab === "tickets" ? "tab-active" : ""}`}
              onClick={() => setActiveTab("tickets")}
            >
              Meus Bilhetes
            </button>
            <button
              className={`tab ${activeTab === "affiliates" ? "tab-active" : ""}`}
              onClick={() => setActiveTab("affiliates")}
            >
              Afiliados
            </button>
            <button
              className={`tab ${activeTab === "settings" ? "tab-active" : ""}`}
              onClick={() => setActiveTab("settings")}
            >
              Segurança
            </button>
          </div>

          {/* Tab Content 1: Overview */}
          {activeTab === "overview" && (
            <div className="card" style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
              <h3 className="card-title">Resumo da Jornada</h3>

              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: "16px" }}>
                <div className="stat-box">
                  <div className="stat-label">Bilhetes Comprados</div>
                  <div className="stat-value">{user.tickets.length}</div>
                </div>
                <div className="stat-box">
                  <div className="stat-label">Rifas Vencidas</div>
                  <div className="stat-value">{user.rafflesWon.length}</div>
                </div>
                <div className="stat-box">
                  <div className="stat-label">Total de Indicados</div>
                  <div className="stat-value">{user.referrals.length}</div>
                </div>
              </div>

              {/* Raffles Won Section */}
              {user.rafflesWon.length > 0 ? (
                <div>
                  <h4 style={{ color: "var(--gold)", fontSize: "14px", letterSpacing: "1px", textTransform: "uppercase", marginBottom: "12px" }}>🏆 Conquistas (Rifas Ganhas)</h4>
                  <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                    {user.rafflesWon.map((r: any) => (
                      <div
                        key={r.id}
                        style={{
                          background: "rgba(39, 174, 96, 0.08)",
                          border: "1px solid var(--green2)",
                          borderRadius: "var(--radius-sm)",
                          padding: "16px",
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                        }}
                      >
                        <div>
                          <strong style={{ color: "var(--gold)", display: "block" }}>{r.title}</strong>
                          <span style={{ fontSize: "12px", color: "var(--cream3)" }}>
                            Sorteado em: {new Date(r.drawDate).toLocaleDateString("pt-BR")}
                          </span>
                        </div>
                        <div style={{ textAlign: "right" }}>
                          <span className="badge badge-paid" style={{ display: "inline-block", marginBottom: "4px" }}>Ganhador</span>
                          <span style={{ display: "block", fontSize: "14px", fontFamily: "var(--font-title)", color: "var(--green2)" }}>
                            Bilhete #{String(r.winningTicketNumber).padStart(3, "0")}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div style={{ border: "1px dashed var(--border)", borderRadius: "var(--radius-sm)", padding: "30px", textAlign: "center" }}>
                  <div style={{ fontSize: "36px", marginBottom: "8px" }}>🛡️</div>
                  <strong style={{ color: "var(--cream2)", display: "block", marginBottom: "4px" }}>Nenhum prêmio conquistado ainda</strong>
                  <span style={{ fontSize: "13px", color: "var(--cream3)", fontStyle: "italic" }}>
                    Adquira bilhetes nas rifas ativas para ter a chance de gravar seu nome no Hall da Fama!
                  </span>
                </div>
              )}

              {/* Avatar settings inline form */}
              <form onSubmit={handleAvatarUpdate} style={{ borderTop: "1px solid var(--border)", paddingTop: "24px" }}>
                <h4 style={{ color: "var(--gold)", fontSize: "14px", letterSpacing: "1px", textTransform: "uppercase", marginBottom: "12px" }}>Retrato do Personagem (Avatar)</h4>
                <div className="form-group">
                  <label className="form-label">Link da imagem do Avatar</label>
                  <div style={{ display: "flex", gap: "10px" }}>
                    <input
                      type="url"
                      className="form-input"
                      style={{ flex: 1 }}
                      placeholder="https://exemplo.com/sua-imagem.png"
                      value={avatarUrl}
                      onChange={(e) => setAvatarUrl(e.target.value)}
                    />
                    <button type="submit" className="btn btn-gold" disabled={avatarLoading}>
                      {avatarLoading ? "Salvando..." : "Salvar"}
                    </button>
                  </div>
                  <span style={{ fontSize: "12px", color: "var(--cream3)", marginTop: "6px", display: "block" }}>
                    Cole o link de uma imagem ou use um avatar gratuito do <a href="https://dicebear.com" target="_blank" rel="noreferrer" style={{ textDecoration: "underline" }}>DiceBear</a>.
                  </span>
                </div>
                {avatarMessage && (
                  <div
                    style={{
                      background: avatarMessage.includes("sucesso") ? "rgba(39, 174, 96, 0.1)" : "rgba(139, 26, 26, 0.15)",
                      border: `1px solid ${avatarMessage.includes("sucesso") ? "var(--green)" : "var(--red)"}`,
                      color: avatarMessage.includes("sucesso") ? "var(--green2)" : "var(--red2)",
                      padding: "10px 14px",
                      borderRadius: "var(--radius-sm)",
                      fontSize: "13px",
                    }}
                  >
                    {avatarMessage}
                  </div>
                )}
              </form>
            </div>
          )}

          {/* Tab Content 2: Tickets */}
          {activeTab === "tickets" && (
            <div className="card">
              <h3 className="card-title">Seus Bilhetes Adquiridos</h3>

              {user.tickets.length > 0 ? (
                <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                  {user.tickets.map((t: any) => {
                    const isWinner = t.raffle.winningTicketNumber === t.number && t.raffle.status === "closed";
                    return (
                      <div
                        key={t.id}
                        style={{
                          background: isWinner ? "rgba(39, 174, 96, 0.08)" : "var(--dark2)",
                          border: `1px solid ${isWinner ? "var(--green2)" : "var(--border)"}`,
                          borderRadius: "var(--radius-sm)",
                          padding: "16px",
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                        }}
                      >
                        <div>
                          <strong style={{ color: isWinner ? "var(--green2)" : "var(--gold)", display: "block" }}>{t.raffle.title}</strong>
                          <span style={{ fontSize: "12px", color: "var(--cream3)" }}>
                            Adquirido em: {new Date(t.createdAt).toLocaleDateString("pt-BR")} às {new Date(t.createdAt).toLocaleTimeString("pt-BR", { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <div style={{ textAlign: "right" }}>
                          <span
                            className="badge"
                            style={{
                              background: isWinner ? "rgba(39,174,96,0.2)" : "var(--dark4)",
                              color: isWinner ? "var(--green2)" : "var(--cream2)",
                              border: `1px solid ${isWinner ? "var(--green2)" : "var(--border2)"}`,
                              fontSize: "14px",
                              fontFamily: "var(--font-title)",
                              padding: "4px 10px",
                              display: "inline-block",
                            }}
                          >
                            #{String(t.number).padStart(3, "0")}
                          </span>
                          {isWinner && (
                            <span style={{ display: "block", color: "var(--green2)", fontSize: "11px", fontWeight: "bold", marginTop: "4px" }}>
                              🏆 BILHETE GANHADOR!
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="empty-state">
                  <div className="empty-state-icon">🎟️</div>
                  <div className="empty-state-title">Nenhum Bilhete Encontrado</div>
                  <div className="empty-state-text" style={{ marginBottom: "20px" }}>Você ainda não adquiriu nenhum bilhete de rifa nesta conta.</div>
                  <button className="btn btn-gold" onClick={() => router.push("/rifas")}>Ver Rifas Ativas</button>
                </div>
              )}
            </div>
          )}

          {/* Tab Content 3: Affiliates */}
          {activeTab === "affiliates" && (
            <div className="card" style={{ display: "flex", flexDirection: "column", gap: "28px" }}>
              <div>
                <h3 className="card-title">Sistema de Afiliados (Indicações)</h3>
                <p style={{ color: "var(--cream3)", fontSize: "14px", fontStyle: "italic" }}>
                  Ganhe <strong>{user.affiliateCommission}%</strong> de comissão em cada bilhete comprado pelos jogadores que se cadastrarem com seu link de indicação!
                </p>
              </div>

              {/* Referral Link Box */}
              <div style={{ background: "var(--dark2)", border: "1px solid var(--border2)", borderRadius: "var(--radius-sm)", padding: "16px" }}>
                <span className="form-label" style={{ marginBottom: "8px" }}>Seu Link de Indicação</span>
                <div style={{ display: "flex", gap: "10px" }}>
                  <input
                    type="text"
                    className="form-input"
                    style={{ flex: 1, background: "var(--dark3)", borderColor: "var(--border)" }}
                    value={referralLink}
                    readOnly
                  />
                  <button type="button" className="btn btn-gold" onClick={handleCopyReferralLink}>
                    {copiedLink ? "Copiado!" : "Copiar"}
                  </button>
                </div>
                {copiedLink && (
                  <span style={{ fontSize: "12px", color: "#27ae60", marginTop: "6px", display: "block" }}>
                    Link copiado para a área de transferência! Compartilhe nas suas redes sociais e guilds.
                  </span>
                )}
              </div>

              {/* Affiliates Stats Grid */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: "16px" }}>
                <div className="stat-box">
                  <div className="stat-label">Total de Indicados</div>
                  <div className="stat-value">{user.referrals.length}</div>
                </div>
                <div className="stat-box">
                  <div className="stat-label">Saldo de Comissão</div>
                  <div className="stat-value" style={{ color: "var(--green2)" }}>
                    R$ {user.commissionBalance.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                  </div>
                </div>
              </div>

              {/* Withdrawal Request Form */}
              <form onSubmit={handleWithdrawal} style={{ borderTop: "1px solid var(--border)", paddingTop: "24px" }}>
                <h4 style={{ color: "var(--gold)", fontSize: "14px", letterSpacing: "1px", textTransform: "uppercase", marginBottom: "16px" }}>Solicitar Resgate de Comissão (Saque PIX)</h4>

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px", marginBottom: "16px" }}>
                  <div className="form-group" style={{ marginBottom: 0 }}>
                    <label className="form-label">Valor do Saque (R$)</label>
                    <input
                      type="number"
                      step="0.01"
                      min="10.00"
                      className="form-input"
                      placeholder="Mínimo R$ 10,00"
                      value={withdrawAmount}
                      onChange={(e) => setWithdrawAmount(e.target.value)}
                      required
                    />
                  </div>
                  <div className="form-group" style={{ marginBottom: 0 }}>
                    <label className="form-label">Chave PIX (CPF, Email ou Telefone)</label>
                    <input
                      type="text"
                      className="form-input"
                      placeholder="Sua chave de recebimento"
                      value={pixKey}
                      onChange={(e) => setPixKey(e.target.value)}
                      required
                    />
                  </div>
                </div>

                {wdError && (
                  <div style={{ background: "rgba(180,30,30,0.15)", border: "1px solid #8b2020", color: "#e57373", borderRadius: "var(--radius-sm)", padding: "10px 14px", fontSize: "13px", marginBottom: "16px" }}>
                    {wdError}
                  </div>
                )}
                {wdMessage && (
                  <div style={{ background: "rgba(39, 174, 96, 0.1)", border: "1px solid var(--green)", color: "var(--green2)", borderRadius: "var(--radius-sm)", padding: "10px 14px", fontSize: "13px", marginBottom: "16px" }}>
                    {wdMessage}
                  </div>
                )}

                <button type="submit" className="btn btn-gold btn-full" disabled={wdLoading}>
                  {wdLoading ? "Efetuando Conjuramento de Saque..." : "Concurar Saque PIX"}
                </button>
              </form>

              {/* History Sub-tabs: Earnings & Withdrawals */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "24px", borderTop: "1px solid var(--border)", paddingTop: "24px" }}>
                {/* Commission Earnings */}
                <div>
                  <h4 style={{ color: "var(--gold)", fontSize: "13px", letterSpacing: "1px", textTransform: "uppercase", marginBottom: "12px" }}>Últimas Comissões</h4>
                  {user.commissionEarnings.length > 0 ? (
                    <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                      {user.commissionEarnings.map((e: any) => (
                        <div key={e.id} style={{ background: "var(--dark2)", border: "1px solid var(--border)", borderRadius: "var(--radius-sm)", padding: "10px 12px", display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: "12px" }}>
                          <span style={{ color: "var(--cream3)" }}>{new Date(e.createdAt).toLocaleDateString("pt-BR")}</span>
                          <strong style={{ color: "var(--green2)" }}>+ R$ {e.amount.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</strong>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p style={{ color: "var(--cream3)", fontSize: "12px", fontStyle: "italic" }}>Nenhuma comissão recebida ainda.</p>
                  )}
                </div>

                {/* Withdrawals */}
                <div>
                  <h4 style={{ color: "var(--gold)", fontSize: "13px", letterSpacing: "1px", textTransform: "uppercase", marginBottom: "12px" }}>Histórico de Saques</h4>
                  {user.withdrawals.length > 0 ? (
                    <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                      {user.withdrawals.map((w: any) => (
                        <div key={w.id} style={{ background: "var(--dark2)", border: "1px solid var(--border)", borderRadius: "var(--radius-sm)", padding: "10px 12px", display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: "12px" }}>
                          <div>
                            <span style={{ color: "var(--cream3)", display: "block" }}>{new Date(w.createdAt).toLocaleDateString("pt-BR")}</span>
                            <span
                              style={{
                                color: w.status === "PENDING" ? "var(--gold)" : w.status === "PAID" ? "var(--green2)" : "var(--red2)",
                                fontSize: "10px",
                                textTransform: "uppercase",
                                fontWeight: "bold",
                              }}
                            >
                              {w.status === "PENDING" ? "Pendente" : w.status === "PAID" ? "Pago" : "Cancelado"}
                            </span>
                          </div>
                          <strong style={{ color: "var(--cream2)" }}>R$ {w.amount.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</strong>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p style={{ color: "var(--cream3)", fontSize: "12px", fontStyle: "italic" }}>Nenhum saque solicitado ainda.</p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Tab Content 4: Settings (Security) */}
          {activeTab === "settings" && (
            <div style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
              <div className="card">
                <h3 className="card-title">Configurações de Segurança</h3>
                <p style={{ color: "var(--cream3)", fontSize: "14px", marginBottom: "24px" }}>Altere sua senha de acesso periodicamente para blindar sua conta contra invasores do reino.</p>

                <form onSubmit={handlePasswordChange}>
                  <div className="form-group">
                    <label className="form-label">Senha Atual</label>
                    <input
                      type="password"
                      className="form-input"
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      required
                    />
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }}>
                    <div className="form-group">
                      <label className="form-label">Nova Senha</label>
                      <input
                        type="password"
                        className="form-input"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        required
                      />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Confirmar Nova Senha</label>
                      <input
                        type="password"
                        className="form-input"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  {pwdError && (
                    <div style={{ background: "rgba(180,30,30,0.15)", border: "1px solid #8b2020", color: "#e57373", borderRadius: "var(--radius-sm)", padding: "10px 14px", fontSize: "13px", marginBottom: "16px" }}>
                      {pwdError}
                    </div>
                  )}
                  {pwdMessage && (
                    <div style={{ background: "rgba(39, 174, 96, 0.1)", border: "1px solid var(--green)", color: "var(--green2)", borderRadius: "var(--radius-sm)", padding: "10px 14px", fontSize: "13px", marginBottom: "16px" }}>
                      {pwdMessage}
                    </div>
                  )}

                  <button type="submit" className="btn btn-gold btn-full" disabled={pwdLoading}>
                    {pwdLoading ? "Alterando Pergaminho de Senha..." : "Alterar Senha"}
                  </button>
                </form>
              </div>

              {/* DANGER ZONE (Delete Account) */}
              <div className="card" style={{ border: "1px solid #8b2020", background: "rgba(139, 32, 32, 0.03)" }}>
                <h3 className="card-title" style={{ color: "#ef5350" }}>💀 ZONA DE PERIGO (DELETAR FICHA)</h3>
                <p style={{ color: "var(--cream3)", fontSize: "13.5px", lineHeight: "1.6", marginBottom: "20px" }}>
                  A exclusão de conta é **definitiva, permanente e irreversível**. Todos os seus bilhetes de rifas, histórico de comissões, saques e XP acumulado serão **completamente deletados e expurgados do reino**.
                </p>

                {!showDeleteConfirm ? (
                  <button
                    type="button"
                    className="btn btn-danger btn-full"
                    style={{ background: "#8b2020", border: "1px solid #8b2020", color: "#fff", cursor: "pointer" }}
                    onClick={() => setShowDeleteConfirm(true)}
                  >
                    EXCLUIR CONTA DEFINITIVAMENTE
                  </button>
                ) : (
                  <div style={{ background: "var(--dark2)", border: "1px solid #3d2e0f", borderRadius: "var(--radius-sm)", padding: "20px" }} className="animate-fade-in">
                    <span className="form-label" style={{ color: "#ef5350", marginBottom: "8px", fontWeight: "bold", display: "block" }}>
                      Deseja mesmo confirmar a exclusão permanente?
                    </span>
                    <p style={{ fontSize: "12px", color: "var(--cream3)", marginBottom: "12px", fontStyle: "italic" }}>
                      Para prosseguir, digite seu nick exato de herói: <strong style={{ color: "var(--gold)" }}>{user.username}</strong>
                    </p>
                    <input
                      type="text"
                      className="form-input"
                      style={{ width: "100%", marginBottom: "16px", borderColor: "#8b2020" }}
                      placeholder="Digite seu nick de guerreiro"
                      value={deleteConfirmText}
                      onChange={(e) => setDeleteConfirmText(e.target.value)}
                    />
                    <div style={{ display: "flex", gap: "10px" }}>
                      <button
                        type="button"
                        className="btn btn-danger"
                        style={{ flex: 1, background: "#8b2020", cursor: "pointer" }}
                        onClick={handleDeleteAccount}
                        disabled={deleteLoading}
                      >
                        {deleteLoading ? "Expurgando..." : "SIM, DELETAR"}
                      </button>
                      <button
                        type="button"
                        className="btn btn-outline"
                        style={{ flex: 1, cursor: "pointer" }}
                        onClick={() => { setShowDeleteConfirm(false); setDeleteConfirmText(""); }}
                        disabled={deleteLoading}
                      >
                        CANCELAR
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Scoped CSS for profile avatar hover transitions */}
          <style jsx global>{`
            .avatar-hover-container:hover .avatar-overlay {
              opacity: 1 !important;
            }
            .avatar-hover-container:hover img {
              filter: blur(2.5px) brightness(0.45);
            }
          `}</style>
        </div>
      </div>
    </div>
  );
}
