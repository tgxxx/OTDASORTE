/* ============================================================
   TIBIA RIFA — PixBox.tsx REFORMULADO v2.0
   Substituir: app/components/PixBox.tsx
   ============================================================ */
"use client";
import { QRCodeSVG } from "qrcode.react";
import { useState } from "react";

type Props = { pix: string };

export default function PixBox({ pix }: Props) {
  const [copied, setCopied] = useState(false);

  async function copyPix() {
    await navigator.clipboard.writeText(pix);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div style={s.wrap}>
      <h2 style={s.title}>⚡ PAGAMENTO PIX</h2>

      <div style={s.qrWrap}>
        <QRCodeSVG value={pix} size={200} />
      </div>

      <p style={s.hint}>Escaneie o QR Code ou copie o código abaixo</p>

      <textarea style={s.code} value={pix} readOnly rows={4} />

      <button style={{ ...s.btn, ...(copied ? s.btnCopied : {}) }} onClick={copyPix}>
        {copied ? "✅ COPIADO COM SUCESSO!" : "📋 COPIAR CÓDIGO PIX"}
      </button>
    </div>
  );
}

const s: Record<string, React.CSSProperties> = {
  wrap: {
    background: "#1a1409", border: "2px solid #5a4318", borderRadius: 10,
    padding: 24, textAlign: "center",
  },
  title: { color: "#d4af37", marginBottom: 16, fontFamily: "'Cinzel',serif", fontSize: 18 },
  qrWrap: {
    background: "#fff", display: "inline-block",
    padding: 14, borderRadius: 8, marginBottom: 14,
  },
  hint: { fontSize: 12, color: "#a8865a", marginBottom: 12, fontStyle: "italic" },
  code: {
    width: "100%", padding: 10, height: 80, resize: "none",
    background: "#0a0704", color: "#d4b87a",
    border: "1px solid #5a4318", borderRadius: 6,
    fontFamily: "monospace", fontSize: 11, marginBottom: 12,
  },
  btn: {
    width: "100%", padding: 14, background: "#1a1409",
    border: "1px solid #8a6a10", color: "#d4af37",
    fontFamily: "'Cinzel',serif", fontSize: 13, letterSpacing: 2,
    cursor: "pointer", borderRadius: 6, transition: "all 0.2s",
  },
  btnCopied: { background: "rgba(39,174,96,0.15)", borderColor: "#27ae60", color: "#27ae60" },
};
