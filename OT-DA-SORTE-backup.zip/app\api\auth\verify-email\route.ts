import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";

export async function POST(req: NextRequest) {
  try {
    const { token } = await req.json();
    if (!token) {
      return NextResponse.json({ error: "Token é obrigatório" }, { status: 400 });
    }

    const user = await prisma.user.findFirst({
      where: {
        verificationToken: token,
      },
    });

    if (!user) {
      return NextResponse.json({ error: "Token inválido ou conta já verificada." }, { status: 400 });
    }

    if (user.verificationTokenExpires && user.verificationTokenExpires < new Date()) {
      return NextResponse.json({ error: "Token de verificação expirado. Por favor, registre-se novamente." }, { status: 400 });
    }

    // Ativar o usuário e limpar o token de verificação
    await prisma.user.update({
      where: { id: user.id },
      data: {
        emailVerified: true,
        verificationToken: null,
        verificationTokenExpires: null,
      },
    });

    return NextResponse.json({ success: true, message: "E-mail verificado com sucesso!" });
  } catch (err) {
    console.error("[verify-email]", err);
    return NextResponse.json({ error: "Erro interno no servidor" }, { status: 500 });
  }
}
