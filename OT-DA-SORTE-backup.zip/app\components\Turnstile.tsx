"use client";

export default function Turnstile() {

  return (

    <div
      className="cf-turnstile"

      data-sitekey={
        process.env
        .NEXT_PUBLIC_TURNSTILE_SITE_KEY
      }
    />
  );
}