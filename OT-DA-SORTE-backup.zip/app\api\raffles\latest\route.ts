import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";

/**
 * GET /api/raffles/latest
 * Retorna a rifa mais recente cadastrada no banco (independente do status).
 * Usado pela Home para sincronização dinâmica da seção de prêmio.
 */
export const dynamic = "force-dynamic"; // nunca cachear — sempre dados frescos

export async function GET() {
  try {
    const raffle = await prisma.raffle.findFirst({
      orderBy: { createdAt: "desc" },
    });

    if (!raffle) {
      return NextResponse.json({ raffle: null }, { status: 200 });
    }

    return NextResponse.json({ raffle }, { status: 200 });
  } catch (err) {
    console.error("[raffles/latest GET]", err);
    return NextResponse.json({ error: "Erro interno ao buscar rifa" }, { status: 500 });
  }
}
