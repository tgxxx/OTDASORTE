import nodemailer from "nodemailer";
import fs from "fs";
import path from "path";

// Get SMTP options from environment
const smtpHost = process.env.SMTP_HOST;
const smtpPort = parseInt(process.env.SMTP_PORT || "587");
const smtpUser = process.env.SMTP_USER;
const smtpPass = process.env.SMTP_PASS;
const smtpFrom = process.env.SMTP_FROM || "no-reply@otdasorte.com";
const appUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";

// Standard nodemailer transporter if configured
let transporter: nodemailer.Transporter | null = null;
const isSmtpConfigured = smtpHost && smtpUser && smtpPass;

if (isSmtpConfigured) {
  transporter = nodemailer.createTransport({
    host: smtpHost,
    port: smtpPort,
    secure: smtpPort === 465,
    auth: {
      user: smtpUser,
      pass: smtpPass,
    },
  });
}

/**
 * Logs email to a local file for easy debugging/testing if SMTP is not configured.
 */
async function fallbackLogEmail(to: string, subject: string, htmlContent: string) {
  try {
    const scratchDir = path.join(process.cwd(), "scratch");
    if (!fs.existsSync(scratchDir)) {
      fs.mkdirSync(scratchDir, { recursive: true });
    }
    const logPath = path.join(scratchDir, "email-log.txt");

    // Extract links from HTML content for easy clicking in terminal/text editor
    const links: string[] = [];
    const hrefRegex = /href="([^"]+)"/g;
    let match;
    while ((match = hrefRegex.exec(htmlContent)) !== null) {
      links.push(match[1]);
    }

    const logEntry = `
========================================
[EMAIL DE BUG LOG] - ${new Date().toISOString()}
Para: ${to}
Assunto: ${subject}
----------------------------------------
LINKS ENCONTRADOS PARA CLICK DIRETO:
${links.map((link) => `⚡ ${link}`).join("\n")}
----------------------------------------
CONTEÚDO DO E-MAIL (HTML):
${htmlContent}
========================================
\n`;

    fs.appendFileSync(logPath, logEntry, "utf-8");
    console.log(`\n📬 [Email Fallback Logged] Para: ${to} | Assunto: ${subject}`);
    console.log(`🔗 Link de Acesso: ${links[0] || "Nenhum link"}\n`);
    console.log(`📝 Salvo em: scratch/email-log.txt\n`);
  } catch (err) {
    console.error("Erro ao escrever log de e-mail:", err);
  }
}

/**
 * Sends a registration verification email
 */
export async function sendVerificationEmail(email: string, username: string, token: string) {
  const verifyLink = `${appUrl}/login?verify=${token}`;
  const subject = "🛡️ Confirme seu cadastro no OT da Sorte!";
  
  const html = `
    <div style="font-family: 'Cinzel', serif, sans-serif; background: #0a0704; color: #f0dfa8; padding: 40px; border: 2px solid #5a4318; border-radius: 8px; max-width: 600px; margin: 0 auto;">
      <div style="text-align: center; margin-bottom: 24px;">
        <span style="font-size: 48px;">🛡️</span>
        <h1 style="color: #d4af37; text-transform: uppercase; letter-spacing: 2px; margin-top: 12px; font-size: 24px;">OT DA SORTE</h1>
      </div>
      <div style="border-top: 1px solid #3d2e0f; padding-top: 24px; font-size: 15px; line-height: 1.6;">
        <p>Saudações, Nobre Guerreiro <strong>${username}</strong>!</p>
        <p>Sua jornada no reino das rifas lendárias está prestes a começar. No entanto, para blindar sua conta e provar sua identidade, você deve confirmar seu pergaminho de e-mail.</p>
        <div style="text-align: center; margin: 32px 0;">
          <a href="${verifyLink}" style="background: linear-gradient(180deg, #d4af37 0%, #8a6a10 100%); border: 1px solid #8a6a10; color: #0a0704; padding: 14px 28px; text-decoration: none; font-weight: bold; border-radius: 4px; letter-spacing: 1px; display: inline-block; font-family: sans-serif; text-transform: uppercase;">⚡ CONFIRMAR CADASTRO</a>
        </div>
        <p style="font-size: 12px; color: #a8865a; font-style: italic; text-align: center;">Este link de verificação expira em 24 horas.</p>
        <p style="color: #a8865a; border-top: 1px solid #3d2e0f; padding-top: 20px; font-size: 13px;">Se o botão acima não funcionar, copie e cole o link no seu navegador:<br>
        <a href="${verifyLink}" style="color: #d4af37; text-decoration: underline;">${verifyLink}</a></p>
      </div>
      <div style="text-align: center; margin-top: 40px; border-top: 1px solid #3d2e0f; padding-top: 20px; color: #5a4318; font-size: 11px;">
        © 2026 OT da Sorte. Todos os direitos reservados no Reino.
      </div>
    </div>
  `;

  if (transporter) {
    try {
      await transporter.sendMail({
        from: smtpFrom,
        to: email,
        subject: subject,
        html: html,
      });
      return true;
    } catch (err) {
      console.error("Transporter falhou, recorrendo ao log local:", err);
    }
  }

  // Fallback if not configured or failed
  await fallbackLogEmail(email, subject, html);
  return true;
}

/**
 * Sends a password reset email
 */
export async function sendPasswordResetEmail(email: string, username: string, token: string) {
  const resetLink = `${appUrl}/login?token=${token}`;
  const subject = "🔮 Recuperação de Senha — OT da Sorte";

  const html = `
    <div style="font-family: 'Cinzel', serif, sans-serif; background: #0a0704; color: #f0dfa8; padding: 40px; border: 2px solid #5a4318; border-radius: 8px; max-width: 600px; margin: 0 auto;">
      <div style="text-align: center; margin-bottom: 24px;">
        <span style="font-size: 48px;">🔮</span>
        <h1 style="color: #d4af37; text-transform: uppercase; letter-spacing: 2px; margin-top: 12px; font-size: 24px;">OT DA SORTE</h1>
      </div>
      <div style="border-top: 1px solid #3d2e0f; padding-top: 24px; font-size: 15px; line-height: 1.6;">
        <p>Saudações, <strong>${username}</strong>!</p>
        <p>Uma prece de recuperação de senha foi conjurada para a sua conta no reino. Caso você tenha solicitado essa mudança, clique no botão mágico abaixo para restaurar seu acesso e redefinir sua senha.</p>
        <div style="text-align: center; margin: 32px 0;">
          <a href="${resetLink}" style="background: linear-gradient(180deg, #d4af37 0%, #8a6a10 100%); border: 1px solid #8a6a10; color: #0a0704; padding: 14px 28px; text-decoration: none; font-weight: bold; border-radius: 4px; letter-spacing: 1px; display: inline-block; font-family: sans-serif; text-transform: uppercase;">⚡ REDEFINIR SENHA</a>
        </div>
        <p style="font-size: 12px; color: #a8865a; font-style: italic; text-align: center;">Este link de redefinição expira em 1 hora.</p>
        <p style="color: #a8865a; border-top: 1px solid #3d2e0f; padding-top: 20px; font-size: 13px;">Se você não solicitou a redefinição de sua senha, ignore este e-mail e sua senha atual continuará perfeitamente segura.</p>
        <p style="color: #a8865a; border-top: 1px solid #3d2e0f; padding-top: 20px; font-size: 13px;">Se o botão não funcionar, copie e cole o link:<br>
        <a href="${resetLink}" style="color: #d4af37; text-decoration: underline;">${resetLink}</a></p>
      </div>
      <div style="text-align: center; margin-top: 40px; border-top: 1px solid #3d2e0f; padding-top: 20px; color: #5a4318; font-size: 11px;">
        © 2026 OT da Sorte. Todos os direitos reservados no Reino.
      </div>
    </div>
  `;

  if (transporter) {
    try {
      await transporter.sendMail({
        from: smtpFrom,
        to: email,
        subject: subject,
        html: html,
      });
      return true;
    } catch (err) {
      console.error("Transporter reset falhou, recorrendo ao log local:", err);
    }
  }

  // Fallback
  await fallbackLogEmail(email, subject, html);
  return true;
}
