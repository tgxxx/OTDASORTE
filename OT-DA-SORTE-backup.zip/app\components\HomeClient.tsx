"use client";

import { useState, useEffect } from "react";
import PixBox from "./PixBox";
import type { RaffleData } from "./RafflePrizeSection";

interface Props {
  initialRaffle: RaffleData | null;
}

/**
 * HomeClient
 * Componente cliente que gerencia a parte interativa da Home:
 * - Seleção de quantidade de tickets
 * - Geração e exibição do PIX
 * - Timer de expiração do PIX
 */
export default function HomeClient({ initialRaffle }: Props) {
  const [qty, setQty] = useState(1);
  const [pix, setPix] = useState("");
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [pixExpiry, setPixExpiry] = useState(0);
  const [authError, setAuthError] = useState("");

  // Resetar estados de pagamento quando a rifa selecionada muda
  useEffect(() => {
    setPix("");
    setAuthError("");
    setQty(1);
  }, [initialRaffle?.id]);

  // Usa a rifa passada pelo servidor como estado base
  const activeRaffle = initialRaffle;

  const price = activeRaffle?.price ?? 5;
  const total = qty * price;

  useEffect(() => {
    if (!pix) return;
    setPixExpiry(30 * 60);
    const t = setInterval(() => setPixExpiry((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(t);
  }, [pix]);

  const fmt = (secs: number) => {
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    const sec = secs % 60;
    return h > 0
      ? `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`
      : `${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
  };

  const changeQty = (d: number) => setQty((q) => Math.max(1, Math.min(99, q + d)));

  async function generatePix() {
    setAuthError("");
    if (!activeRaffle) {
      setAuthError("Nenhuma rifa ativa no momento.");
      return;
    }
    setLoading(true);
    setPix("");
    try {
      const res = await fetch("/api/pix", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amount: total,
          raffleId: activeRaffle.id,
          quantity: qty,
        }),
      });
      const data = await res.json();
      if (res.status === 401) {
        setAuthError("Você precisa estar logado para comprar bilhetes.");
        return;
      }
      if (!res.ok || data.error) {
        setAuthError(data.error ?? "Erro ao gerar PIX");
        return;
      }
      setPix(data.qr_code ?? "");
    } catch {
      setAuthError("Erro de conexão. Tente novamente.");
    } finally {
      setLoading(false);
    }
  }

  async function copyPix() {
    await navigator.clipboard.writeText(pix);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  // ─── Fallback: sem rifa ativa ──────────────────────────────────────────────
  if (!activeRaffle) {
    return (
      <section style={{ ...s.section, maxWidth: 640 }}>
        <div style={s.ticketPanel}>
          <h3 style={s.ticketTitle}>🎟 COMPRAR TICKETS</h3>
          <div
            style={{
              textAlign: "center",
              padding: "24px 16px",
              color: "#a8865a",
              fontStyle: "italic",
              fontSize: 14,
            }}
          >
            Nenhuma rifa disponível para compra no momento.
            <br />
            <span style={{ fontSize: 12, color: "#5a4318", marginTop: 8, display: "block" }}>
              Acompanhe o anúncio da próxima rifa lendária!
            </span>
          </div>
        </div>
      </section>
    );
  }

  // ─── Estado normal: rifa ativa ─────────────────────────────────────────────
  const priceFormatted = price.toLocaleString("pt-BR", { minimumFractionDigits: 2 });

  return (
    <section style={{ ...s.section, maxWidth: 640 }}>
      <div style={s.ticketPanel}>
        <h3 style={s.ticketTitle}>🎟 COMPRAR TICKETS</h3>
        <p style={s.ticketSub}>
          Cada ticket custa R$ {priceFormatted} · Pague via PIX instantâneo
        </p>

        <div style={s.priceRow}>
          <span style={s.priceLabel}>Preço por ticket</span>
          <strong style={s.priceVal}>R$ {priceFormatted}</strong>
        </div>

        <div style={s.qtyControl}>
          <button style={s.qtyBtn} onClick={() => changeQty(-1)}>
            −
          </button>
          <span style={s.qtyDisplay}>{qty}</span>
          <button style={s.qtyBtn} onClick={() => changeQty(1)}>
            +
          </button>
        </div>

        <div style={s.presets}>
          {[1, 5, 10, 25, 50].map((n) => (
            <button
              key={n}
              style={{ ...s.preset, ...(qty === n ? s.presetActive : {}) }}
              onClick={() => setQty(n)}
            >
              {n}x
            </button>
          ))}
        </div>

        <div style={s.totalBox}>
          <span style={s.totalLabel}>Total a pagar</span>
          <span style={s.totalVal}>
            R$ {total.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
          </span>
        </div>

        {authError && (
          <div style={s.errorBox}>
            {authError}{" "}
            {authError.includes("logado") && (
              <a href="/login" style={{ color: "#d4af37" }}>
                Fazer login
              </a>
            )}
          </div>
        )}

        <button
          style={{ ...s.mainBtn, opacity: loading ? 0.7 : 1 }}
          onClick={generatePix}
          disabled={loading}
        >
          {loading ? "⚡ Conjurando PIX..." : "⚡ GERAR PIX"}
        </button>

        <div style={s.badges}>
          <Badge icon="🔒" label="Pagamento Seguro" />
          <Badge icon="⚡" label="PIX Instantâneo" />
          <Badge icon="✅" label="Bilhetes Confirmados" />
        </div>

        {pix && (
          <div style={s.pixSection}>
            <h3 style={s.pixTitle}>⚡ PAGAMENTO PIX</h3>
            <p style={s.pixSub}>
              R$ {total.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
            </p>
            <PixBox pix={pix} />
            {pixExpiry > 0 && (
              <div style={s.expiry}>
                ⏳ Expira em:{" "}
                <strong style={{ color: "#d4af37" }}>{fmt(pixExpiry)}</strong>
              </div>
            )}
            <p style={s.pixNote}>
              Após pagamento, seus bilhetes serão confirmados automaticamente
            </p>
          </div>
        )}
      </div>
    </section>
  );
}

// ─── Sub-componentes ─────────────────────────────────────────────────────────
function Badge({ icon, label }: { icon: string; label: string }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 11, color: "#a8865a" }}>
      <span>{icon}</span>
      <span>{label}</span>
    </div>
  );
}

// ─── Estilos ─────────────────────────────────────────────────────────────────
const s: Record<string, React.CSSProperties> = {
  section: { maxWidth: 1100, margin: "0 auto", padding: "36px 20px" },
  ticketPanel: {
    background: "#1a1409",
    border: "1px solid #5a4318",
    borderRadius: 8,
    padding: 28,
  },
  ticketTitle: {
    fontFamily: "'Cinzel',serif",
    color: "#d4af37",
    fontSize: 18,
    textAlign: "center",
    marginBottom: 6,
  },
  ticketSub: {
    color: "#a8865a",
    fontSize: 13,
    textAlign: "center",
    marginBottom: 24,
    fontStyle: "italic",
    fontFamily: "'Crimson Text',serif",
  },
  priceRow: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "12px 16px",
    background: "#231b0d",
    border: "1px solid #3d2e0f",
    borderRadius: 6,
    marginBottom: 16,
  },
  priceLabel: { color: "#d4b87a", fontSize: 14, fontFamily: "'Cinzel',serif" },
  priceVal: { color: "#d4af37", fontSize: 16, fontFamily: "'Cinzel',serif" },
  qtyControl: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 20,
    margin: "20px 0",
  },
  qtyBtn: {
    width: 44,
    height: 44,
    background: "#231b0d",
    border: "1px solid #7a5c22",
    color: "#d4af37",
    fontSize: 22,
    cursor: "pointer",
    borderRadius: 4,
    fontFamily: "'Cinzel',serif",
  },
  qtyDisplay: {
    fontFamily: "'Cinzel',serif",
    fontSize: 40,
    color: "#d4af37",
    minWidth: 60,
    textAlign: "center",
    textShadow: "0 0 20px rgba(201,162,39,0.3)",
  },
  presets: {
    display: "flex",
    gap: 8,
    justifyContent: "center",
    marginBottom: 20,
    flexWrap: "wrap" as const,
  },
  preset: {
    background: "#231b0d",
    border: "1px solid #3d2e0f",
    color: "#a8865a",
    fontSize: 12,
    padding: "6px 14px",
    cursor: "pointer",
    borderRadius: 4,
    fontFamily: "'Cinzel',serif",
    letterSpacing: 1,
  },
  presetActive: {
    background: "rgba(201,162,39,0.15)",
    borderColor: "#d4af37",
    color: "#d4af37",
  },
  totalBox: {
    background: "#110e08",
    border: "1px solid #5a4318",
    borderRadius: 6,
    padding: 16,
    textAlign: "center",
    margin: "16px 0",
  },
  totalLabel: {
    fontSize: 11,
    color: "#a8865a",
    letterSpacing: 2,
    textTransform: "uppercase",
    display: "block",
    marginBottom: 6,
  },
  totalVal: { fontFamily: "'Cinzel',serif", fontSize: 32, color: "#d4af37" },
  errorBox: {
    background: "rgba(180,30,30,0.15)",
    border: "1px solid #8b2020",
    color: "#e57373",
    borderRadius: 6,
    padding: "10px 14px",
    fontSize: 13,
    margin: "8px 0",
  },
  mainBtn: {
    width: "100%",
    padding: "16px 0",
    marginTop: 12,
    background: "linear-gradient(180deg,#d4af37 0%,#8a6a10 100%)",
    border: "1px solid #8a6a10",
    color: "#0a0704",
    fontFamily: "'Cinzel',serif",
    fontSize: 14,
    letterSpacing: 2,
    cursor: "pointer",
    borderRadius: 4,
    fontWeight: 700,
    textTransform: "uppercase" as const,
  },
  badges: {
    display: "flex",
    justifyContent: "center",
    gap: 20,
    marginTop: 14,
    flexWrap: "wrap" as const,
  },
  pixSection: {
    background: "#231b0d",
    border: "1px solid #5a4318",
    borderRadius: 8,
    padding: 24,
    textAlign: "center",
    marginTop: 20,
  },
  pixTitle: { fontFamily: "'Cinzel',serif", color: "#d4af37", fontSize: 18, marginBottom: 4 },
  pixSub: {
    color: "#a8865a",
    marginBottom: 16,
    fontStyle: "italic",
    fontFamily: "'Crimson Text',serif",
  },
  expiry: {
    display: "flex",
    justifyContent: "center",
    gap: 8,
    marginTop: 14,
    fontSize: 13,
    color: "#a8865a",
  },
  pixNote: {
    fontSize: 12,
    color: "#a8865a",
    marginTop: 12,
    fontStyle: "italic",
    fontFamily: "'Crimson Text',serif",
  },
};
