/* ============================================================
   TIBIA RIFA — NumberCard.tsx REFORMULADO v2.0
   Substituir: app/components/NumberCard.tsx
   ============================================================ */

type Props = {
  number: number;
  status: "available" | "selected" | "sold" | "mine";
  onClick?: () => void;
};

const STATUS_STYLES = {
  available: { background: "#1a1409", borderColor: "#3d2e0f", color: "#d4b87a" },
  selected:  { background: "rgba(212,175,55,0.18)", borderColor: "#d4af37", color: "#d4af37" },
  sold:      { background: "rgba(139,26,26,0.2)", borderColor: "#8b1a1a", color: "#c0392b", cursor: "not-allowed" as const },
  mine:      { background: "rgba(39,174,96,0.12)", borderColor: "#27ae60", color: "#27ae60", cursor: "not-allowed" as const },
};

export default function NumberCard({ number, status, onClick }: Props) {
  return (
    <button
      onClick={status === "available" || status === "selected" ? onClick : undefined}
      style={{
        aspectRatio: "1",
        display: "flex", alignItems: "center", justifyContent: "center",
        border: "1px solid",
        borderRadius: 4,
        cursor: "pointer",
        fontFamily: "'Cinzel',serif",
        fontSize: 11,
        fontWeight: 700,
        transition: "all 0.15s",
        userSelect: "none",
        ...STATUS_STYLES[status],
      }}
    >
      {String(number).padStart(3, "0")}
    </button>
  );
}
