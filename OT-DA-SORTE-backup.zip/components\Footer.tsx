"use client";

import Link from "next/link";
import { GoldenHelmetIcon } from "./Navbar";

export default function Footer() {
  return (
    <footer style={s.footer}>
      <div className="container" style={s.container}>
        
        {/* Top section: Logo and Description */}
        <div style={s.topSection}>
          <div style={s.logoCol}>
            <div style={s.logoRow}>
              <GoldenHelmetIcon size={32} />
              <span style={s.logoText}>OT DA SORTE</span>
            </div>
            <p style={s.descText}>
              O principal portal de sorteios de itens raros e lendários no reino medieval. Teste sua sorte, adquira seus bilhetes e grave seu nome na história.
            </p>
          </div>

          {/* Column 1: Links */}
          <div style={s.linksCol}>
            <h4 style={s.colTitle}>Sorteios</h4>
            <div style={s.linksList}>
              <Link href="/" style={s.link}>Início</Link>
              <Link href="/rifas" style={s.link}>Rifas Ativas</Link>
              <Link href="/ranking" style={s.link}>Hall da Fama</Link>
            </div>
          </div>

          {/* Column 2: Trust */}
          <div style={s.linksCol}>
            <h4 style={s.colTitle}>Transparência</h4>
            <div style={s.linksList}>
              <Link href="/provably-fair" style={s.link}>Aba Fair (Auditoria)</Link>
              <span style={s.staticLink}>Sorteios via Caixa</span>
              <span style={s.staticLink}>Matemática Pública</span>
            </div>
          </div>

          {/* Column 3: Support */}
          <div style={s.linksCol}>
            <h4 style={s.colTitle}>Guilda & Suporte</h4>
            <div style={s.linksList}>
              <a href="mailto:suporte@otdasorte.com" style={s.link}>📩 suporte@otdasorte.com</a>
              <span style={s.staticLink}>Discord Oficial</span>
              <span style={s.staticLink}>Guild Chat</span>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div style={s.divider} />

        {/* Bottom section: Legal, Socials and Copyright */}
        <div style={s.bottomSection}>
          <div style={s.legalCol}>
            <span style={s.legalLink}>Termos de Uso</span>
            <span style={s.legalDot}>·</span>
            <span style={s.legalLink}>Políticas de Privacidade</span>
            <span style={s.legalDot}>·</span>
            <span style={s.legalLink}>Jogo Responsável</span>
          </div>

          <div style={s.socials}>
            <span style={s.socialIcon} title="Telegram">✈️</span>
            <span style={s.socialIcon} title="Discord">💬</span>
            <span style={s.socialIcon} title="Instagram">📸</span>
          </div>
        </div>

        <div style={s.copyright}>
          © 2026 OT da Sorte. Todos os direitos reservados. Conquiste sua lenda com honra!
        </div>
      </div>
    </footer>
  );
}

const s: Record<string, React.CSSProperties> = {
  footer: {
    background: "linear-gradient(180deg, #0a0704 0%, #110e08 100%)",
    borderTop: "1px solid #3d2e0f",
    color: "#a8865a",
    padding: "56px 20px 32px",
    fontFamily: "'Crimson Text', serif",
  },
  container: {
    maxWidth: 1100,
    margin: "0 auto",
    display: "flex",
    flexDirection: "column" as const,
  },
  topSection: {
    display: "flex",
    justifyContent: "space-between",
    flexWrap: "wrap",
    gap: "32px",
    marginBottom: "40px",
  },
  logoCol: {
    flex: "2 1 300px",
    display: "flex",
    flexDirection: "column" as const,
    gap: "12px",
  },
  logoRow: {
    display: "flex",
    alignItems: "center",
    gap: "10px",
  },
  logoText: {
    fontFamily: "'Cinzel', serif",
    color: "#d4af37",
    fontSize: "18px",
    fontWeight: "bold",
    letterSpacing: "1.5px",
  },
  descText: {
    fontSize: "13.5px",
    lineHeight: "1.6",
    color: "#8a6a10",
    maxWidth: 380,
  },
  linksCol: {
    flex: "1 1 150px",
    display: "flex",
    flexDirection: "column" as const,
    gap: "14px",
  },
  colTitle: {
    fontFamily: "'Cinzel', serif",
    color: "#d4af37",
    fontSize: "12px",
    fontWeight: "bold",
    letterSpacing: "1.2px",
    textTransform: "uppercase" as const,
    margin: 0,
  },
  linksList: {
    display: "flex",
    flexDirection: "column" as const,
    gap: "8px",
    fontSize: "13.5px",
  },
  link: {
    color: "#a8865a",
    textDecoration: "none",
    transition: "color 0.2s",
  },
  staticLink: {
    color: "#5a4318",
    cursor: "default",
  },
  divider: {
    height: "1px",
    background: "linear-gradient(90deg, transparent, #3d2e0f, transparent)",
    margin: "0 0 24px",
  },
  bottomSection: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    flexWrap: "wrap",
    gap: "16px",
    marginBottom: "16px",
  },
  legalCol: {
    display: "flex",
    alignItems: "center",
    gap: "8px",
    fontSize: "12.5px",
  },
  legalLink: {
    color: "#8a6a10",
    cursor: "pointer",
    transition: "color 0.2s",
  },
  legalDot: {
    color: "#3d2e0f",
  },
  socials: {
    display: "flex",
    gap: "16px",
  },
  socialIcon: {
    fontSize: "18px",
    cursor: "pointer",
    opacity: 0.7,
    transition: "opacity 0.2s, transform 0.2s",
  },
  copyright: {
    textAlign: "center",
    fontSize: "11px",
    color: "#5a4318",
    letterSpacing: "0.5px",
    marginTop: "24px",
    fontFamily: "'Cinzel', serif",
  },
};
