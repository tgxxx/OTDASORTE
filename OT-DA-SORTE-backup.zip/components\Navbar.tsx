"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";

interface User {
  username: string;
  role: string;
  avatar?: string;
}

/** 
 * GoldenHelmetIcon — iconic Tibia-style knight helmet in gold.
 * Full dome, nose guard, cheek plates, visor bars — premium MMORPG aesthetic.
 * Exported so other pages can reuse it.
 */
export function GoldenHelmetIcon({ size = 32 }: { size?: number }) {
  const id = `winged-helmet-${size}`;
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="navbar-logo-icon"
      aria-label="Winged Helmet"
    >
      <defs>
        {/* Glow behind the helmet matching the gold-glow of the site */}
        <radialGradient id={`${id}-glow`} cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#f39c12" stopOpacity="0.45" />
          <stop offset="100%" stopColor="#f39c12" stopOpacity="0" />
        </radialGradient>
        {/* Rich Tibia-style orange/gold gradient for the helmet dome */}
        <linearGradient id={`${id}-dome`} x1="12" y1="18" x2="36" y2="46" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#ff9f43" /> {/* Bright orange-gold */}
          <stop offset="50%" stopColor="#e67e22" /> {/* Rich mid orange */}
          <stop offset="100%" stopColor="#964b00" /> {/* Deep shadow */}
        </linearGradient>
        {/* Lighter orange gradient for the flared brim */}
        <linearGradient id={`${id}-brim`} x1="4" y1="36" x2="38" y2="48" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#ffb057" />
          <stop offset="70%" stopColor="#d35400" />
          <stop offset="100%" stopColor="#802b00" />
        </linearGradient>
        {/* Wing gradient for premium silver/white depth */}
        <linearGradient id={`${id}-wing`} x1="38" y1="16" x2="60" y2="38" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="60%" stopColor="#f1f5f9" />
          <stop offset="100%" stopColor="#cbd5e1" />
        </linearGradient>
      </defs>

      {/* Aura Glow */}
      <circle cx="32" cy="32" r="28" fill={`url(#${id}-glow)`} />

      {/* Helmet Outline */}
      <path
        d="M28 15C17.5 15 9 22.5 8.5 32.5C4 35 1.5 38.5 1 41.5C0.5 44 2.5 45.5 5 46C13.5 48 23 52 38 52C42.5 52 44.5 50.5 44.5 48.5C44.5 47 43 45 42 43.5C44 42.5 45 41.5 45 40C45 36.5 43.5 33 42 30.5C42.5 24 37 15 28 15Z"
        fill="#1e1302"
      />

      {/* Main Dome */}
      <path
        d="M28 17C19 17 11 23.5 10.5 32.5C21 34 32.5 32.5 39.5 29.5C39.5 24.5 35 17 28 17Z"
        fill={`url(#${id}-dome)`}
        stroke="#4d2800"
        strokeWidth="1"
      />

      {/* Flared Visor/Brim */}
      <path
        d="M9.8 33.5C9.8 33.5 20.5 35 37.5 31C39.5 30 40 31.5 40 33C40 36.5 37.5 40 37.5 40C24 43 14 41.5 3 39.5C2 39 2.5 37.5 4.5 36.5C6.5 35.5 9.8 33.5 9.8 33.5Z"
        fill={`url(#${id}-brim)`}
        stroke="#4d2800"
        strokeWidth="1"
      />

      {/* Visor/Brim bottom extension matching the image */}
      <path
        d="M17.5 40.5C25 43.5 32 44.5 42.5 42.5C43.5 42.5 43.5 44 42.5 45C33 49.5 21 48 11.5 45C10 44.5 9.5 42.5 11.5 42C13.5 41.5 17.5 40.5 17.5 40.5Z"
        fill="#b33c00"
        stroke="#4d2800"
        strokeWidth="1"
      />

      {/* Dome Highlights/Dithering simulation */}
      <path
        d="M22 22C24 19.5 28 19 31 20"
        stroke="#fff8e8"
        strokeWidth="2"
        strokeLinecap="round"
        opacity="0.6"
      />
      <circle cx="26" cy="25" r="1.5" fill="#ffffff" opacity="0.8" />
      <circle cx="18" cy="30" r="1" fill="#fff8e8" opacity="0.5" />

      {/* The Wing */}
      {/* Wing Backing / Outline */}
      <path
        d="M35 43C34 38 35 32.5 38 27.5C40 24.5 43.5 20.5 48.5 18C52 16.5 56.5 16.5 61.5 17.5C63 17.8 63 19 61 20L56.5 23.5C59.5 23.5 61.5 25.5 61 27.5L53.5 31.5C56 31.5 57.5 33.5 57 35.5L48.5 39.5C50 40 51.5 41.5 50.5 43.5L43.5 47C40 47.5 37 46.5 35 43Z"
        fill="#1e1302"
      />

      {/* Wing Feathers */}
      {/* Feather 1 (Top) */}
      <path
        d="M48.5 19.5C52.5 18 56.5 18 59.5 18.5C60.5 18.7 60 19.5 57 21C53 23 48.5 25.5 44 28"
        fill="#ffffff"
        stroke="#1e1302"
        strokeWidth="1"
      />

      {/* Feather 2 */}
      <path
        d="M44.5 28C48.5 25 53 23 57 21.5C59 23 59.5 24.5 59.5 26C59.5 27 58 28 54 29.5C49.5 31 45 32.5 40.5 34.5"
        fill={`url(#${id}-wing)`}
        stroke="#1e1302"
        strokeWidth="1"
      />

      {/* Feather 3 */}
      <path
        d="M41 34.5C45.5 32.5 50 31 54 29.5C55.5 30.5 56.5 32 56.5 33.5C56.5 34.5 54.5 35.5 50.5 37C46.5 38.5 42.5 39.5 38.5 40.5"
        fill="#e2e8f0"
        stroke="#1e1302"
        strokeWidth="1"
      />

      {/* Feather 4 (Bottom) */}
      <path
        d="M38.5 40.5C42.5 39.5 46.5 38.5 50.5 37C51.5 38 51.5 39.5 50 41C48.5 42.5 45.5 44.5 42.5 45.5C39.5 46.5 37.5 45.5 36.5 43"
        fill="#cbd5e1"
        stroke="#1e1302"
        strokeWidth="1"
      />

      {/* Attachment rivet */}
      <circle cx="37" cy="42" r="3" fill="#ff9f43" stroke="#1e1302" strokeWidth="1" />
      <circle cx="37.5" cy="41.5" r="0.8" fill="#ffffff" />
    </svg>
  );
}

/** @deprecated Use GoldenHelmetIcon instead */
export const HermesHelmetIcon = GoldenHelmetIcon;

export default function Navbar() {
  const [user, setUser] = useState<User | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((d) => setUser(d.user ?? null))
      .catch(() => { });
  }, []);

  async function handleLogout() {
    await fetch("/api/auth/logout", { method: "POST" });
    setUser(null);
    window.location.href = "/";
  }

  const links = [
    { href: "/", label: "Home" },
    { href: "/rifas", label: "Rifas" },
    { href: "/ranking", label: "Ranking" },
    { href: "/provably-fair", label: "Fair" },
  ];

  if (user?.role === "ADMIN") {
    links.push({ href: "/admin", label: "Admin" });
  }

  return (
    <header className="navbar">
      <div className="navbar-inner">
        <Link href="/" className="navbar-logo">
          <GoldenHelmetIcon size={30} />
          <span>OT DA SORTE</span>
        </Link>

        <nav className="navbar-links">
          {links.map((link, i) => (
            <span key={link.href} style={{ display: "flex", alignItems: "center" }}>
              {i > 0 && <div className="nav-divider" />}
              <Link
                href={link.href}
                className={`nav-link ${pathname === link.href ? "active" : ""}`}
              >
                {link.label}
              </Link>
            </span>
          ))}
        </nav>

        {user ? (
          <div className="nav-user nav-user-desktop">
            <Link href="/perfil">
              {user.avatar ? (
                <img src={user.avatar} alt={user.username} className="nav-avatar" />
              ) : (
                <div
                  className="nav-avatar"
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    background: "#2a1f0e",
                    fontFamily: "var(--font-title)",
                    color: "var(--gold)",
                    fontSize: 14,
                    fontWeight: 700,
                  }}
                >
                  {user.username[0].toUpperCase()}
                </div>
              )}
            </Link>
            <Link href="/perfil" className="nav-username">{user.username}</Link>
            <button className="nav-logout" onClick={handleLogout}>Sair</button>
          </div>
        ) : (
          <Link href="/login" className="nav-cta nav-cta-desktop">Entrar</Link>
        )}

        <button className="hamburger" onClick={() => setMenuOpen(true)}>☰</button>
      </div>

      {/* Mobile overlay */}
      {menuOpen && (
        <div className="mobile-overlay" onClick={() => setMenuOpen(false)}>
          <button className="mobile-close" onClick={() => setMenuOpen(false)}>✕</button>
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`nav-link ${pathname === link.href ? "active" : ""}`}
              style={{ fontSize: 16, padding: "14px 24px" }}
              onClick={() => setMenuOpen(false)}
            >
              {link.label}
            </Link>
          ))}
          {user ? (
            <>
              <Link href="/perfil" className="nav-link" onClick={() => setMenuOpen(false)}>
                👤 {user.username}
              </Link>
              <button className="nav-logout" onClick={handleLogout}>Sair</button>
            </>
          ) : (
            <Link href="/login" className="nav-cta" onClick={() => setMenuOpen(false)}>Entrar</Link>
          )}
        </div>
      )}
    </header>
  );
}
