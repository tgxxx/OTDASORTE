import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import bcrypt from "bcryptjs";

export async function POST(req: NextRequest) {
  try {
    const { token, password } = await req.json();
    if (!token || !password) {
      return NextResponse.json({ error: "Token e nova senha são obrigatórios" }, { status: 400 });
    }

    if (password.length < 6) {
      return NextResponse.json({ error: "A nova senha deve ter no mínimo 6 caracteres" }, { status: 400 });
    }

    const user = await prisma.user.findFirst({
      where: {
        resetToken: token,
      },
    });

    if (!user) {
      return NextResponse.json({ error: "Token de recuperação inválido ou já utilizado." }, { status: 400 });
    }

    if (user.resetTokenExpires && user.resetTokenExpires < new Date()) {
      return NextResponse.json({ error: "Token de recuperação expirado. Solicite outro envio." }, { status: 400 });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    // Atualizar a senha e limpar tokens de reset
    await prisma.user.update({
      where: { id: user.id },
      data: {
        password: hashedPassword,
        resetToken: null,
        resetTokenExpires: null,
      },
    });

    return NextResponse.json({ success: true, message: "Sua senha foi redefinida com sucesso! Você já pode entrar." });
  } catch (err) {
    console.error("[reset-password]", err);
    return NextResponse.json({ error: "Erro interno no servidor" }, { status: 500 });
  }
}
