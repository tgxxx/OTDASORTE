import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";

export async function GET() {
  const users = await prisma.user.findMany({
    orderBy: { xp: "desc" },
    take: 20,
    select: { id: true, username: true, xp: true, level: true, _count: { select: { tickets: true } } },
  });
  return NextResponse.json({ users });
}
