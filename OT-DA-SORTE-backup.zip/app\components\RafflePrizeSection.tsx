import React from "react";

export interface RaffleData {
  id: string;
  title: string;
  description: string;
  image: string | null;
  price: number;
  totalTickets: number;
  soldTickets: number;
  status: string;
  createdAt: Date;
}

interface Props {
  raffle: RaffleData | null;
}

/**
 * RafflePrizeSection
 * Exibe dinamicamente os dados da última rifa cadastrada no banco.
 * Pode ser usada como Server Component (sem hooks de cliente).
 */
export default function RafflePrizeSection({ raffle }: Props) {
  // ─── Fallback: nenhuma rifa cadastrada ───────────────────────────────────
  if (!raffle) {
    return (
      <section style={s.section}>
        <SectionTitle>✦ PRÊMIO DA RIFA ✦</SectionTitle>
        <p style={s.sectionSub}>O vencedor leva o seguinte prêmio</p>
        <div style={s.prizeCard}>
          <div style={{ textAlign: "center", padding: "32px 16px" }}>
            <div style={{ fontSize: 48, marginBottom: 12 }}>🏆</div>
            <p style={{ color: "#a8865a", fontStyle: "italic", fontSize: 15 }}>
              Nenhuma rifa ativa no momento.
            </p>
            <p style={{ color: "#5a4318", fontSize: 13, marginTop: 6 }}>
              Aguarde o anúncio da próxima batalha lendária!
            </p>
          </div>
        </div>
      </section>
    );
  }

  // ─── Status badge ─────────────────────────────────────────────────────────
  const isActive = raffle.status === "active";
  const statusLabel = isActive ? "⚔️ Ativa" : "🔒 Encerrada";
  const statusColor = isActive ? "#27ae60" : "#8b2020";
  const statusBg = isActive ? "rgba(39,174,96,0.12)" : "rgba(139,32,32,0.12)";
  const statusBorder = isActive ? "#27ae60" : "#8b2020";

  // ─── Prize info grid (dados reais da rifa) ────────────────────────────────
  const prizeStats: Array<{ icon: string; label: string; value: string }> = [
    {
      icon: "💰",
      label: "Valor do Bilhete",
      value: `R$ ${raffle.price.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`,
    },
    {
      icon: "🎟️",
      label: "Total de Bilhetes",
      value: raffle.totalTickets.toLocaleString("pt-BR"),
    },
    {
      icon: "👥",
      label: "Bilhetes Vendidos",
      value: raffle.soldTickets.toLocaleString("pt-BR"),
    },
    {
      icon: "🔓",
      label: "Restantes",
      value: (raffle.totalTickets - raffle.soldTickets).toLocaleString("pt-BR"),
    },
    {
      icon: "📊",
      label: "Status",
      value: isActive ? "Ativa" : "Encerrada",
    },
    {
      icon: "📅",
      label: "Criada em",
      value: new Date(raffle.createdAt).toLocaleDateString("pt-BR"),
    },
  ];

  return (
    <section style={s.section}>
      <SectionTitle>✦ PRÊMIO DA RIFA ✦</SectionTitle>
      <p style={s.sectionSub}>O vencedor leva o seguinte prêmio</p>

      <div style={s.prizeCard}>
        {/* ── Cabeçalho do prêmio ─────────────────────────────────────── */}
        <div style={s.prizeHeader}>
          {/* Ícone / imagem da rifa */}
          <div style={s.prizeIconBox}>
            {raffle.image ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={raffle.image}
                alt={raffle.title}
                style={{
                  width: "100%",
                  height: "100%",
                  objectFit: "contain",
                  padding: 6,
                  borderRadius: 4,
                }}
              />
            ) : (
              <span style={{ fontSize: 32 }}>🏆</span>
            )}
          </div>

          {/* Título e descrição */}
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
              <h2 style={s.prizeName}>{raffle.title}</h2>
              {/* Badge de status dinâmico */}
              <span
                style={{
                  fontSize: 11,
                  fontFamily: "'Cinzel',serif",
                  letterSpacing: 1,
                  padding: "3px 10px",
                  borderRadius: 20,
                  border: `1px solid ${statusBorder}`,
                  background: statusBg,
                  color: statusColor,
                  whiteSpace: "nowrap" as const,
                }}
              >
                {statusLabel}
              </span>
            </div>
            <p style={s.prizeDesc}>{raffle.description}</p>
          </div>
        </div>

        {/* ── Grid de informações da rifa (dados reais) ───────────────── */}
        <div style={s.prizeGrid}>
          {prizeStats.map((item) => (
            <div key={item.label} style={s.prizeItem}>
              <span style={{ fontSize: 26 }}>{item.icon}</span>
              <span style={s.prizeItemName}>{item.label}</span>
              <span style={s.prizeItemVal}>{item.value}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── Sub-componentes ────────────────────────────────────────────────────────
function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <h2
      style={{
        fontFamily: "'Cinzel',serif",
        fontSize: "clamp(18px,3vw,24px)",
        color: "#d4af37",
        textAlign: "center" as const,
        marginBottom: 8,
        letterSpacing: 2,
      }}
    >
      {children}
    </h2>
  );
}

// ─── Estilos ────────────────────────────────────────────────────────────────
const s: Record<string, React.CSSProperties> = {
  section: { maxWidth: 1100, margin: "0 auto", padding: "36px 20px" },
  sectionSub: {
    textAlign: "center",
    color: "#a8865a",
    marginBottom: 24,
    fontStyle: "italic",
    fontFamily: "'Crimson Text',serif",
  },
  prizeCard: {
    background: "#1a1409",
    border: "1px solid #5a4318",
    borderRadius: 8,
    padding: 24,
  },
  prizeHeader: {
    display: "flex",
    alignItems: "flex-start",
    gap: 16,
    marginBottom: 20,
    flexWrap: "wrap" as const,
  },
  prizeIconBox: {
    width: 72,
    height: 72,
    flexShrink: 0,
    background: "#231b0d",
    border: "2px solid #7a5c22",
    borderRadius: 6,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
  },
  prizeName: {
    fontFamily: "'Cinzel',serif",
    color: "#d4af37",
    fontSize: "clamp(16px,2.5vw,20px)",
    margin: 0,
  },
  prizeDesc: {
    color: "#a8865a",
    fontSize: 14,
    marginTop: 6,
    lineHeight: 1.6,
    fontFamily: "'Crimson Text',serif",
    display: "-webkit-box",
    WebkitLineClamp: 3,
    WebkitBoxOrient: "vertical" as const,
    overflow: "hidden",
  },
  prizeGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(140px,1fr))",
    gap: 12,
    marginTop: 4,
  },
  prizeItem: {
    background: "#231b0d",
    border: "1px solid #3d2e0f",
    borderRadius: 6,
    padding: "12px 10px",
    textAlign: "center",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: 4,
  },
  prizeItemName: {
    fontFamily: "'Cinzel',serif",
    fontSize: 11,
    color: "#d4b87a",
    letterSpacing: 0.5,
  },
  prizeItemVal: { fontSize: 12, color: "#d4af37", fontWeight: 600 },
};
