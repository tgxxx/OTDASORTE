import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { mpPayment } from "@/lib/mercadopago";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    console.log("[webhook mp]", JSON.stringify(body));

    // Mercado Pago envia type: "payment" com data.id
    if (body.type !== "payment") {
      return NextResponse.json({ ok: true });
    }

    const paymentId = body.data?.id;
    if (!paymentId) return NextResponse.json({ ok: true });

    // Consulta o pagamento no MP para confirmar status real
    let mpData: any;
    try {
      mpData = await mpPayment.get({ id: paymentId });
    } catch {
      return NextResponse.json({ error: "Pagamento nao encontrado no MP" }, { status: 404 });
    }

    if (mpData.status !== "approved") {
      return NextResponse.json({ ok: true, status: mpData.status });
    }

    // Busca o payment local pelo mp payment id (armazenado em pixCode)
    const payment = await prisma.payment.findFirst({
      where: { pixCode: String(paymentId) },
    });

    if (!payment) {
      console.warn("[webhook] payment nao encontrado localmente, id:", paymentId);
      return NextResponse.json({ ok: true });
    }

    if (payment.status === "APPROVED") {
      return NextResponse.json({ ok: true, msg: "ja processado" });
    }

    // Calcula quantidade de bilhetes (amount / preco da rifa)
    const raffle = await prisma.raffle.findFirst({ where: { status: "active" } });
    if (!raffle) throw new Error("Rifa ativa nao encontrada");

    const quantity = Math.max(1, Math.floor(payment.amount / raffle.price));

    let ticketNumbers: number[] = [];
    let transactionSuccess = false;
    let attempts = 0;

    // Retry loop for handling potential concurrent ticket collision unique constraint violations
    while (!transactionSuccess && attempts < 5) {
      attempts++;

      // 1. Get currently sold numbers for this raffle
      const existingNumbers = await prisma.ticket.findMany({
        where: { raffleId: raffle.id },
        select: { number: true },
      });
      const usedNumbers = new Set(existingNumbers.map((t) => t.number));

      // Check capacity
      const availableCount = raffle.totalTickets - usedNumbers.size;
      if (availableCount < quantity) {
        return NextResponse.json({ error: "Rifa esgotada ou sem quantidade disponível de bilhetes" }, { status: 400 });
      }

      // 2. Select unique random ticket numbers (1-indexed)
      ticketNumbers = [];
      let selectionAttempts = 0;
      while (ticketNumbers.length < quantity && selectionAttempts < 20000) {
        const n = Math.floor(Math.random() * raffle.totalTickets) + 1;
        if (!usedNumbers.has(n) && !ticketNumbers.includes(n)) {
          ticketNumbers.push(n);
        }
        selectionAttempts++;
      }

      if (ticketNumbers.length < quantity) {
        throw new Error("Falha ao gerar números de bilhetes únicos aleatórios");
      }

      try {
        // 3. Interactive Transaction to ensure atomicity
        await prisma.$transaction(async (tx) => {
          // Double check payment status to avoid duplicate processing in concurrent threads
          const checkPayment = await tx.payment.findUnique({
            where: { id: payment.id },
          });

          if (checkPayment?.status === "APPROVED") {
            throw new Error("PAYMENT_ALREADY_APPROVED");
          }

          // Approve payment
          await tx.payment.update({
            where: { id: payment.id },
            data: { status: "APPROVED" },
          });

          // Insert tickets (fails if database @@unique([raffleId, number]) is violated)
          await tx.ticket.createMany({
            data: ticketNumbers.map((number) => ({
              number,
              raffleId: raffle.id,
              userId: payment.userId,
              paymentId: payment.id,
            })),
          });

          // Update raffle sales count
          await tx.raffle.update({
            where: { id: raffle.id },
            data: { soldTickets: { increment: ticketNumbers.length } },
          });

          // Award player XP (10 XP per ticket purchased)
          await tx.user.update({
            where: { id: payment.userId },
            data: { xp: { increment: ticketNumbers.length * 10 } },
          });

          // --- Affiliate & Commission Distribution ---
          const buyer = await tx.user.findUnique({
            where: { id: payment.userId },
            select: { referredById: true },
          });

          if (buyer?.referredById) {
            const referrer = await tx.user.findUnique({
              where: { id: buyer.referredById },
              select: { id: true, affiliateCommission: true },
            });

            if (referrer) {
              const commissionAmount = payment.amount * (referrer.affiliateCommission / 100);

              // Increment referrer commission balance
              await tx.user.update({
                where: { id: referrer.id },
                data: { commissionBalance: { increment: commissionAmount } },
              });

              // Log commission earning
              await tx.commissionEarning.create({
                data: {
                  referrerId: referrer.id,
                  referredId: payment.userId,
                  paymentId: payment.id,
                  amount: commissionAmount,
                },
              });
            }
          }
        });

        transactionSuccess = true;
      } catch (txErr: any) {
        if (txErr.message === "PAYMENT_ALREADY_APPROVED") {
          return NextResponse.json({ ok: true, msg: "ja processado" });
        }
        console.warn(`[webhook race retry] Concurrency collision on ticket purchase, attempt ${attempts}/5. Retrying...`, txErr.message || txErr);
      }
    }

    if (!transactionSuccess) {
      throw new Error("Transação falhou persistentemente após retentativas de condição de corrida");
    }

    console.log("[webhook] aprovado com sucesso:", quantity, "bilhetes para o usuário", payment.userId);

    return NextResponse.json({ success: true, tickets: ticketNumbers.length });
  } catch (err) {
    console.error("[webhook error]", err);
    return NextResponse.json({ error: "Erro webhook" }, { status: 500 });
  }
}
