type RateLimitEntry = {
  hits: number;
  resetTime: number;
};

const rateLimitMap = new Map<string, RateLimitEntry>();

/**
 * Checks if a given identifier (e.g. IP address) has exceeded the rate limit.
 * @param key The identifier to limit (e.g. IP or email).
 * @param limit Max number of requests allowed in the window.
 * @param windowMs Time window in milliseconds.
 * @returns true if the request is allowed, false if limit is exceeded.
 */
export function checkRateLimit(key: string, limit: number, windowMs: number): boolean {
  const now = Date.now();
  const entry = rateLimitMap.get(key);

  if (!entry) {
    rateLimitMap.set(key, { hits: 1, resetTime: now + windowMs });
    return true;
  }

  if (now > entry.resetTime) {
    entry.hits = 1;
    entry.resetTime = now + windowMs;
    return true;
  }

  if (entry.hits >= limit) {
    return false;
  }

  entry.hits += 1;
  return true;
}
