"use client";
import { useState, useEffect } from "react";
import { GoldenHelmetIcon } from "@/components/Navbar";

type Tab = "login" | "register" | "forgot" | "reset" | "verifying" | "verified";

export default function LoginPage() {
  const [tab, setTab] = useState<Tab>("login");
  const [form, setForm] = useState({ username: "", email: "", password: "", confirmPassword: "" });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);
  const [token, setToken] = useState("");

  useEffect(() => {
    // Detect URL query parameters in a client-safe way that won't break Next.js static builds
    const params = new URLSearchParams(window.location.search);
    const verifyToken = params.get("verify");
    const resetToken = params.get("token");

    if (verifyToken) {
      handleVerifyEmail(verifyToken);
    } else if (resetToken) {
      setToken(resetToken);
      setTab("reset");
    }
  }, []);

  async function handleVerifyEmail(verifyToken: string) {
    setTab("verifying");
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/verify-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: verifyToken }),
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        setError(data.error ?? "Erro ao confirmar e-mail. Link inválido ou expirado.");
        setTab("login");
      } else {
        setSuccess(data.message ?? "E-mail confirmado com sucesso!");
        setTab("verified");
      }
    } catch {
      setError("Erro de rede ao confirmar e-mail.");
      setTab("login");
    } finally {
      setLoading(false);
    }
  }

  function setField(key: string, val: string) {
    setForm((f) => ({ ...f, [key]: val }));
  }

  async function handleSubmit(e?: React.FormEvent) {
    if (e) e.preventDefault();
    setError("");
    setSuccess("");
    setLoading(true);

    try {
      if (tab === "login") {
        const res = await fetch("/api/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email: form.email, password: form.password }),
        });
        const data = await res.json();
        if (!res.ok || data.error) {
          setError(data.error ?? "Erro de login");
        } else {
          window.location.href = "/";
        }
      } else if (tab === "register") {
        const res = await fetch("/api/auth/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            username: form.username,
            email: form.email,
            password: form.password,
          }),
        });
        const data = await res.json();
        if (!res.ok || data.error) {
          setError(data.error ?? "Erro no cadastro");
        } else {
          setSuccess(data.message ?? "Cadastro efetuado! Confirme seu e-mail.");
          setTab("login");
          // Clear password but keep email
          setForm(f => ({ ...f, password: "", username: "" }));
        }
      } else if (tab === "forgot") {
        const res = await fetch("/api/auth/forgot-password", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email: form.email }),
        });
        const data = await res.json();
        if (!res.ok || data.error) {
          setError(data.error ?? "Erro ao solicitar recuperação");
        } else {
          setSuccess(data.message ?? "Se o e-mail existir, enviamos o link!");
          setForm(f => ({ ...f, password: "", username: "" }));
        }
      } else if (tab === "reset") {
        if (form.password !== form.confirmPassword) {
          setError("As senhas não coincidem.");
          setLoading(false);
          return;
        }
        const res = await fetch("/api/auth/reset-password", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ token, password: form.password }),
        });
        const data = await res.json();
        if (!res.ok || data.error) {
          setError(data.error ?? "Erro ao redefinir a senha");
        } else {
          setSuccess(data.message ?? "Senha redefinida com sucesso!");
          setTab("login");
          setForm(f => ({ ...f, password: "", confirmPassword: "" }));
        }
      }
    } catch {
      setError("Erro de conexão");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={s.bg}>
      <div style={s.card} className="animate-fade-in">
        {/* Crown Icon */}
        <div style={s.crown}>
          <GoldenHelmetIcon size={56} />
        </div>
        <h1 style={s.title}>OT da Sorte</h1>
        
        {tab === "login" && <p style={s.sub}>Acesse sua conta para forjar sua sorte</p>}
        {tab === "register" && <p style={s.sub}>Escreva seu nome no pergaminho de guerreiros</p>}
        {tab === "forgot" && <p style={s.sub}>Conjuque a prece de restauração de senha</p>}
        {tab === "reset" && <p style={s.sub}>Insira os pergaminhos da sua nova senha</p>}
        {tab === "verifying" && <p style={s.sub}>Auditando verificação criptográfica...</p>}
        {tab === "verified" && <p style={s.sub}>Identidade confirmada com sucesso!</p>}

        {/* Tab selection bar (only on login/register views) */}
        {(tab === "login" || tab === "register") && (
          <div style={s.tabs}>
            <button
              style={{ ...s.tab, ...(tab === "login" ? s.tabActive : {}) }}
              onClick={() => { setTab("login"); setError(""); setSuccess(""); }}
            >
              Entrar
            </button>
            <button
              style={{ ...s.tab, ...(tab === "register" ? s.tabActive : {}) }}
              onClick={() => { setTab("register"); setError(""); setSuccess(""); }}
            >
              Criar Conta
            </button>
          </div>
        )}

        {/* Info Feedbacks */}
        {success && <div style={s.successBox}>✨ {success}</div>}
        {error && <div style={s.errorBox}>⚠️ {error}</div>}

        {/* Loading state for verification */}
        {tab === "verifying" && (
          <div style={{ padding: "24px 0", display: "flex", flexDirection: "column", alignItems: "center", gap: 16 }}>
            <div className="login-spinner" />
            <span style={{ fontSize: 13, color: "var(--cream3)", fontStyle: "italic" }}>Contatando os anciões do reino...</span>
          </div>
        )}

        {/* Success verification state */}
        {tab === "verified" && (
          <div style={{ padding: "16px 0", textAlign: "center" }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>🏆</div>
            <p style={{ color: "var(--cream2)", fontSize: 14, fontStyle: "italic", marginBottom: 24 }}>
              Seu e-mail foi validado! Sua conta está 100% ativa no reino.
            </p>
            <button style={s.btn} onClick={() => { setTab("login"); setSuccess(""); }}>
              ⚡ FAZER LOGIN AGORA
            </button>
          </div>
        )}

        {/* Standard Form Forms */}
        {tab !== "verifying" && tab !== "verified" && (
          <form onSubmit={handleSubmit} style={s.form}>
            {tab === "register" && (
              <input
                style={s.input}
                placeholder="Nome de usuário (RPG Nick)"
                value={form.username}
                onChange={(e) => setField("username", e.target.value)}
                required
              />
            )}
            
            {tab !== "reset" && (
              <input
                style={s.input}
                placeholder="Pergaminho de E-mail"
                type="email"
                value={form.email}
                onChange={(e) => setField("email", e.target.value)}
                required
              />
            )}

            {tab !== "forgot" && (
              <input
                style={s.input}
                placeholder={tab === "reset" ? "Nova Senha" : "Senha Secreta"}
                type="password"
                value={form.password}
                onChange={(e) => setField("password", e.target.value)}
                required
              />
            )}

            {tab === "reset" && (
              <input
                style={s.input}
                placeholder="Confirmar Nova Senha"
                type="password"
                value={form.confirmPassword}
                onChange={(e) => setField("confirmPassword", e.target.value)}
                required
              />
            )}

            {/* Forgot password link only on login screen */}
            {tab === "login" && (
              <div style={{ textAlign: "right", marginTop: -4 }}>
                <span
                  style={{ color: "#a8865a", fontSize: 12, cursor: "pointer", textDecoration: "underline" }}
                  onClick={() => { setTab("forgot"); setError(""); setSuccess(""); }}
                >
                  Esqueceu sua senha?
                </span>
              </div>
            )}

            <button style={{ ...s.btn, opacity: loading ? 0.7 : 1 }} type="submit" disabled={loading}>
              {loading
                ? "Conjurando..."
                : tab === "login"
                ? "⚡ ENTRAR NO REINO"
                : tab === "register"
                ? "⚡ CADASTRAR FICHA"
                : tab === "forgot"
                ? "⚡ SOLICITAR ACESSO"
                : "⚡ REDEFINIR SENHA"}
            </button>
          </form>
        )}

        {/* Bottom Switch Links */}
        {tab === "forgot" && (
          <p style={s.note}>
            Lembrou a senha?{" "}
            <span style={s.noteLink} onClick={() => { setTab("login"); setError(""); setSuccess(""); }}>
              Voltar ao login
            </span>
          </p>
        )}

        {tab === "reset" && (
          <p style={s.note}>
            Voltar para o{" "}
            <span style={s.noteLink} onClick={() => { setTab("login"); setError(""); setSuccess(""); }}>
              Login
            </span>
          </p>
        )}

        {(tab === "login" || tab === "register") && (
          <p style={s.note}>
            {tab === "login" ? "Não possui uma ficha? " : "Já possui um personagem? "}
            <span
              style={s.noteLink}
              onClick={() => {
                setTab(tab === "login" ? "register" : "login");
                setError("");
                setSuccess("");
              }}
            >
              {tab === "login" ? "Cadastrar agora" : "Fazer login"}
            </span>
          </p>
        )}
      </div>

      <style jsx global>{`
        .login-spinner {
          display: inline-block;
          width: 32px;
          height: 32px;
          border: 3px solid rgba(212,175,55,0.1);
          border-top-color: var(--gold);
          border-radius: 50%;
          animation: spin 0.8s linear infinite;
        }
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}

const s: Record<string, React.CSSProperties> = {
  bg: {
    minHeight: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    background: "radial-gradient(ellipse 80% 40% at 50% 0%,rgba(201,162,39,0.08) 0%,transparent 60%), #0a0704",
    padding: 20,
    color: "var(--cream)",
  },
  card: {
    background: "#1a1409",
    border: "1px solid #5a4318",
    borderRadius: 10,
    padding: "40px 36px",
    width: "100%",
    maxWidth: 420,
    textAlign: "center" as const,
    boxShadow: "0 10px 40px rgba(0,0,0,0.5)",
  },
  crown: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 12,
  },
  title: {
    fontFamily: "'Cinzel',serif",
    color: "#d4af37",
    fontSize: 26,
    marginBottom: 6,
    letterSpacing: "2px",
  },
  sub: {
    color: "#a8865a",
    fontSize: 13,
    fontStyle: "italic",
    marginBottom: 24,
    fontFamily: "'Crimson Text',serif",
  },
  tabs: {
    display: "flex",
    background: "#110e08",
    borderRadius: 6,
    padding: 4,
    marginBottom: 24,
    gap: 4,
  },
  tab: {
    flex: 1,
    padding: "9px 0",
    background: "transparent",
    border: "none",
    color: "#a8865a",
    cursor: "pointer",
    borderRadius: 4,
    fontFamily: "'Cinzel',serif",
    fontSize: 13,
    transition: "all 0.2s",
  },
  tabActive: {
    background: "#2a1f0e",
    color: "#d4af37",
    border: "1px solid #5a4318",
  },
  form: {
    display: "flex",
    flexDirection: "column" as const,
    gap: 14,
  },
  input: {
    padding: "13px 16px",
    background: "#0a0704",
    border: "1px solid #3d2e0f",
    color: "#f0dfa8",
    borderRadius: 6,
    fontSize: 14,
    outline: "none",
    transition: "border-color 0.2s",
  },
  errorBox: {
    background: "rgba(180,30,30,0.12)",
    border: "1px solid #8b2020",
    color: "#e57373",
    borderRadius: 6,
    padding: "10px 14px",
    fontSize: 13,
    textAlign: "left",
    marginBottom: 14,
  },
  successBox: {
    background: "rgba(39, 174, 96, 0.08)",
    border: "1px solid #27ae60",
    color: "#a3e2bc",
    borderRadius: 6,
    padding: "10px 14px",
    fontSize: 13,
    textAlign: "left",
    marginBottom: 14,
  },
  btn: {
    padding: "15px 0",
    background: "linear-gradient(180deg,#d4af37 0%,#8a6a10 100%)",
    border: "none",
    color: "#0a0704",
    fontFamily: "'Cinzel',serif",
    fontSize: 13,
    letterSpacing: 2,
    cursor: "pointer",
    borderRadius: 6,
    fontWeight: 700,
    marginTop: 4,
    textTransform: "uppercase" as const,
    boxShadow: "0 4px 12px rgba(212,175,55,0.15)",
  },
  note: {
    color: "#a8865a",
    fontSize: 12,
    marginTop: 20,
    fontFamily: "'Crimson Text',serif",
  },
  noteLink: {
    color: "#d4af37",
    cursor: "pointer",
    textDecoration: "underline",
  },
};
