import { NextRequest, NextResponse } from "next/server";

interface TokenPayload {
  id: string;
  email: string;
  username: string;
  role: string;
}

function decodeJwt(token: string): TokenPayload | null {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;

    const payload = parts[1];
    const base64 = payload.replace(/-/g, "+").replace(/_/g, "/");
    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split("")
        .map((c) => "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2))
        .join("")
    );

    return JSON.parse(jsonPayload) as TokenPayload;
  } catch {
    return null;
  }
}

export function middleware(req: NextRequest) {
  const token = req.cookies.get("token")?.value;
  const url = req.nextUrl.pathname;

  // Track referral links (?ref=CODE) on any page visit
  const refCode = req.nextUrl.searchParams.get("ref");
  
  let response = NextResponse.next();

  if (url.startsWith("/admin")) {
    if (!token) {
      response = NextResponse.redirect(new URL("/login", req.url));
    } else {
      const decoded = decodeJwt(token);
      if (!decoded || decoded.role !== "ADMIN") {
        response = NextResponse.redirect(new URL("/", req.url));
      }
    }
  }

  // Set the referral cookie for 30 days
  if (refCode) {
    response.cookies.set("ref", refCode, {
      httpOnly: true,
      maxAge: 60 * 60 * 24 * 30, // 30 days
      path: "/",
      sameSite: "lax",
    });
  }

  return response;
}

export const config = {
  matcher: [
    "/((?!api|_next/static|_next/image|favicon.ico).*)"
  ],
};
