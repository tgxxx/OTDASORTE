"use client";

import { useEffect, useState } from "react";

interface Raffle {
  id: string;
  title: string;
  price: number;
  totalTickets: number;
  soldTickets: number;
  status: string;
  winningTicketNumber?: number | null;
  serverSeedHash?: string | null;
  drawDate?: string | null;
}

interface Stats {
  users: number;
  tickets: number;
  revenue: number;
  raffles: number;
}

export default function AdminPage() {
  const [raffles, setRaffles] = useState<Raffle[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [form, setForm] = useState({
    title: "Pack Lendário do Guerreiro",
    description: "Contém 1x Demon Armor, 1x Golden Legs e 50.000 GP para iniciar sua jornada com poder total!",
    price: "5",
    totalTickets: "500",
    image: "https://i.imgur.com/8Fk3UeA.png",
  });
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(false);
  const [tab, setTab] = useState<"dashboard" | "create">("dashboard");

  // Federal Lottery Draw State
  const [federalContests, setFederalContests] = useState<Record<string, string>>({});
  const [drawResult, setDrawResult] = useState<any>(null);
  const [drawingRaffleId, setDrawingRaffleId] = useState<string | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      const [rRes, sRes] = await Promise.all([
        fetch("/api/raffles"),
        fetch("/api/admin/stats"),
      ]);
      const rData = await rRes.json();
      setRaffles(Array.isArray(rData) ? rData : []);
      if (sRes.ok) {
        setStats(await sRes.json());
      }
    } catch (err) {
      console.error(err);
    }
  }

  function setField(k: string, v: string) {
    setForm((f) => ({ ...f, [k]: v }));
  }

  async function createRaffle() {
    setMsg("");
    setLoading(true);
    try {
      const res = await fetch("/api/raffles", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          price: Number(form.price),
          totalTickets: Number(form.totalTickets),
        }),
      });
      const data = await res.json();
      if (data.success) {
        setMsg("✅ Rifa criada com sucesso!");
        setForm({
          title: "",
          description: "",
          price: "",
          totalTickets: "",
          image: "",
        });
        loadData();
        setTab("dashboard");
      } else {
        setMsg("❌ " + (data.error ?? "Erro ao criar a rifa"));
      }
    } catch {
      setMsg("❌ Erro de conexão com o servidor");
    } finally {
      setLoading(false);
    }
  }

  async function handleDraw(raffleId: string) {
    setDrawResult(null);
    setDrawingRaffleId(raffleId);
    
    const federalContest = federalContests[raffleId] || "";

    try {
      const res = await fetch(`/api/admin/raffles/${raffleId}/draw`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ federalContest }),
      });
      const data = await res.json();
      if (!res.ok) {
        alert(data.error || "Erro ao realizar o sorteio");
      } else {
        setDrawResult(data.raffle);
        loadData(); // Refresh list to show ended status
      }
    } catch (err) {
      console.error(err);
      alert("Erro ao realizar o sorteio.");
    } finally {
      setDrawingRaffleId(null);
    }
  }

  async function handleDeleteRaffle(id: string) {
    if (!confirm("Tem certeza que deseja deletar esta rifa? Todos os bilhetes comprados desta rifa serão perdidos definitivamente!")) return;
    try {
      const res = await fetch(`/api/raffles?id=${id}`, {
        method: "DELETE",
      });
      const data = await res.json();
      if (data.success) {
        alert("✅ Rifa deletada com sucesso!");
        loadData();
      } else {
        alert("❌ " + (data.error ?? "Erro ao deletar rifa"));
      }
    } catch (err) {
      console.error(err);
      alert("Erro de conexão ao deletar rifa.");
    }
  }

  return (
    <div style={{ minHeight: "100vh", background: "var(--dark)", color: "var(--cream)" }}>
      {/* Header Banner */}
      <div
        style={{
          background: "linear-gradient(180deg, var(--dark2) 0%, var(--dark3) 100%)",
          borderBottom: "1px solid var(--border)",
          padding: "32px 24px 0",
        }}
      >
        <div className="container" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "16px", marginBottom: "20px" }}>
          <div>
            <h1 style={{ fontSize: "28px", display: "flex", alignItems: "center", gap: "12px" }}>
              <span>⚙️</span> PAINEL DE CONTROLE
            </h1>
            <p style={{ color: "var(--cream3)", fontSize: "14px", fontStyle: "italic", marginTop: "4px" }}>
              Gerenciamento de rifas, estatísticas de vendas e sorteios Provably Fair
            </p>
          </div>
          <div className="tabs" style={{ width: "auto" }}>
            <button
              className={`tab ${tab === "dashboard" ? "tab-active" : ""}`}
              onClick={() => setTab("dashboard")}
            >
              Dashboard
            </button>
            <button
              className={`tab ${tab === "create" ? "tab-active" : ""}`}
              onClick={() => setTab("create")}
            >
              Criar Rifa
            </button>
          </div>
        </div>
      </div>

      <div className="container" style={{ padding: "40px 20px" }}>
        
        {/* Draw Result Success Modal Box */}
        {drawResult && (
          <div
            className="card card-gold animate-fade-in"
            style={{
              background: "rgba(39, 174, 96, 0.08)",
              border: "2px solid var(--green2)",
              marginBottom: "32px",
              padding: "28px",
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div>
                <h3 style={{ color: "var(--green2)", fontSize: "20px", display: "flex", alignItems: "center", gap: "8px" }}>
                  🏆 SORTEIO REALIZADO COM SUCESSO!
                </h3>
                <p style={{ color: "var(--cream2)", fontSize: "15px", marginTop: "4px" }}>
                  A rifa <strong>{drawResult.title}</strong> possui um vencedor oficial auditado!
                </p>
              </div>
              <button
                onClick={() => setDrawResult(null)}
                style={{
                  background: "transparent",
                  border: "none",
                  color: "var(--cream3)",
                  fontSize: "20px",
                  cursor: "pointer",
                }}
              >
                ✕
              </button>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "16px", marginTop: "24px" }}>
              <div style={{ background: "var(--dark2)", border: "1px solid var(--border)", padding: "14px", borderRadius: "var(--radius-sm)" }}>
                <span style={{ fontSize: "10px", color: "var(--cream3)", textTransform: "uppercase", display: "block" }}>Ganhador</span>
                <strong style={{ color: "var(--gold)", fontSize: "18px", fontFamily: "var(--font-title)", display: "block", marginTop: "4px" }}>
                  {drawResult.winner}
                </strong>
              </div>
              <div style={{ background: "var(--dark2)", border: "1px solid var(--border)", padding: "14px", borderRadius: "var(--radius-sm)" }}>
                <span style={{ fontSize: "10px", color: "var(--cream3)", textTransform: "uppercase", display: "block" }}>Bilhete Sorteado</span>
                <strong style={{ color: "var(--green2)", fontSize: "18px", fontFamily: "var(--font-title)", display: "block", marginTop: "4px" }}>
                  #{String(drawResult.winningTicketNumber).padStart(3, "0")}
                </strong>
              </div>
              <div style={{ background: "var(--dark2)", border: "1px solid var(--border)", padding: "14px", borderRadius: "var(--radius-sm)" }}>
                <span style={{ fontSize: "10px", color: "var(--cream3)", textTransform: "uppercase", display: "block" }}>Concurso Federal</span>
                <strong style={{ color: "var(--gold)", fontSize: "16px", display: "block", marginTop: "4px" }}>
                  Nº {drawResult.federalContest}
                </strong>
              </div>
              <div style={{ background: "var(--dark2)", border: "1px solid var(--border)", padding: "14px", borderRadius: "var(--radius-sm)" }}>
                <span style={{ fontSize: "10px", color: "var(--cream3)", textTransform: "uppercase", display: "block" }}>1º Prêmio Oficial</span>
                <strong style={{ color: "var(--gold)", fontSize: "16px", display: "block", marginTop: "4px" }}>
                  {drawResult.federal1stPrize}
                </strong>
              </div>
            </div>
            <p style={{ fontSize: "12px", color: "var(--cream3)", fontStyle: "italic", marginTop: "16px" }}>
              * Os jogadores podem auditar este sorteio na página de transparência (Fair) conferindo os números oficiais da Loteria Federal.
            </p>
          </div>
        )}

        {tab === "dashboard" && (
          <>
            {/* Stats Grid */}
            {stats && (
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "16px", marginBottom: "40px" }}>
                <div className="stat-box">
                  <div className="stat-label">Jogadores Cadastrados</div>
                  <div className="stat-value">{stats.users}</div>
                  <span style={{ fontSize: "12px", color: "var(--cream3)" }}>Ficha de aventureiros</span>
                </div>
                <div className="stat-box">
                  <div className="stat-label">Bilhetes Vendidos</div>
                  <div className="stat-value">{stats.tickets}</div>
                  <span style={{ fontSize: "12px", color: "var(--cream3)" }}>Participação active</span>
                </div>
                <div className="stat-box">
                  <div className="stat-label">Arrecadação Bruta</div>
                  <div className="stat-value" style={{ color: "var(--gold)" }}>
                    R$ {(stats.revenue || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                  </div>
                  <span style={{ fontSize: "12px", color: "var(--green2)" }}>Vendas aprovadas PIX</span>
                </div>
                <div className="stat-box">
                  <div className="stat-label font-title">Total de Rifas</div>
                  <div className="stat-value">{stats.raffles}</div>
                  <span style={{ fontSize: "12px", color: "var(--cream3)" }}>Lendárias criadas</span>
                </div>
              </div>
            )}

            {/* Raffles List */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
              <h2 style={{ fontSize: "18px", letterSpacing: "2px" }}>RIFAS CADASTRADAS</h2>
              <button className="btn btn-gold btn-sm" onClick={() => setTab("create")}>+ Nova Rifa</button>
            </div>

            {raffles.length === 0 ? (
              <div className="empty-state">
                <div className="empty-state-icon">🏆</div>
                <div className="empty-state-title">Nenhuma Rifa no Reino</div>
                <div className="empty-state-text" style={{ marginBottom: "20px" }}>Crie uma nova rifa para começar a vender bilhetes!</div>
                <button className="btn btn-gold" onClick={() => setTab("create")}>Criar Primeira Rifa</button>
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
                {raffles.map((r) => {
                  const pct = Math.round((r.soldTickets / r.totalTickets) * 100) || 0;
                  return (
                    <div
                      key={r.id}
                      className="card"
                      style={{
                        display: "flex",
                        flexDirection: "column",
                        gap: "16px",
                        borderLeft: `4px solid ${r.status === "active" ? "var(--gold)" : "var(--border)"}`,
                      }}
                    >
                      {/* Top Row: Raffle Name and Badge */}
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "12px" }}>
                        <div>
                          <strong style={{ fontSize: "16px", color: "var(--gold)" }}>{r.title}</strong>
                          <span style={{ fontSize: "12px", color: "var(--cream3)", display: "block", marginTop: "2px" }}>
                            R$ {r.price.toFixed(2)} por bilhete · {r.soldTickets} / {r.totalTickets} vendidos
                          </span>
                        </div>
                        <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
                          <span className={`badge ${r.status === "active" ? "badge-paid" : "badge-closed"}`}>
                            {r.status === "active" ? "Ativa" : "Encerrada"}
                          </span>
                          <button
                            className="btn btn-danger btn-sm"
                            style={{ padding: "4px 10px", fontSize: "10px", textTransform: "uppercase", background: "rgba(139,26,26,0.3)" }}
                            onClick={() => handleDeleteRaffle(r.id)}
                          >
                            Deletar
                          </button>
                        </div>
                      </div>

                      {/* Progress Tracker */}
                      <div>
                        <div style={{ display: "flex", justifyContent: "space-between", fontSize: "12px", marginBottom: "4px", color: "var(--cream3)" }}>
                          <span>Progresso de Venda</span>
                          <span>{pct}%</span>
                        </div>
                        <div className="progress-track">
                          <div className="progress-fill" style={{ width: `${pct}%` }} />
                        </div>
                      </div>

                      {/* Draw actions for Active Raffles */}
                      {r.status === "active" && (
                        <div
                          style={{
                            background: "var(--dark2)",
                            border: "1px solid var(--border)",
                            borderRadius: "var(--radius-sm)",
                            padding: "16px",
                            display: "flex",
                            flexDirection: "column",
                            gap: "12px",
                            marginTop: "8px",
                          }}
                        >
                          <h4 style={{ color: "var(--gold)", fontSize: "12px", letterSpacing: "1px", textTransform: "uppercase" }}>
                            🔮 Sorteio Real da Loteria Federal (Transparência)
                          </h4>
                          <div style={{ display: "flex", gap: "12px", flexWrap: "wrap" }}>
                            <div style={{ flex: 1, minWidth: "220px" }}>
                              <label className="form-label" style={{ fontSize: "9px" }}>Concurso Federal (Ex: 5865 - Opcional)</label>
                              <input
                                type="text"
                                className="form-input"
                                style={{ width: "100%", padding: "8px 12px", fontSize: "13px" }}
                                placeholder="Deixe em branco para buscar o último concurso oficial"
                                value={federalContests[r.id] || ""}
                                onChange={(e) => setFederalContests({ ...federalContests, [r.id]: e.target.value })}
                              />
                            </div>
                            <div style={{ display: "flex", alignItems: "flex-end" }}>
                              <button
                                className="btn btn-gold"
                                style={{ padding: "10px 20px" }}
                                onClick={() => handleDraw(r.id)}
                                disabled={r.soldTickets === 0 || drawingRaffleId === r.id}
                              >
                                {drawingRaffleId === r.id ? "Sorteando..." : "Realizar Sorteio"}
                              </button>
                            </div>
                          </div>
                          {r.soldTickets === 0 && (
                            <span style={{ fontSize: "12px", color: "var(--red2)", fontStyle: "italic" }}>
                              * Pelo menos 1 bilhete deve ser vendido para habilitar o sorteio.
                            </span>
                          )}
                        </div>
                      )}

                      {/* Info for Closed Raffles */}
                      {r.status === "ended" && (
                        <div
                          style={{
                            background: "rgba(39, 174, 96, 0.04)",
                            border: "1px dashed var(--green2)",
                            borderRadius: "var(--radius-sm)",
                            padding: "14px",
                            fontSize: "13px",
                            display: "grid",
                            gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
                            gap: "12px",
                          }}
                        >
                          <div>
                            <span style={{ color: "var(--cream3)", fontSize: "10px", textTransform: "uppercase" }}>Bilhete Ganhador</span>
                            <strong style={{ color: "var(--green2)", display: "block", fontSize: "15px" }}>
                              #{String(r.winningTicketNumber).padStart(3, "0")}
                            </strong>
                          </div>
                          <div>
                            <span style={{ color: "var(--cream3)", fontSize: "10px", textTransform: "uppercase" }}>Concurso Federal / 1º Prêmio</span>
                            <code style={{ color: "var(--cream2)", fontSize: "10px", display: "block" }}>
                              Concurso {(r as any).federalContest || "N/A"} · Prêmio: {(r as any).federal1stPrize || "N/A"}
                            </code>
                          </div>
                          <div>
                            <span style={{ color: "var(--cream3)", fontSize: "10px", textTransform: "uppercase" }}>Data do Sorteio</span>
                            <span style={{ color: "var(--cream2)", display: "block" }}>
                              {r.drawDate ? new Date(r.drawDate).toLocaleDateString("pt-BR") : "N/A"}
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </>
        )}

        {tab === "create" && (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))", gap: "32px", alignItems: "start" }}>
            
            {/* Raffle Form Box */}
            <div className="card">
              <h3 className="card-title">Nova Rifa</h3>
              <p style={{ color: "var(--cream3)", fontSize: "13px", marginBottom: "24px", fontStyle: "italic" }}>
                Preencha os pergaminhos para forjar uma nova rifa lendária.
              </p>

              <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
                <div className="form-group" style={{ marginBottom: 0 }}>
                  <label className="form-label">Título da Rifa *</label>
                  <input
                    type="text"
                    className="form-input"
                    value={form.title}
                    onChange={(e) => setField("title", e.target.value)}
                    placeholder="Ex: Demon Armor Pack"
                  />
                </div>

                <div className="form-group" style={{ marginBottom: 0 }}>
                  <label className="form-label">Descrição / Prêmios *</label>
                  <textarea
                    className="form-input"
                    style={{ height: "100px", resize: "none" }}
                    value={form.description}
                    onChange={(e) => setField("description", e.target.value)}
                    placeholder="Descreva as recompensas que o vencedor levará..."
                  />
                </div>

                <div className="form-group" style={{ marginBottom: 0 }}>
                  <label className="form-label">URL da Imagem Ilustrativa</label>
                  <input
                    type="url"
                    className="form-input"
                    value={form.image}
                    onChange={(e) => setField("image", e.target.value)}
                    placeholder="https://i.imgur.com/..."
                  />
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }}>
                  <div className="form-group" style={{ marginBottom: 0 }}>
                    <label className="form-label">Preço do Bilhete (R$) *</label>
                    <input
                      type="number"
                      className="form-input"
                      value={form.price}
                      onChange={(e) => setField("price", e.target.value)}
                      placeholder="5.00"
                    />
                  </div>
                  <div className="form-group" style={{ marginBottom: 0 }}>
                    <label className="form-label">Total de Bilhetes (Meta) *</label>
                    <input
                      type="number"
                      className="form-input"
                      value={form.totalTickets}
                      onChange={(e) => setField("totalTickets", e.target.value)}
                      placeholder="500"
                    />
                  </div>
                </div>

                {msg && (
                  <div
                    style={{
                      background: msg.startsWith("✅") ? "rgba(39, 174, 96, 0.1)" : "rgba(139, 26, 26, 0.15)",
                      border: `1px solid ${msg.startsWith("✅") ? "var(--green)" : "var(--red)"}`,
                      color: msg.startsWith("✅") ? "var(--green2)" : "var(--red2)",
                      padding: "10px 14px",
                      borderRadius: "var(--radius-sm)",
                      fontSize: "13px",
                    }}
                  >
                    {msg}
                  </div>
                )}

                <button
                  className="btn btn-gold btn-full"
                  onClick={createRaffle}
                  disabled={loading || !form.title || !form.price || !form.totalTickets}
                  style={{ marginTop: "12px" }}
                >
                  {loading ? "⚡ Conjurando Rifa..." : "⚡ FORJAR RIFA LENDÁRIA"}
                </button>
              </div>
            </div>

            {/* LIVE PREVIEW OF RAFFLE CARD */}
            <div style={{ position: "sticky", top: "40px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "12px" }}>
                <span style={{ fontSize: "16px" }}>👁️</span>
                <span className="form-label" style={{ margin: 0 }}>Visualização em Tempo Real (Preview)</span>
              </div>

              {/* High-Fidelity Raffle Card Preview */}
              <div
                className="card card-gold animate-fade-in"
                style={{
                  background: "var(--dark3)",
                  boxShadow: "0 10px 30px rgba(0,0,0,0.6)",
                }}
              >
                <div style={{ display: "flex", gap: "16px", flexWrap: "wrap", marginBottom: "20px" }}>
                  {form.image ? (
                    <img
                      src={form.image}
                      alt="Raffle item"
                      onError={(e) => {
                        // Fallback image if loaded url fails
                        (e.target as HTMLImageElement).src = "https://i.imgur.com/8Fk3UeA.png";
                      }}
                      style={{
                        width: "80px",
                        height: "80px",
                        background: "var(--dark2)",
                        border: "2px solid var(--border3)",
                        borderRadius: "var(--radius-sm)",
                        objectFit: "contain",
                        padding: "4px",
                      }}
                    />
                  ) : (
                    <div
                      style={{
                        width: "80px",
                        height: "80px",
                        background: "var(--dark2)",
                        border: "2px dashed var(--border)",
                        borderRadius: "var(--radius-sm)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: "24px",
                        color: "var(--border3)",
                      }}
                    >
                      🎁
                    </div>
                  )}

                  <div style={{ flex: 1, minWidth: "180px" }}>
                    <h3 style={{ fontSize: "18px", color: "var(--gold)", margin: 0 }}>
                      {form.title || "Título da Rifa"}
                    </h3>
                    <p style={{ color: "var(--cream3)", fontSize: "13px", marginTop: "4px", fontStyle: "italic" }}>
                      R$ {parseFloat(form.price || "0").toLocaleString("pt-BR", { minimumFractionDigits: 2 })} por bilhete
                    </p>
                  </div>
                </div>

                <div style={{ marginBottom: "20px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: "12px", marginBottom: "6px", color: "var(--cream3)" }}>
                    <span>Progresso de Venda</span>
                    <span>0%</span>
                  </div>
                  <div className="progress-track">
                    <div className="progress-fill" style={{ width: "0%" }} />
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: "11px", color: "var(--cream3)", marginTop: "6px" }}>
                    <span>0 vendidos</span>
                    <span style={{ color: "var(--gold)" }}>meta: {form.totalTickets || "0"}</span>
                  </div>
                </div>

                <div style={{ borderTop: "1px solid var(--border)", paddingTop: "16px" }}>
                  <h4 style={{ color: "var(--gold)", fontSize: "12px", letterSpacing: "1px", textTransform: "uppercase", marginBottom: "8px" }}>
                    Recompensas do Vencedor
                  </h4>
                  <p style={{ color: "var(--cream2)", fontSize: "13px", lineHeight: "1.5" }}>
                    {form.description || "Adicione uma descrição detalhada das recompensas no formulário."}
                  </p>
                </div>
              </div>
            </div>

          </div>
        )}
      </div>
    </div>
  );
}
