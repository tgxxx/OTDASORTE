/**
 * app/page.tsx — Server Component
 *
 * Busca as 2 rifas mais recentes diretamente do Prisma no servidor.
 * Mantém o visual moderno, responsivo e simétrico com barras de progresso individuais.
 */

import React from "react";
import Link from "next/link";
import prisma from "@/lib/prisma";
import { GoldenHelmetIcon } from "@/components/Navbar";
import RafflePrizeSection from "./components/RafflePrizeSection";
import HomeClient from "./components/HomeClient";
import RaffleCardImage from "./components/RaffleCardImage";
import type { RaffleData } from "./components/RafflePrizeSection";

// Garante dados sempre frescos a cada requisição (sem cache do Next.js)
export const revalidate = 0;

async function getRecentRaffles(): Promise<RaffleData[]> {
  try {
    const raffles = await prisma.raffle.findMany({
      orderBy: { createdAt: "desc" },
      take: 2,
    });
    return raffles;
  } catch (err) {
    console.error("[Home] Erro ao buscar rifas recentes:", err);
    return [];
  }
}

export default async function Home({ searchParams }: { searchParams: { raffle?: string } }) {
  const recentRaffles = await getRecentRaffles();

  // Determinar qual rifa está ativa para a área de compras (padrão é a mais recente)
  let activeRaffle: RaffleData | null = recentRaffles[0] || null;
  if (searchParams.raffle) {
    const found = recentRaffles.find((r) => r.id === searchParams.raffle);
    if (found) {
      activeRaffle = found;
    } else {
      // Se for uma rifa mais antiga clicada de outra página
      const dbRaffle = await prisma.raffle.findUnique({
        where: { id: searchParams.raffle },
      });
      if (dbRaffle) {
        activeRaffle = dbRaffle;
      }
    }
  }

  const activeRaffleId = activeRaffle?.id || "";

  return (
    <div style={s.bg}>

      {/* ── HERO ──────────────────────────────────────────────────────── */}
      <section style={s.hero}>
        <div style={s.heroCrown}>
          <GoldenHelmetIcon size={64} />
        </div>
        <h1 style={s.heroTitle}>OT DA SORTE</h1>
        <p style={s.heroSub}>
          Participe e conquiste itens lendários do Reino Medieval
        </p>
        <Divider />
      </section>

      {/* ── GRILHAS DE RIFAS MAIS RECENTES (Lado a Lado) ────────────────── */}
      <section style={s.section}>
        <h2 style={s.sectionTitle}>✦ ÚLTIMAS RIFAS DO REINO ✦</h2>
        <p style={s.sectionSub}>Selecione uma das batalhas ativas abaixo para conjurar seus bilhetes</p>

        {recentRaffles.length === 0 ? (
          <div style={s.emptyCard}>
            <span style={{ fontSize: 40 }}>🔮</span>
            <p style={{ color: "#a8865a", fontStyle: "italic", marginTop: 12 }}>Nenhuma rifa ativa no momento.</p>
          </div>
        ) : (
          <div className="raffle-split-grid">
            {recentRaffles.map((raffle) => {
              const sold = raffle.soldTickets;
              const total = raffle.totalTickets;
              const pct = total > 0 ? Math.round((sold / total) * 100) : 0;
              const isActiveCard = raffle.id === activeRaffleId;
              const isEnded = raffle.status !== "active";

              return (
                <div
                  key={raffle.id}
                  style={{
                    ...s.raffleCard,
                    ...(isActiveCard ? s.raffleCardActive : {}),
                  }}
                  className="raffle-hover-card"
                >
                  {/* Status Badge */}
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                    <span style={{
                      fontSize: 10,
                      fontFamily: "'Cinzel',serif",
                      padding: "2px 8px",
                      borderRadius: 12,
                      border: `1px solid ${isEnded ? "#8b2020" : "#d4af37"}`,
                      background: isEnded ? "rgba(139,32,32,0.12)" : "rgba(212,175,55,0.08)",
                      color: isEnded ? "#e57373" : "#d4af37",
                      letterSpacing: "1px",
                    }}>
                      {isEnded ? "🔒 ENCERRADA" : "⚔️ ATIVA"}
                    </span>
                    <strong style={{ color: "var(--gold)", fontSize: 13, fontFamily: "'Cinzel', serif" }}>
                      R$ {raffle.price.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </strong>
                  </div>

                  {/* Image and Info */}
                  <div style={{ display: "flex", gap: 16, marginBottom: 16 }}>
                    <RaffleCardImage src={raffle.image ?? ""} alt={raffle.title} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <h3 style={s.raffleTitle}>{raffle.title}</h3>
                      <p style={s.raffleDesc}>{raffle.description}</p>
                    </div>
                  </div>

                  {/* INDIVIDUAL PROGRESS BAR */}
                  <div style={s.progressContainer}>
                    <div style={s.progressHeader}>
                      <span style={s.progressLabel}>Progresso de Venda</span>
                      <span style={s.progressPct}>{pct}%</span>
                    </div>
                    <div style={s.progressTrack}>
                      <div style={{ ...s.progressFill, width: `${pct}%` }} />
                    </div>
                    <div style={s.progressLegend}>
                      <span>{sold} vendidos</span>
                      <span style={{ color: "#d4af37" }}>meta: {total}</span>
                    </div>
                  </div>

                  {/* Select button */}
                  <Link
                    href={`/?raffle=${raffle.id}`}
                    scroll={false}
                    style={{
                      ...s.selectBtn,
                      ...(isActiveCard ? s.selectBtnActive : {}),
                    }}
                  >
                    {isActiveCard ? "⚡ RIFA SELECIONADA" : "⚔️ SELECIONAR RIFA"}
                  </Link>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* ── DETALHES DO PRÊMIO DA RIFA SELECIONADA ───────────────────────── */}
      <RafflePrizeSection raffle={activeRaffle} />

      {/* ── COMPRA DE TICKETS DA RIFA SELECIONADA ────────────────────────── */}
      <HomeClient initialRaffle={activeRaffle} />
    </div>
  );
}

function Divider() {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 12,
        maxWidth: 400,
        margin: "0 auto 8px",
      }}
    >
      <div
        style={{
          flex: 1,
          height: 1,
          background:
            "linear-gradient(90deg,transparent,#5a4318,transparent)",
        }}
      />
      <span style={{ color: "#8a6a10", fontSize: 18 }}>✦</span>
      <div
        style={{
          flex: 1,
          height: 1,
          background:
            "linear-gradient(90deg,transparent,#5a4318,transparent)",
        }}
      />
    </div>
  );
}

const s: Record<string, React.CSSProperties> = {
  bg: {
    minHeight: "100vh",
    background:
      "radial-gradient(ellipse 80% 40% at 50% 0%,rgba(201,162,39,0.08) 0%,transparent 60%), #0a0704",
    color: "#f0dfa8",
    fontFamily: "'Crimson Text',serif",
  },
  hero: {
    background: "linear-gradient(180deg,#110e08 0%,#0a0704 100%)",
    borderBottom: "1px solid #3d2e0f",
    padding: "48px 20px 24px",
    textAlign: "center",
  },
  heroCrown: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 12,
  },
  heroTitle: {
    fontFamily: "'Cinzel',serif",
    fontSize: "clamp(26px,5vw,46px)",
    color: "#d4af37",
    lineHeight: 1.1,
    textShadow:
      "0 0 40px rgba(201,162,39,0.3),0 2px 4px rgba(0,0,0,0.8)",
    marginBottom: 10,
    letterSpacing: "6px",
  },
  heroSub: {
    fontSize: "clamp(13px,2vw,16px)",
    color: "#a8865a",
    fontStyle: "italic",
    marginBottom: 20,
  },
  section: { maxWidth: 1100, margin: "0 auto", padding: "36px 20px" },
  sectionTitle: {
    fontFamily: "'Cinzel',serif",
    fontSize: "18px",
    color: "#d4af37",
    textAlign: "center",
    letterSpacing: "3px",
    marginBottom: 6,
  },
  sectionSub: {
    fontSize: "13px",
    color: "#a8865a",
    fontStyle: "italic",
    textAlign: "center",
    marginBottom: 32,
    fontFamily: "'Crimson Text',serif",
  },
  emptyCard: {
    background: "#1a1409",
    border: "1px dashed #5a4318",
    borderRadius: 8,
    padding: "48px 24px",
    textAlign: "center",
  },
  raffleCard: {
    background: "#161006",
    border: "1px solid #3d2e0f",
    borderRadius: 8,
    padding: 20,
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between",
  },
  raffleCardActive: {
    borderColor: "#d4af37",
    background: "#20170a",
    boxShadow: "0 0 20px rgba(212,175,55,0.06)",
  },
  raffleTitle: {
    fontFamily: "'Cinzel',serif",
    fontSize: "15px",
    color: "#d4af37",
    margin: 0,
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
  },
  raffleDesc: {
    fontSize: "12.5px",
    color: "#a8865a",
    lineHeight: "1.4",
    marginTop: 6,
    margin: 0,
    display: "-webkit-box",
    WebkitLineClamp: 3,
    WebkitBoxOrient: "vertical" as const,
    overflow: "hidden",
  },
  progressContainer: {
    margin: "12px 0 20px",
  },
  progressHeader: {
    display: "flex",
    justifyContent: "space-between",
    marginBottom: 6,
  },
  progressLabel: { fontSize: 11, color: "#a8865a", letterSpacing: 0.5 },
  progressPct: {
    fontFamily: "'Cinzel',serif",
    color: "#d4af37",
    fontSize: 14,
    fontWeight: "bold",
  },
  progressTrack: {
    background: "#0c0904",
    border: "1px solid #32250c",
    borderRadius: 4,
    height: 8,
    overflow: "hidden",
  },
  progressFill: {
    height: "100%",
    background: "linear-gradient(90deg,#8a6a10,#e8c547)",
    borderRadius: 4,
    transition: "width 0.5s ease-out",
  },
  progressLegend: {
    display: "flex",
    justifyContent: "space-between",
    marginTop: 6,
    fontSize: 11,
    color: "#a8865a",
  },
  selectBtn: {
    display: "block",
    textAlign: "center",
    width: "100%",
    padding: "10px 0",
    borderRadius: 4,
    background: "transparent",
    border: "1px solid #7a5c22",
    color: "#d4af37",
    fontFamily: "'Cinzel',serif",
    fontSize: 11,
    letterSpacing: 1.5,
    textDecoration: "none",
    fontWeight: "bold",
    transition: "all 0.2s",
    cursor: "pointer",
  },
  selectBtnActive: {
    background: "linear-gradient(180deg,#d4af37 0%,#8a6a10 100%)",
    border: "1px solid #8a6a10",
    color: "#0a0704",
    boxShadow: "0 4px 10px rgba(212,175,55,0.15)",
  },
};
