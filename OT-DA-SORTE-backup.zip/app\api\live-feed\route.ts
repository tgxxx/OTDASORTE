import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";

/**
 * Lightweight polling endpoint for serverless-compatible real-time updates.
 * Returns the latest raffle stats and recent ticket purchases.
 * Clients poll this every 5-10 seconds for a live feed experience.
 */
export async function GET(req: NextRequest) {
  try {
    // Get active raffles with recent ticket info
    const activeRaffles = await prisma.raffle.findMany({
      where: { status: "active" },
      select: {
        id: true,
        title: true,
        totalTickets: true,
        soldTickets: true,
        price: true,
      },
    });

    // Get last 10 ticket purchases across all raffles
    const recentTickets = await prisma.ticket.findMany({
      take: 10,
      orderBy: { createdAt: "desc" },
      select: {
        number: true,
        createdAt: true,
        user: {
          select: { username: true },
        },
        raffle: {
          select: { title: true },
        },
      },
    });

    const feed = recentTickets.map((t) => ({
      username: t.user.username,
      raffle: t.raffle.title,
      number: t.number,
      time: t.createdAt,
    }));

    return NextResponse.json(
      { raffles: activeRaffles, feed },
      {
        headers: {
          "Cache-Control": "public, s-maxage=5, stale-while-revalidate=10",
        },
      }
    );
  } catch (err) {
    console.error("[live-feed]", err);
    return NextResponse.json({ raffles: [], feed: [] });
  }
}
