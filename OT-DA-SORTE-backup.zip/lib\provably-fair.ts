import crypto from "crypto";

/**
 * Generates a cryptographically secure random 256-bit server seed.
 */
export function generateServerSeed(): string {
  return crypto.randomBytes(32).toString("hex");
}

/**
 * Hashes a string using SHA-256.
 */
export function hashSha256(data: string): string {
  return crypto.createHash("sha256").update(data).digest("hex");
}

/**
 * Computes the winning ticket number mathematically using Provably Fair algorithm.
 * Formula: winningNumber = (HMAC_SHA256(serverSeed, clientSeed + "-0") [first 8 bytes] % totalTickets) + 1
 * 
 * @param serverSeed The secret server seed (revealed after draw)
 * @param clientSeed The public client seed (Ethereum block hash, user seed, etc.)
 * @param totalTickets Total tickets sold (or total raffle tickets range)
 */
export function getWinningTicket(serverSeed: string, clientSeed: string, totalTickets: number): number {
  const hmac = crypto.createHmac("sha256", serverSeed);
  hmac.update(`${clientSeed}-0`); // using nonce 0
  const hash = hmac.digest("hex");

  // Get first 10 hex chars (5 bytes) to fit in MAX_SAFE_INTEGER safely
  const hexSubstring = hash.substring(0, 10);
  const intVal = parseInt(hexSubstring, 16);

  // Return 1-indexed ticket number
  return (intVal % totalTickets) + 1;
}
