import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import crypto from "crypto";
import { sendPasswordResetEmail } from "@/lib/email";

export async function POST(req: NextRequest) {
  try {
    const { email } = await req.json();
    if (!email) {
      return NextResponse.json({ error: "E-mail é obrigatório" }, { status: 400 });
    }

    const user = await prisma.user.findUnique({
      where: { email },
    });

    // Security practice: do not confirm if the email exists to prevent enumeration,
    // but proceed to send the email if the user does exist.
    if (user) {
      const resetToken = crypto.randomBytes(32).toString("hex");
      const resetTokenExpires = new Date(Date.now() + 60 * 60 * 1000); // 1 hora de expiração

      await prisma.user.update({
        where: { id: user.id },
        data: {
          resetToken,
          resetTokenExpires,
        },
      });

      try {
        await sendPasswordResetEmail(email, user.username, resetToken);
      } catch (emailErr) {
        console.error("Erro ao enviar e-mail de recuperação:", emailErr);
      }
    }

    return NextResponse.json({
      success: true,
      message: "Se o e-mail inserido estiver cadastrado, um link de recuperação foi enviado para sua caixa de entrada.",
    });
  } catch (err) {
    console.error("[forgot-password]", err);
    return NextResponse.json({ error: "Erro interno no servidor" }, { status: 500 });
  }
}
