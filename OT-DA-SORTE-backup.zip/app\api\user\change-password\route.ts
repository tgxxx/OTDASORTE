import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import bcrypt from "bcryptjs";
import { verifyToken } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    // 1. Verify Authentication
    const token = req.cookies.get("token")?.value;
    if (!token) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
    }

    const decoded = verifyToken(token);
    if (!decoded) {
      return NextResponse.json({ error: "Sessão inválida" }, { status: 401 });
    }

    // 2. Parse request fields
    const { currentPassword, newPassword, confirmPassword } = await req.json();

    if (!currentPassword || !newPassword || !confirmPassword) {
      return NextResponse.json({ error: "Todos os campos são obrigatórios" }, { status: 400 });
    }

    if (newPassword.length < 6) {
      return NextResponse.json({ error: "A nova senha deve ter no mínimo 6 caracteres" }, { status: 400 });
    }

    if (newPassword !== confirmPassword) {
      return NextResponse.json({ error: "As senhas não coincidem" }, { status: 400 });
    }

    // 3. Retrieve user
    const user = await prisma.user.findUnique({
      where: { id: decoded.id }
    });

    if (!user) {
      return NextResponse.json({ error: "Usuário não encontrado" }, { status: 404 });
    }

    // 4. Verify current password
    const isMatch = await bcrypt.compare(currentPassword, user.password);
    if (!isMatch) {
      return NextResponse.json({ error: "Senha atual incorreta" }, { status: 400 });
    }

    // 5. Encrypt and save new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    await prisma.user.update({
      where: { id: user.id },
      data: {
        password: hashedPassword
      }
    });

    // 6. Log security action
    const ip = req.headers.get("x-forwarded-for") || "127.0.0.1";
    await prisma.log.create({
      data: {
        action: "PASSWORD_CHANGED",
        ip: ip,
        userId: user.id
      }
    });

    return NextResponse.json({ success: true, message: "Senha alterada com sucesso!" });
  } catch (err) {
    console.error("[change-password]", err);
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 });
  }
}
